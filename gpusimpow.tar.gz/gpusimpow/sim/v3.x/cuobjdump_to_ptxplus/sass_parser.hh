/* A Bison parser, made by GNU Bison 2.5.  */

/* Bison interface for Yacc-like parsers in C
   
      Copyright (C) 1984, 1989-1990, 2000-2011 Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     BAR = 258,
     ADA = 259,
     AND = 260,
     ANDS = 261,
     BRA = 262,
     CAL = 263,
     COS = 264,
     DADD = 265,
     DMIN = 266,
     DMAX = 267,
     DFMA = 268,
     DMUL = 269,
     EX2 = 270,
     F2F = 271,
     F2I = 272,
     FADD = 273,
     FADD32 = 274,
     FADD32I = 275,
     FMAD = 276,
     FMAD32I = 277,
     FMUL = 278,
     FMUL32 = 279,
     FMUL32I = 280,
     FSET = 281,
     DSET = 282,
     G2R = 283,
     GLD = 284,
     GST = 285,
     I2F = 286,
     I2I = 287,
     IADD = 288,
     IADD32 = 289,
     IADD32I = 290,
     IMAD = 291,
     ISAD = 292,
     IMAD24 = 293,
     IMAD32I = 294,
     IMAD32 = 295,
     IADDCARRY = 296,
     IMUL = 297,
     IMUL24 = 298,
     IMULS24 = 299,
     IMUL32 = 300,
     IMUL32S24 = 301,
     IMUL32U24 = 302,
     IMUL32I = 303,
     IMUL32I24 = 304,
     IMUL32IS24 = 305,
     ISET = 306,
     LG2 = 307,
     LLD = 308,
     LST = 309,
     MOV = 310,
     MOV32 = 311,
     MVC = 312,
     MVI = 313,
     NOP = 314,
     NOT = 315,
     NOTS = 316,
     OR = 317,
     ORS = 318,
     R2A = 319,
     R2G = 320,
     R2GU16U8 = 321,
     RCP = 322,
     RCP32 = 323,
     RET = 324,
     RRO = 325,
     RSQ = 326,
     SIN = 327,
     SHL = 328,
     SHR = 329,
     SSY = 330,
     XOR = 331,
     XORS = 332,
     S2R = 333,
     SASS_LD = 334,
     STS = 335,
     LDS = 336,
     SASS_ST = 337,
     IMIN = 338,
     IMAX = 339,
     A2R = 340,
     FMAX = 341,
     FMIN = 342,
     TEX = 343,
     TEX32 = 344,
     C2R = 345,
     EXIT = 346,
     GRED = 347,
     PBK = 348,
     BRK = 349,
     R2C = 350,
     GATOM = 351,
     VOTE = 352,
     EQ = 353,
     EQU = 354,
     GE = 355,
     GEU = 356,
     GT = 357,
     GTU = 358,
     LE = 359,
     LEU = 360,
     LT = 361,
     LTU = 362,
     NE = 363,
     NEU = 364,
     DOTBEXT = 365,
     DOTS = 366,
     DOTSFU = 367,
     DOTTRUNC = 368,
     DOTCEIL = 369,
     DOTFLOOR = 370,
     DOTIR = 371,
     DOTUN = 372,
     DOTNODEP = 373,
     DOTSAT = 374,
     DOTANY = 375,
     DOTALL = 376,
     DOTF16 = 377,
     DOTF32 = 378,
     DOTF64 = 379,
     DOTS8 = 380,
     DOTS16 = 381,
     DOTS32 = 382,
     DOTS64 = 383,
     DOTS128 = 384,
     DOTU8 = 385,
     DOTU16 = 386,
     DOTU32 = 387,
     DOTU24 = 388,
     DOTU64 = 389,
     DOTHI = 390,
     DOTNOINC = 391,
     DOTEQ = 392,
     DOTEQU = 393,
     DOTGE = 394,
     DOTGEU = 395,
     DOTGT = 396,
     DOTGTU = 397,
     DOTLE = 398,
     DOTLEU = 399,
     DOTLT = 400,
     DOTLTU = 401,
     DOTNE = 402,
     DOTNEU = 403,
     DOTNSF = 404,
     DOTSF = 405,
     DOTCARRY = 406,
     DOTCC = 407,
     DOTX = 408,
     DOTE = 409,
     DOTRED = 410,
     DOTPOPC = 411,
     REGISTER = 412,
     REGISTERLO = 413,
     REGISTERHI = 414,
     OFFSETREGISTER = 415,
     PREDREGISTER = 416,
     PREDREGISTER2 = 417,
     PREDREGISTER3 = 418,
     SREGISTER = 419,
     VERSIONHEADER = 420,
     FUNCTIONHEADER = 421,
     SMEMLOCATION = 422,
     ABSSMEMLOCATION = 423,
     GMEMLOCATION = 424,
     CMEMLOCATION = 425,
     LMEMLOCATION = 426,
     IDENTIFIER = 427,
     HEXLITERAL = 428,
     LEFTBRACKET = 429,
     RIGHTBRACKET = 430,
     PIPE = 431,
     TILDE = 432,
     NEWLINE = 433,
     SEMICOLON = 434,
     LABEL = 435,
     LABELSTART = 436,
     LABELEND = 437,
     PTXHEADER = 438,
     ELFHEADER = 439,
     INFOARCHVERSION = 440,
     INFOCODEVERSION_HEADER = 441,
     INFOCODEVERSION = 442,
     INFOPRODUCER = 443,
     INFOHOST = 444,
     INFOCOMPILESIZE_HEADER = 445,
     INFOCOMPILESIZE = 446,
     INFOIDENTIFIER = 447,
     DOT = 448,
     INSTHEX = 449,
     OSQBRACKET = 450,
     CSQBRACKET = 451
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 2068 of yacc.c  */
#line 41 "sass.y"

  double double_value;
  float  float_value;
  int    int_value;
  char * string_value;
  void * ptr_value;



/* Line 2068 of yacc.c  */
#line 256 "sass_parser.hh"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE sass_lval;


