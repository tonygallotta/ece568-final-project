/* A Bison parser, made by GNU Bison 2.5.  */

/* Bison implementation for Yacc-like parsers in C
   
      Copyright (C) 1984, 1989-1990, 2000-2011 Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.5"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* Using locations.  */
#define YYLSP_NEEDED 0

/* Substitute the variable and function names.  */
#define yyparse         ptx_parse
#define yylex           ptx_lex
#define yyerror         ptx_error
#define yylval          ptx_lval
#define yychar          ptx_char
#define yydebug         ptx_debug
#define yynerrs         ptx_nerrs


/* Copy the first part of user declarations.  */


/* Line 268 of yacc.c  */
#line 79 "ptx.tab.c"

/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     STRING = 258,
     OPCODE = 259,
     ALIGN_DIRECTIVE = 260,
     BRANCHTARGETS_DIRECTIVE = 261,
     BYTE_DIRECTIVE = 262,
     CALLPROTOTYPE_DIRECTIVE = 263,
     CALLTARGETS_DIRECTIVE = 264,
     CONST_DIRECTIVE = 265,
     CONSTPTR_DIRECTIVE = 266,
     ENTRY_DIRECTIVE = 267,
     EXTERN_DIRECTIVE = 268,
     FILE_DIRECTIVE = 269,
     FUNC_DIRECTIVE = 270,
     GLOBAL_DIRECTIVE = 271,
     LOCAL_DIRECTIVE = 272,
     LOC_DIRECTIVE = 273,
     MAXNCTAPERSM_DIRECTIVE = 274,
     MAXNNREG_DIRECTIVE = 275,
     MAXNTID_DIRECTIVE = 276,
     MINNCTAPERSM_DIRECTIVE = 277,
     PARAM_DIRECTIVE = 278,
     PRAGMA_DIRECTIVE = 279,
     REG_DIRECTIVE = 280,
     REQNTID_DIRECTIVE = 281,
     SECTION_DIRECTIVE = 282,
     SHARED_DIRECTIVE = 283,
     SREG_DIRECTIVE = 284,
     STRUCT_DIRECTIVE = 285,
     SURF_DIRECTIVE = 286,
     TARGET_DIRECTIVE = 287,
     TEX_DIRECTIVE = 288,
     UNION_DIRECTIVE = 289,
     VERSION_DIRECTIVE = 290,
     ADDRESS_SIZE_DIRECTIVE = 291,
     VISIBLE_DIRECTIVE = 292,
     IDENTIFIER = 293,
     INT_OPERAND = 294,
     FLOAT_OPERAND = 295,
     DOUBLE_OPERAND = 296,
     S8_TYPE = 297,
     S16_TYPE = 298,
     S32_TYPE = 299,
     S64_TYPE = 300,
     U8_TYPE = 301,
     U16_TYPE = 302,
     U32_TYPE = 303,
     U64_TYPE = 304,
     F16_TYPE = 305,
     F32_TYPE = 306,
     F64_TYPE = 307,
     FF64_TYPE = 308,
     B8_TYPE = 309,
     B16_TYPE = 310,
     B32_TYPE = 311,
     B64_TYPE = 312,
     BB64_TYPE = 313,
     BB128_TYPE = 314,
     PRED_TYPE = 315,
     TEXREF_TYPE = 316,
     SAMPLERREF_TYPE = 317,
     SURFREF_TYPE = 318,
     V2_TYPE = 319,
     V3_TYPE = 320,
     V4_TYPE = 321,
     COMMA = 322,
     PRED = 323,
     HALF_OPTION = 324,
     EQ_OPTION = 325,
     NE_OPTION = 326,
     LT_OPTION = 327,
     LE_OPTION = 328,
     GT_OPTION = 329,
     GE_OPTION = 330,
     LO_OPTION = 331,
     LS_OPTION = 332,
     HI_OPTION = 333,
     HS_OPTION = 334,
     EQU_OPTION = 335,
     NEU_OPTION = 336,
     LTU_OPTION = 337,
     LEU_OPTION = 338,
     GTU_OPTION = 339,
     GEU_OPTION = 340,
     NUM_OPTION = 341,
     NAN_OPTION = 342,
     CF_OPTION = 343,
     SF_OPTION = 344,
     NSF_OPTION = 345,
     LEFT_SQUARE_BRACKET = 346,
     RIGHT_SQUARE_BRACKET = 347,
     WIDE_OPTION = 348,
     SPECIAL_REGISTER = 349,
     MINUS = 350,
     PLUS = 351,
     COLON = 352,
     SEMI_COLON = 353,
     EXCLAMATION = 354,
     PIPE = 355,
     RIGHT_BRACE = 356,
     LEFT_BRACE = 357,
     EQUALS = 358,
     PERIOD = 359,
     BACKSLASH = 360,
     DIMENSION_MODIFIER = 361,
     RN_OPTION = 362,
     RZ_OPTION = 363,
     RM_OPTION = 364,
     RP_OPTION = 365,
     RNI_OPTION = 366,
     RZI_OPTION = 367,
     RMI_OPTION = 368,
     RPI_OPTION = 369,
     UNI_OPTION = 370,
     GEOM_MODIFIER_1D = 371,
     GEOM_MODIFIER_2D = 372,
     GEOM_MODIFIER_3D = 373,
     SAT_OPTION = 374,
     FTZ_OPTION = 375,
     NEG_OPTION = 376,
     ATOMIC_AND = 377,
     ATOMIC_OR = 378,
     ATOMIC_XOR = 379,
     ATOMIC_CAS = 380,
     ATOMIC_EXCH = 381,
     ATOMIC_ADD = 382,
     ATOMIC_INC = 383,
     ATOMIC_DEC = 384,
     ATOMIC_MIN = 385,
     ATOMIC_MAX = 386,
     LEFT_ANGLE_BRACKET = 387,
     RIGHT_ANGLE_BRACKET = 388,
     LEFT_PAREN = 389,
     RIGHT_PAREN = 390,
     APPROX_OPTION = 391,
     FULL_OPTION = 392,
     ANY_OPTION = 393,
     ALL_OPTION = 394,
     GLOBAL_OPTION = 395,
     CTA_OPTION = 396,
     SYS_OPTION = 397,
     EXIT_OPTION = 398,
     ABS_OPTION = 399,
     TO_OPTION = 400,
     CA_OPTION = 401,
     CG_OPTION = 402,
     CS_OPTION = 403,
     LU_OPTION = 404,
     CV_OPTION = 405,
     WB_OPTION = 406,
     WT_OPTION = 407
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 293 of yacc.c  */
#line 30 "../src/cuda-sim/ptx.y"

  double double_value;
  float  float_value;
  int    int_value;
  char * string_value;
  void * ptr_value;



/* Line 293 of yacc.c  */
#line 277 "ptx.tab.c"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif


/* Copy the second part of user declarations.  */

/* Line 343 of yacc.c  */
#line 192 "../src/cuda-sim/ptx.y"

  	#include "ptx_parser.h"
	#include <stdlib.h>
	#include <string.h>
	#include <math.h>
	void syntax_not_implemented();
	extern int g_func_decl;
	int ptx_lex(void);
	int ptx_error(const char *);


/* Line 343 of yacc.c  */
#line 301 "ptx.tab.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int yyi)
#else
static int
YYID (yyi)
    int yyi;
#endif
{
  return yyi;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)				\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack_alloc, Stack, yysize);			\
	Stack = &yyptr->Stack_alloc;					\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  2
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   582

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  153
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  60
/* YYNRULES -- Number of rules.  */
#define YYNRULES  252
/* YYNRULES -- Number of states.  */
#define YYNSTATES  351

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   407

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
     135,   136,   137,   138,   139,   140,   141,   142,   143,   144,
     145,   146,   147,   148,   149,   150,   151,   152
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     4,     7,    10,    13,    14,    18,    19,
      20,    26,    33,    34,    35,    43,    44,    48,    50,    51,
      52,    59,    61,    63,    65,    68,    71,    72,    74,    75,
      80,    81,    86,    87,    92,    96,    98,   100,   103,   106,
     109,   111,   114,   117,   121,   124,   129,   136,   139,   143,
     148,   152,   155,   160,   165,   172,   174,   176,   180,   182,
     187,   191,   196,   198,   201,   203,   205,   207,   209,   212,
     214,   216,   218,   220,   222,   224,   226,   228,   230,   232,
     234,   237,   239,   241,   243,   245,   247,   249,   251,   253,
     255,   257,   259,   261,   263,   265,   267,   269,   271,   273,
     275,   277,   279,   281,   283,   285,   287,   291,   295,   297,
     301,   304,   307,   311,   312,   324,   331,   337,   340,   342,
     343,   347,   349,   352,   356,   360,   364,   368,   372,   376,
     380,   384,   388,   392,   396,   398,   401,   403,   405,   407,
     409,   411,   413,   415,   417,   419,   421,   423,   425,   427,
     429,   431,   433,   435,   437,   439,   441,   443,   445,   447,
     449,   451,   453,   455,   457,   459,   461,   463,   465,   467,
     469,   471,   473,   475,   477,   479,   481,   483,   485,   487,
     489,   491,   493,   495,   497,   499,   501,   503,   505,   507,
     509,   511,   513,   515,   517,   519,   521,   523,   525,   527,
     529,   531,   533,   535,   537,   539,   541,   545,   547,   550,
     553,   555,   557,   559,   561,   564,   566,   570,   573,   577,
     580,   584,   588,   593,   598,   602,   607,   612,   618,   626,
     636,   637,   644,   647,   649,   653,   658,   663,   668,   671,
     675,   680,   685,   690,   696,   702,   707,   709,   711,   713,
     715,   718,   721
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
     154,     0,    -1,    -1,   154,   175,    -1,   154,   155,    -1,
     154,   160,    -1,    -1,   160,   156,   173,    -1,    -1,    -1,
     160,   157,   159,   158,   173,    -1,    21,    39,    67,    39,
      67,    39,    -1,    -1,    -1,   167,   134,   161,   170,   135,
     162,   164,    -1,    -1,   167,   163,   164,    -1,   167,    -1,
      -1,    -1,    38,   165,   134,   166,   168,   135,    -1,    38,
      -1,    12,    -1,    15,    -1,    37,    15,    -1,    13,    15,
      -1,    -1,   170,    -1,    -1,   168,    67,   169,   170,    -1,
      -1,    23,   171,   177,   179,    -1,    -1,    25,   172,   177,
     179,    -1,   102,   174,   101,    -1,   175,    -1,   190,    -1,
     174,   175,    -1,   174,   190,    -1,   174,   173,    -1,   173,
      -1,   176,    98,    -1,    35,    41,    -1,    35,    41,    96,
      -1,    36,    39,    -1,    32,    38,    67,    38,    -1,    32,
      38,    67,    38,    67,    38,    -1,    32,    38,    -1,    14,
      39,     3,    -1,    18,    39,    39,    39,    -1,    24,     3,
      98,    -1,   177,   178,    -1,   177,   179,   103,   188,    -1,
     177,   179,   103,   211,    -1,    11,    38,    67,    38,    67,
      39,    -1,   180,    -1,   179,    -1,   178,    67,   179,    -1,
      38,    -1,    38,   132,    39,   133,    -1,    38,    91,    92,
      -1,    38,    91,    39,    92,    -1,   181,    -1,   180,   181,
      -1,   183,    -1,   185,    -1,   182,    -1,    13,    -1,     5,
      39,    -1,    25,    -1,    29,    -1,   184,    -1,    10,    -1,
      16,    -1,    17,    -1,    23,    -1,    28,    -1,    31,    -1,
      33,    -1,   187,    -1,   186,   187,    -1,    64,    -1,    65,
      -1,    66,    -1,    42,    -1,    43,    -1,    44,    -1,    45,
      -1,    46,    -1,    47,    -1,    48,    -1,    49,    -1,    50,
      -1,    51,    -1,    52,    -1,    53,    -1,    54,    -1,    55,
      -1,    56,    -1,    57,    -1,    58,    -1,    59,    -1,    60,
      -1,    61,    -1,    62,    -1,    63,    -1,   102,   189,   101,
      -1,   102,   188,   101,    -1,   211,    -1,   189,    67,   211,
      -1,   191,    98,    -1,    38,    97,    -1,   195,   191,    98,
      -1,    -1,   193,   134,   204,   135,   192,    67,   204,    67,
     134,   203,   135,    -1,   193,   204,    67,   134,   203,   135,
      -1,   193,   204,    67,   134,   135,    -1,   193,   203,    -1,
     193,    -1,    -1,     4,   194,   196,    -1,     4,    -1,    68,
      38,    -1,    68,    99,    38,    -1,    68,    38,    70,    -1,
      68,    38,    73,    -1,    68,    38,    71,    -1,    68,    38,
      75,    -1,    68,    38,    80,    -1,    68,    38,    84,    -1,
      68,    38,    81,    -1,    68,    38,    88,    -1,    68,    38,
      89,    -1,    68,    38,    90,    -1,   197,    -1,   197,   196,
      -1,   185,    -1,   202,    -1,   184,    -1,   199,    -1,   115,
      -1,    93,    -1,   138,    -1,   139,    -1,   140,    -1,   141,
      -1,   142,    -1,   116,    -1,   117,    -1,   118,    -1,   119,
      -1,   120,    -1,   121,    -1,   136,    -1,   137,    -1,   143,
      -1,   144,    -1,   198,    -1,   145,    -1,    69,    -1,   146,
      -1,   147,    -1,   148,    -1,   149,    -1,   150,    -1,   151,
      -1,   152,    -1,   122,    -1,   123,    -1,   124,    -1,   125,
      -1,   126,    -1,   127,    -1,   128,    -1,   129,    -1,   130,
      -1,   131,    -1,   200,    -1,   201,    -1,   107,    -1,   108,
      -1,   109,    -1,   110,    -1,   111,    -1,   112,    -1,   113,
      -1,   114,    -1,    70,    -1,    71,    -1,    72,    -1,    73,
      -1,    74,    -1,    75,    -1,    76,    -1,    77,    -1,    78,
      -1,    79,    -1,    80,    -1,    81,    -1,    82,    -1,    83,
      -1,    84,    -1,    85,    -1,    86,    -1,    87,    -1,   204,
      -1,   204,    67,   203,    -1,    38,    -1,    99,    38,    -1,
      95,    38,    -1,   209,    -1,   211,    -1,   208,    -1,   205,
      -1,    95,   205,    -1,   206,    -1,    38,    96,    39,    -1,
      38,    76,    -1,    95,    38,    76,    -1,    38,    78,    -1,
      95,    38,    78,    -1,    38,   100,    38,    -1,    38,   100,
      38,    76,    -1,    38,   100,    38,    78,    -1,    38,   105,
      38,    -1,    38,   105,    38,    76,    -1,    38,   105,    38,
      78,    -1,   102,    38,    67,    38,   101,    -1,   102,    38,
      67,    38,    67,    38,   101,    -1,   102,    38,    67,    38,
      67,    38,    67,    38,   101,    -1,    -1,    91,    38,    67,
     207,   205,    92,    -1,    94,   106,    -1,    94,    -1,    91,
     212,    92,    -1,    38,    91,   212,    92,    -1,    38,    91,
     211,    92,    -1,    38,    91,   210,    92,    -1,    95,   209,
      -1,    38,    96,    38,    -1,    38,    96,    38,    76,    -1,
      38,    96,    38,    78,    -1,    38,    96,   103,    38,    -1,
      38,    96,   103,    38,    76,    -1,    38,    96,   103,    38,
      78,    -1,    38,    96,   103,    39,    -1,    39,    -1,    40,
      -1,    41,    -1,    38,    -1,    38,    76,    -1,    38,    78,
      -1,    38,    96,    39,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   205,   205,   206,   207,   208,   211,   211,   212,   212,
     212,   215,   220,   220,   220,   221,   221,   222,   225,   225,
     225,   226,   229,   230,   231,   232,   235,   236,   237,   237,
     239,   239,   240,   240,   242,   244,   245,   246,   247,   248,
     249,   252,   253,   254,   255,   256,   257,   258,   259,   260,
     261,   264,   265,   266,   267,   270,   272,   273,   275,   276,
     288,   289,   292,   293,   295,   296,   297,   298,   301,   303,
     304,   305,   308,   309,   310,   311,   312,   313,   314,   317,
     318,   321,   322,   323,   326,   327,   328,   329,   330,   331,
     332,   333,   334,   335,   336,   337,   338,   339,   340,   341,
     342,   343,   344,   345,   346,   347,   350,   351,   353,   354,
     356,   357,   358,   360,   360,   361,   362,   363,   364,   367,
     367,   368,   370,   371,   372,   373,   374,   375,   376,   377,
     378,   379,   380,   381,   384,   385,   387,   388,   389,   390,
     391,   392,   393,   394,   395,   396,   397,   398,   399,   400,
     401,   402,   403,   404,   405,   406,   407,   408,   409,   410,
     411,   412,   413,   414,   415,   416,   417,   420,   421,   422,
     423,   424,   425,   426,   427,   428,   429,   432,   433,   435,
     436,   437,   438,   441,   442,   443,   444,   447,   448,   449,
     450,   451,   452,   453,   454,   455,   456,   457,   458,   459,
     460,   461,   462,   463,   464,   467,   468,   470,   471,   472,
     473,   474,   475,   476,   477,   478,   479,   480,   481,   482,
     483,   484,   485,   486,   487,   488,   489,   492,   493,   494,
     497,   497,   501,   502,   505,   506,   507,   508,   509,   512,
     513,   514,   515,   516,   517,   518,   521,   522,   523,   526,
     527,   528,   529
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "STRING", "OPCODE", "ALIGN_DIRECTIVE",
  "BRANCHTARGETS_DIRECTIVE", "BYTE_DIRECTIVE", "CALLPROTOTYPE_DIRECTIVE",
  "CALLTARGETS_DIRECTIVE", "CONST_DIRECTIVE", "CONSTPTR_DIRECTIVE",
  "ENTRY_DIRECTIVE", "EXTERN_DIRECTIVE", "FILE_DIRECTIVE",
  "FUNC_DIRECTIVE", "GLOBAL_DIRECTIVE", "LOCAL_DIRECTIVE", "LOC_DIRECTIVE",
  "MAXNCTAPERSM_DIRECTIVE", "MAXNNREG_DIRECTIVE", "MAXNTID_DIRECTIVE",
  "MINNCTAPERSM_DIRECTIVE", "PARAM_DIRECTIVE", "PRAGMA_DIRECTIVE",
  "REG_DIRECTIVE", "REQNTID_DIRECTIVE", "SECTION_DIRECTIVE",
  "SHARED_DIRECTIVE", "SREG_DIRECTIVE", "STRUCT_DIRECTIVE",
  "SURF_DIRECTIVE", "TARGET_DIRECTIVE", "TEX_DIRECTIVE", "UNION_DIRECTIVE",
  "VERSION_DIRECTIVE", "ADDRESS_SIZE_DIRECTIVE", "VISIBLE_DIRECTIVE",
  "IDENTIFIER", "INT_OPERAND", "FLOAT_OPERAND", "DOUBLE_OPERAND",
  "S8_TYPE", "S16_TYPE", "S32_TYPE", "S64_TYPE", "U8_TYPE", "U16_TYPE",
  "U32_TYPE", "U64_TYPE", "F16_TYPE", "F32_TYPE", "F64_TYPE", "FF64_TYPE",
  "B8_TYPE", "B16_TYPE", "B32_TYPE", "B64_TYPE", "BB64_TYPE", "BB128_TYPE",
  "PRED_TYPE", "TEXREF_TYPE", "SAMPLERREF_TYPE", "SURFREF_TYPE", "V2_TYPE",
  "V3_TYPE", "V4_TYPE", "COMMA", "PRED", "HALF_OPTION", "EQ_OPTION",
  "NE_OPTION", "LT_OPTION", "LE_OPTION", "GT_OPTION", "GE_OPTION",
  "LO_OPTION", "LS_OPTION", "HI_OPTION", "HS_OPTION", "EQU_OPTION",
  "NEU_OPTION", "LTU_OPTION", "LEU_OPTION", "GTU_OPTION", "GEU_OPTION",
  "NUM_OPTION", "NAN_OPTION", "CF_OPTION", "SF_OPTION", "NSF_OPTION",
  "LEFT_SQUARE_BRACKET", "RIGHT_SQUARE_BRACKET", "WIDE_OPTION",
  "SPECIAL_REGISTER", "MINUS", "PLUS", "COLON", "SEMI_COLON",
  "EXCLAMATION", "PIPE", "RIGHT_BRACE", "LEFT_BRACE", "EQUALS", "PERIOD",
  "BACKSLASH", "DIMENSION_MODIFIER", "RN_OPTION", "RZ_OPTION", "RM_OPTION",
  "RP_OPTION", "RNI_OPTION", "RZI_OPTION", "RMI_OPTION", "RPI_OPTION",
  "UNI_OPTION", "GEOM_MODIFIER_1D", "GEOM_MODIFIER_2D", "GEOM_MODIFIER_3D",
  "SAT_OPTION", "FTZ_OPTION", "NEG_OPTION", "ATOMIC_AND", "ATOMIC_OR",
  "ATOMIC_XOR", "ATOMIC_CAS", "ATOMIC_EXCH", "ATOMIC_ADD", "ATOMIC_INC",
  "ATOMIC_DEC", "ATOMIC_MIN", "ATOMIC_MAX", "LEFT_ANGLE_BRACKET",
  "RIGHT_ANGLE_BRACKET", "LEFT_PAREN", "RIGHT_PAREN", "APPROX_OPTION",
  "FULL_OPTION", "ANY_OPTION", "ALL_OPTION", "GLOBAL_OPTION", "CTA_OPTION",
  "SYS_OPTION", "EXIT_OPTION", "ABS_OPTION", "TO_OPTION", "CA_OPTION",
  "CG_OPTION", "CS_OPTION", "LU_OPTION", "CV_OPTION", "WB_OPTION",
  "WT_OPTION", "$accept", "input", "function_defn", "$@1", "$@2", "$@3",
  "block_spec", "function_decl", "$@4", "$@5", "$@6",
  "function_ident_param", "$@7", "$@8", "function_decl_header",
  "param_list", "$@9", "param_entry", "$@10", "$@11", "statement_block",
  "statement_list", "directive_statement", "variable_declaration",
  "variable_spec", "identifier_list", "identifier_spec", "var_spec_list",
  "var_spec", "align_spec", "space_spec", "addressable_spec", "type_spec",
  "vector_spec", "scalar_type", "initializer_list", "literal_list",
  "instruction_statement", "instruction", "$@12", "opcode_spec", "$@13",
  "pred_spec", "option_list", "option", "atomic_operation_spec",
  "rounding_mode", "floating_point_rounding_mode", "integer_rounding_mode",
  "compare_spec", "operand_list", "operand", "vector_operand",
  "tex_operand", "$@14", "builtin_operand", "memory_operand",
  "twin_operand", "literal_operand", "address_expression", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,   364,
     365,   366,   367,   368,   369,   370,   371,   372,   373,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,   387,   388,   389,   390,   391,   392,   393,   394,
     395,   396,   397,   398,   399,   400,   401,   402,   403,   404,
     405,   406,   407
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,   153,   154,   154,   154,   154,   156,   155,   157,   158,
     155,   159,   161,   162,   160,   163,   160,   160,   165,   166,
     164,   164,   167,   167,   167,   167,   168,   168,   169,   168,
     171,   170,   172,   170,   173,   174,   174,   174,   174,   174,
     174,   175,   175,   175,   175,   175,   175,   175,   175,   175,
     175,   176,   176,   176,   176,   177,   178,   178,   179,   179,
     179,   179,   180,   180,   181,   181,   181,   181,   182,   183,
     183,   183,   184,   184,   184,   184,   184,   184,   184,   185,
     185,   186,   186,   186,   187,   187,   187,   187,   187,   187,
     187,   187,   187,   187,   187,   187,   187,   187,   187,   187,
     187,   187,   187,   187,   187,   187,   188,   188,   189,   189,
     190,   190,   190,   192,   191,   191,   191,   191,   191,   194,
     193,   193,   195,   195,   195,   195,   195,   195,   195,   195,
     195,   195,   195,   195,   196,   196,   197,   197,   197,   197,
     197,   197,   197,   197,   197,   197,   197,   197,   197,   197,
     197,   197,   197,   197,   197,   197,   197,   197,   197,   197,
     197,   197,   197,   197,   197,   197,   197,   198,   198,   198,
     198,   198,   198,   198,   198,   198,   198,   199,   199,   200,
     200,   200,   200,   201,   201,   201,   201,   202,   202,   202,
     202,   202,   202,   202,   202,   202,   202,   202,   202,   202,
     202,   202,   202,   202,   202,   203,   203,   204,   204,   204,
     204,   204,   204,   204,   204,   204,   204,   204,   204,   204,
     204,   204,   204,   204,   204,   204,   204,   205,   205,   205,
     207,   206,   208,   208,   209,   209,   209,   209,   209,   210,
     210,   210,   210,   210,   210,   210,   211,   211,   211,   212,
     212,   212,   212
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     0,     2,     2,     2,     0,     3,     0,     0,
       5,     6,     0,     0,     7,     0,     3,     1,     0,     0,
       6,     1,     1,     1,     2,     2,     0,     1,     0,     4,
       0,     4,     0,     4,     3,     1,     1,     2,     2,     2,
       1,     2,     2,     3,     2,     4,     6,     2,     3,     4,
       3,     2,     4,     4,     6,     1,     1,     3,     1,     4,
       3,     4,     1,     2,     1,     1,     1,     1,     2,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       2,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     3,     3,     1,     3,
       2,     2,     3,     0,    11,     6,     5,     2,     1,     0,
       3,     1,     2,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     1,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     3,     1,     2,     2,
       1,     1,     1,     1,     2,     1,     3,     2,     3,     2,
       3,     3,     4,     4,     3,     4,     4,     5,     7,     9,
       0,     6,     2,     1,     3,     4,     4,     4,     2,     3,
       4,     4,     4,     5,     5,     4,     1,     1,     1,     1,
       2,     2,     3
};

/* YYDEFACT[STATE-NAME] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       2,     0,     1,     0,    72,     0,    22,    67,     0,    23,
      73,    74,     0,    75,     0,    69,    76,    70,    77,     0,
      78,     0,     0,     0,    84,    85,    86,    87,    88,    89,
      90,    91,    92,    93,    94,    95,    96,    97,    98,    99,
     100,   101,   102,   103,   104,   105,    81,    82,    83,     4,
       5,    17,     3,     0,     0,    55,    62,    66,    64,    71,
      65,     0,    79,    68,     0,    25,     0,     0,     0,    47,
      42,    44,    24,     0,     0,    12,     0,    41,    58,    51,
      56,    67,    63,    80,     0,    48,     0,    50,     0,    43,
       0,     7,     0,     9,     0,    21,    16,     0,     0,     0,
       0,     0,    49,    45,   119,     0,     0,    40,     0,    35,
      36,     0,   118,     0,     0,     0,    30,    32,     0,     0,
       0,    60,     0,    57,   246,   247,   248,     0,    52,    53,
       0,     0,     0,   111,   122,     0,    34,    39,    37,    38,
     110,   207,     0,   233,     0,     0,     0,     0,   117,   205,
     213,   215,   212,   210,   211,     0,     0,    10,     0,     0,
      13,    19,    61,    59,     0,     0,   108,    54,    46,   159,
     187,   188,   189,   190,   191,   192,   193,   194,   195,   196,
     197,   198,   199,   200,   201,   202,   203,   204,   141,   179,
     180,   181,   182,   183,   184,   185,   186,   140,   147,   148,
     149,   150,   151,   152,   167,   168,   169,   170,   171,   172,
     173,   174,   175,   176,   153,   154,   142,   143,   144,   145,
     146,   155,   156,   158,   160,   161,   162,   163,   164,   165,
     166,   138,   136,   120,   134,   157,   139,   177,   178,   137,
     124,   126,   125,   127,   128,   130,   129,   131,   132,   133,
     123,   217,   219,     0,     0,     0,     0,   249,     0,   232,
     209,     0,     0,   214,   238,   208,     0,     0,     0,   112,
       0,     0,     0,     0,    26,   107,     0,   106,   135,   249,
       0,     0,     0,   216,   221,   224,   230,   250,   251,     0,
     234,   218,   220,   249,     0,     0,   113,     0,   206,   205,
       0,    31,    33,    14,     0,    27,   109,     0,   237,   236,
     235,   222,   223,   225,   226,     0,   252,     0,     0,   116,
       0,     0,    11,    28,    20,   239,     0,     0,     0,   227,
       0,   115,     0,   240,   241,   242,   245,   231,     0,     0,
      29,   243,   244,     0,   228,     0,     0,     0,   229,     0,
     114
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     1,    49,    73,    74,   115,    93,    50,    94,   273,
      76,    96,   119,   274,    51,   304,   332,   118,   158,   159,
      91,   108,    52,    53,    54,    79,    80,    55,    56,    57,
      58,    59,    60,    61,    62,   128,   165,   110,   111,   318,
     112,   132,   113,   233,   234,   235,   236,   237,   238,   239,
     298,   299,   150,   151,   315,   152,   153,   280,   154,   258
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -242
static const yytype_int16 yypact[] =
{
    -242,   432,  -242,   -26,  -242,   -21,  -242,    20,    47,  -242,
    -242,  -242,    55,  -242,    96,  -242,  -242,  -242,  -242,   115,
    -242,   125,   129,   154,  -242,  -242,  -242,  -242,  -242,  -242,
    -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,
    -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,
     -13,   -34,  -242,    91,   150,   494,  -242,  -242,  -242,  -242,
    -242,   519,  -242,  -242,   126,  -242,   197,   162,   109,   143,
     117,  -242,  -242,   122,   196,  -242,   187,  -242,    -4,   171,
     166,  -242,  -242,  -242,   190,  -242,   193,  -242,   230,  -242,
     273,  -242,   231,  -242,    67,   137,  -242,   -29,   233,   150,
      -9,   206,  -242,   207,   254,   178,   -14,  -242,   198,  -242,
    -242,   181,   319,   272,   213,   122,  -242,  -242,   146,   148,
     211,  -242,   152,  -242,  -242,  -242,  -242,    -9,  -242,  -242,
     249,   269,    -5,  -242,   311,   274,  -242,  -242,  -242,  -242,
    -242,   298,   275,   204,    63,   276,   302,   331,  -242,   277,
    -242,  -242,  -242,  -242,  -242,   244,   304,  -242,   494,   494,
    -242,  -242,  -242,  -242,   245,    83,  -242,  -242,  -242,  -242,
    -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,
    -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,
    -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,
    -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,
    -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,
    -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,
    -242,  -242,  -242,  -242,    -5,  -242,  -242,  -242,  -242,  -242,
    -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,
    -242,  -242,  -242,   157,   308,   312,   313,    94,   262,  -242,
      95,   317,    92,  -242,  -242,  -242,   294,   227,   325,  -242,
     300,   150,   150,   187,    67,  -242,   165,  -242,  -242,   -62,
     281,   285,   286,  -242,   104,   142,  -242,  -242,  -242,   329,
    -242,  -242,  -242,   103,   288,   342,  -242,    57,  -242,   316,
     346,  -242,  -242,  -242,   -52,  -242,  -242,   -19,  -242,  -242,
    -242,  -242,  -242,  -242,  -242,   291,  -242,    90,   320,  -242,
     255,   331,  -242,  -242,  -242,   161,   -17,   305,   358,  -242,
     331,  -242,    67,  -242,  -242,   189,  -242,  -242,    93,   335,
    -242,  -242,  -242,   366,  -242,   271,   306,   331,  -242,   280,
    -242
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,  -242,
    -242,   133,  -242,  -242,  -242,  -242,  -242,  -241,  -242,  -242,
      59,  -242,   -83,  -242,     4,  -242,   -96,  -242,   353,  -242,
    -242,  -105,   -70,  -242,   348,   284,  -242,   309,   299,  -242,
    -242,  -242,  -242,   194,  -242,  -242,  -242,  -242,  -242,  -242,
    -112,  -111,  -138,  -242,  -242,  -242,  -135,  -242,   -98,   170
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -122
static const yytype_int16 yytable[] =
{
     148,   149,   129,   123,   -15,     4,   263,   109,    -8,   264,
     120,    10,    11,    63,   287,   323,   288,    64,    13,   325,
     316,   335,   336,    16,   134,   138,    18,   231,    20,   166,
     124,   125,   126,   305,   307,    65,   267,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,   232,   121,   169,   170,   171,   172,   173,   174,
     175,   176,   177,   178,   179,   180,   181,   182,   183,   184,
     185,   186,   187,   324,   326,   135,    66,    97,   188,    -6,
     116,   340,   117,   127,    67,   141,   124,   125,   126,    68,
      75,   260,   189,   190,   191,   192,   193,   194,   195,   196,
     197,   198,   199,   200,   201,   202,   203,   204,   205,   206,
     207,   208,   209,   210,   211,   212,   213,   264,    98,   231,
     294,   214,   215,   216,   217,   218,   219,   220,   221,   222,
     223,   224,   225,   226,   227,   228,   229,   230,   142,   107,
     276,   143,   144,    69,   261,   281,   145,   328,   262,   146,
     343,   286,   271,   272,   232,   146,    70,   137,    71,    72,
     287,   291,   288,   292,   157,   301,   302,   327,   306,   287,
     311,   288,   312,   261,   277,   320,   253,   262,    78,    77,
     289,   329,   319,    84,   344,   279,   124,   125,   126,   289,
      85,    86,   104,     3,   124,   125,   126,    87,     4,     5,
      88,    81,     8,    89,    10,    11,    12,    92,   313,   339,
     314,    13,    14,    15,    90,    95,    16,    17,   101,    18,
      19,    20,   102,    21,    22,   349,   105,   333,    99,   334,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    47,    48,   341,   106,   342,   103,   100,
     114,   -18,   122,   130,   131,   133,   104,   104,     3,   140,
     156,   160,   161,     4,     5,   163,    81,     8,   167,    10,
      11,    12,  -121,  -121,  -121,  -121,    13,    14,    15,   136,
      90,    16,    17,   162,    18,    19,    20,   168,    21,    22,
     259,   105,   250,   257,   265,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
     266,   106,   269,   270,   268,  -121,   275,   283,  -121,  -121,
     284,   285,  -121,  -121,   290,   293,  -121,   141,   124,   125,
     126,   295,   296,   141,   124,   125,   126,   300,   316,   141,
     124,   125,   126,   308,   251,    90,   252,   309,   310,   253,
     317,   240,   241,   321,   242,   322,   243,   330,  -121,   253,
     331,   244,   245,   146,   254,   246,   338,   337,   255,   247,
     248,   249,   345,   256,   346,   347,   303,   348,    82,    83,
     142,   164,   155,   143,   144,   350,   142,   139,   145,   143,
     144,   146,   142,   282,   145,   143,   144,   146,   278,     0,
     145,     0,     2,   146,     0,     0,     0,     3,     0,     0,
       0,     0,     4,     5,     6,     7,     8,     9,    10,    11,
      12,     0,     0,   147,     0,    13,    14,    15,     0,   297,
      16,    17,     0,    18,    19,    20,     0,    21,    22,    23,
       0,     0,     0,     0,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,    48,     3,
       0,     0,     0,     0,     4,     0,     0,    81,     0,     0,
      10,    11,     0,     0,     0,     0,     0,    13,     0,    15,
       0,     0,    16,    17,     0,    18,     0,    20,     0,     0,
       0,     0,     0,     0,     0,     0,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    41,    42,    43,    44,    45,    46,    47,
      48,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45
};

#define yypact_value_is_default(yystate) \
  ((yystate) == (-242))

#define yytable_value_is_error(yytable_value) \
  YYID (0)

static const yytype_int16 yycheck[] =
{
     112,   112,   100,    99,    38,    10,   144,    90,    21,   144,
      39,    16,    17,    39,    76,    67,    78,    38,    23,    38,
      39,    38,    39,    28,    38,   108,    31,   132,    33,   127,
      39,    40,    41,   274,    96,    15,   147,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,   132,    92,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,   135,   103,    99,    39,    91,    93,   102,
      23,   332,    25,   102,    39,    38,    39,    40,    41,     3,
     134,    38,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   262,   132,   234,
      38,   136,   137,   138,   139,   140,   141,   142,   143,   144,
     145,   146,   147,   148,   149,   150,   151,   152,    91,    90,
      67,    94,    95,    38,    91,   253,    99,    67,    95,   102,
      67,    67,   158,   159,   234,   102,    41,   108,    39,    15,
      76,    76,    78,    78,   115,   271,   272,   315,   276,    76,
      76,    78,    78,    91,   101,   297,    91,    95,    38,    98,
      96,   101,   135,    67,   101,    38,    39,    40,    41,    96,
       3,    39,     4,     5,    39,    40,    41,    98,    10,    11,
      67,    13,    14,    96,    16,    17,    18,    21,    76,   330,
      78,    23,    24,    25,   102,    38,    28,    29,    38,    31,
      32,    33,    39,    35,    36,   347,    38,    76,    67,    78,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,    63,    64,    65,    66,    76,    68,    78,    38,   103,
      39,   134,    39,    67,    67,    97,     4,     4,     5,    98,
      67,   135,   134,    10,    11,   133,    13,    14,    39,    16,
      17,    18,    38,    39,    40,    41,    23,    24,    25,   101,
     102,    28,    29,    92,    31,    32,    33,    38,    35,    36,
     106,    38,    38,    38,    38,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
      38,    68,    98,    39,    67,    91,   101,    39,    94,    95,
      38,    38,    98,    99,    92,    38,   102,    38,    39,    40,
      41,    67,   135,    38,    39,    40,    41,    67,    39,    38,
      39,    40,    41,    92,    76,   102,    78,    92,    92,    91,
      38,    70,    71,    67,    73,    39,    75,    67,   134,    91,
     135,    80,    81,   102,    96,    84,    38,    92,   100,    88,
      89,    90,    67,   105,    38,   134,   273,   101,    55,    61,
      91,   127,   113,    94,    95,   135,    91,   108,    99,    94,
      95,   102,    91,   253,    99,    94,    95,   102,   234,    -1,
      99,    -1,     0,   102,    -1,    -1,    -1,     5,    -1,    -1,
      -1,    -1,    10,    11,    12,    13,    14,    15,    16,    17,
      18,    -1,    -1,   134,    -1,    23,    24,    25,    -1,   134,
      28,    29,    -1,    31,    32,    33,    -1,    35,    36,    37,
      -1,    -1,    -1,    -1,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,    63,    64,    65,    66,     5,
      -1,    -1,    -1,    -1,    10,    -1,    -1,    13,    -1,    -1,
      16,    17,    -1,    -1,    -1,    -1,    -1,    23,    -1,    25,
      -1,    -1,    28,    29,    -1,    31,    -1,    33,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,    58,    59,    60,    61,    62,    63,    64,    65,
      66,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,    63
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,   154,     0,     5,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    23,    24,    25,    28,    29,    31,    32,
      33,    35,    36,    37,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,    63,    64,    65,    66,   155,
     160,   167,   175,   176,   177,   180,   181,   182,   183,   184,
     185,   186,   187,    39,    38,    15,    39,    39,     3,    38,
      41,    39,    15,   156,   157,   134,   163,    98,    38,   178,
     179,    13,   181,   187,    67,     3,    39,    98,    67,    96,
     102,   173,    21,   159,   161,    38,   164,    91,   132,    67,
     103,    38,    39,    38,     4,    38,    68,   173,   174,   175,
     190,   191,   193,   195,    39,   158,    23,    25,   170,   165,
      39,    92,    39,   179,    39,    40,    41,   102,   188,   211,
      67,    67,   194,    97,    38,    99,   101,   173,   175,   190,
      98,    38,    91,    94,    95,    99,   102,   134,   203,   204,
     205,   206,   208,   209,   211,   191,    67,   173,   171,   172,
     135,   134,    92,   133,   188,   189,   211,    39,    38,    69,
      70,    71,    72,    73,    74,    75,    76,    77,    78,    79,
      80,    81,    82,    83,    84,    85,    86,    87,    93,   107,
     108,   109,   110,   111,   112,   113,   114,   115,   116,   117,
     118,   119,   120,   121,   122,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   136,   137,   138,   139,   140,   141,
     142,   143,   144,   145,   146,   147,   148,   149,   150,   151,
     152,   184,   185,   196,   197,   198,   199,   200,   201,   202,
      70,    71,    73,    75,    80,    81,    84,    88,    89,    90,
      38,    76,    78,    91,    96,   100,   105,    38,   212,   106,
      38,    91,    95,   205,   209,    38,    38,   204,    67,    98,
      39,   177,   177,   162,   166,   101,    67,   101,   196,    38,
     210,   211,   212,    39,    38,    38,    67,    76,    78,    96,
      92,    76,    78,    38,    38,    67,   135,   134,   203,   204,
      67,   179,   179,   164,   168,   170,   211,    96,    92,    92,
      92,    76,    78,    76,    78,   207,    39,    38,   192,   135,
     203,    67,    39,    67,   135,    38,   103,   205,    67,   101,
      67,   135,   169,    76,    78,    38,    39,    92,    38,   204,
     170,    76,    78,    67,   101,    67,    38,   134,   101,   203,
     135
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  However,
   YYFAIL appears to be in use.  Nevertheless, it is formally deprecated
   in Bison 2.4.2's NEWS entry, where a plan to phase it out is
   discussed.  */

#define YYFAIL		goto yyerrlab
#if defined YYFAIL
  /* This is here to suppress warnings from the GCC cpp's
     -Wunused-macros.  Normally we don't worry about that warning, but
     some users do, and we want to make it easy for users to remove
     YYFAIL uses, which will produce warnings from Bison 2.5.  */
#endif

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* This macro is provided for backward compatibility. */

#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
#else
static void
yy_stack_print (yybottom, yytop)
    yytype_int16 *yybottom;
    yytype_int16 *yytop;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYSIZE_T *yymsg_alloc, char **yymsg,
                yytype_int16 *yyssp, int yytoken)
{
  YYSIZE_T yysize0 = yytnamerr (0, yytname[yytoken]);
  YYSIZE_T yysize = yysize0;
  YYSIZE_T yysize1;
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = 0;
  /* Arguments of yyformat. */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Number of reported tokens (one for the "unexpected", one per
     "expected"). */
  int yycount = 0;

  /* There are many possibilities here to consider:
     - Assume YYFAIL is not used.  It's too flawed to consider.  See
       <http://lists.gnu.org/archive/html/bison-patches/2009-12/msg00024.html>
       for details.  YYERROR is fine as it does not invoke this
       function.
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[*yyssp];
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                yysize1 = yysize + yytnamerr (0, yytname[yyx]);
                if (! (yysize <= yysize1
                       && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
                  return 2;
                yysize = yysize1;
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  yysize1 = yysize + yystrlen (yyformat);
  if (! (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
    return 2;
  yysize = yysize1;

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          yyp++;
          yyformat++;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */
#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */


/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;


/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       `yyss': related to states.
       `yyvs': related to semantic values.

       Refer to the stacks thru separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yytoken = 0;
  yyss = yyssa;
  yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */
  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss_alloc, yyss);
	YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 6:

/* Line 1806 of yacc.c  */
#line 211 "../src/cuda-sim/ptx.y"
    { set_symtab((yyvsp[(1) - (1)].ptr_value)); func_header(".skip"); }
    break;

  case 7:

/* Line 1806 of yacc.c  */
#line 211 "../src/cuda-sim/ptx.y"
    { end_function(); }
    break;

  case 8:

/* Line 1806 of yacc.c  */
#line 212 "../src/cuda-sim/ptx.y"
    { set_symtab((yyvsp[(1) - (1)].ptr_value)); }
    break;

  case 9:

/* Line 1806 of yacc.c  */
#line 212 "../src/cuda-sim/ptx.y"
    { func_header(".skip"); }
    break;

  case 10:

/* Line 1806 of yacc.c  */
#line 212 "../src/cuda-sim/ptx.y"
    { end_function(); }
    break;

  case 11:

/* Line 1806 of yacc.c  */
#line 215 "../src/cuda-sim/ptx.y"
    {func_header_info_int(".maxntid", (yyvsp[(2) - (6)].int_value));
										func_header_info_int(",", (yyvsp[(4) - (6)].int_value));
										func_header_info_int(",", (yyvsp[(6) - (6)].int_value)); }
    break;

  case 12:

/* Line 1806 of yacc.c  */
#line 220 "../src/cuda-sim/ptx.y"
    { start_function((yyvsp[(1) - (2)].int_value)); func_header_info("(");}
    break;

  case 13:

/* Line 1806 of yacc.c  */
#line 220 "../src/cuda-sim/ptx.y"
    {func_header_info(")");}
    break;

  case 14:

/* Line 1806 of yacc.c  */
#line 220 "../src/cuda-sim/ptx.y"
    { (yyval.ptr_value) = reset_symtab(); }
    break;

  case 15:

/* Line 1806 of yacc.c  */
#line 221 "../src/cuda-sim/ptx.y"
    { start_function((yyvsp[(1) - (1)].int_value)); }
    break;

  case 16:

/* Line 1806 of yacc.c  */
#line 221 "../src/cuda-sim/ptx.y"
    { (yyval.ptr_value) = reset_symtab(); }
    break;

  case 17:

/* Line 1806 of yacc.c  */
#line 222 "../src/cuda-sim/ptx.y"
    { start_function((yyvsp[(1) - (1)].int_value)); add_function_name(""); g_func_decl=0; (yyval.ptr_value) = reset_symtab(); }
    break;

  case 18:

/* Line 1806 of yacc.c  */
#line 225 "../src/cuda-sim/ptx.y"
    { add_function_name((yyvsp[(1) - (1)].string_value)); }
    break;

  case 19:

/* Line 1806 of yacc.c  */
#line 225 "../src/cuda-sim/ptx.y"
    {func_header_info("(");}
    break;

  case 20:

/* Line 1806 of yacc.c  */
#line 225 "../src/cuda-sim/ptx.y"
    { g_func_decl=0; func_header_info(")"); }
    break;

  case 21:

/* Line 1806 of yacc.c  */
#line 226 "../src/cuda-sim/ptx.y"
    { add_function_name((yyvsp[(1) - (1)].string_value)); g_func_decl=0; }
    break;

  case 22:

/* Line 1806 of yacc.c  */
#line 229 "../src/cuda-sim/ptx.y"
    { (yyval.int_value) = 1; g_func_decl=1; func_header(".entry"); }
    break;

  case 23:

/* Line 1806 of yacc.c  */
#line 230 "../src/cuda-sim/ptx.y"
    { (yyval.int_value) = 0; g_func_decl=1; func_header(".func"); }
    break;

  case 24:

/* Line 1806 of yacc.c  */
#line 231 "../src/cuda-sim/ptx.y"
    { (yyval.int_value) = 0; g_func_decl=1; func_header(".func"); }
    break;

  case 25:

/* Line 1806 of yacc.c  */
#line 232 "../src/cuda-sim/ptx.y"
    { (yyval.int_value) = 2; g_func_decl=1; func_header(".func"); }
    break;

  case 27:

/* Line 1806 of yacc.c  */
#line 236 "../src/cuda-sim/ptx.y"
    { add_directive(); }
    break;

  case 28:

/* Line 1806 of yacc.c  */
#line 237 "../src/cuda-sim/ptx.y"
    {func_header_info(",");}
    break;

  case 29:

/* Line 1806 of yacc.c  */
#line 237 "../src/cuda-sim/ptx.y"
    { add_directive(); }
    break;

  case 30:

/* Line 1806 of yacc.c  */
#line 239 "../src/cuda-sim/ptx.y"
    { add_space_spec(param_space_unclassified,0); }
    break;

  case 31:

/* Line 1806 of yacc.c  */
#line 239 "../src/cuda-sim/ptx.y"
    { add_function_arg(); }
    break;

  case 32:

/* Line 1806 of yacc.c  */
#line 240 "../src/cuda-sim/ptx.y"
    { add_space_spec(reg_space,0); }
    break;

  case 33:

/* Line 1806 of yacc.c  */
#line 240 "../src/cuda-sim/ptx.y"
    { add_function_arg(); }
    break;

  case 35:

/* Line 1806 of yacc.c  */
#line 244 "../src/cuda-sim/ptx.y"
    { add_directive(); }
    break;

  case 36:

/* Line 1806 of yacc.c  */
#line 245 "../src/cuda-sim/ptx.y"
    { add_instruction(); }
    break;

  case 37:

/* Line 1806 of yacc.c  */
#line 246 "../src/cuda-sim/ptx.y"
    { add_directive(); }
    break;

  case 38:

/* Line 1806 of yacc.c  */
#line 247 "../src/cuda-sim/ptx.y"
    { add_instruction(); }
    break;

  case 42:

/* Line 1806 of yacc.c  */
#line 253 "../src/cuda-sim/ptx.y"
    { add_version_info((yyvsp[(2) - (2)].double_value), 0); }
    break;

  case 43:

/* Line 1806 of yacc.c  */
#line 254 "../src/cuda-sim/ptx.y"
    { add_version_info((yyvsp[(2) - (3)].double_value),1); }
    break;

  case 44:

/* Line 1806 of yacc.c  */
#line 255 "../src/cuda-sim/ptx.y"
    {/*Do nothing*/}
    break;

  case 45:

/* Line 1806 of yacc.c  */
#line 256 "../src/cuda-sim/ptx.y"
    { target_header2((yyvsp[(2) - (4)].string_value),(yyvsp[(4) - (4)].string_value)); }
    break;

  case 46:

/* Line 1806 of yacc.c  */
#line 257 "../src/cuda-sim/ptx.y"
    { target_header3((yyvsp[(2) - (6)].string_value),(yyvsp[(4) - (6)].string_value),(yyvsp[(6) - (6)].string_value)); }
    break;

  case 47:

/* Line 1806 of yacc.c  */
#line 258 "../src/cuda-sim/ptx.y"
    { target_header((yyvsp[(2) - (2)].string_value)); }
    break;

  case 48:

/* Line 1806 of yacc.c  */
#line 259 "../src/cuda-sim/ptx.y"
    { add_file((yyvsp[(2) - (3)].int_value),(yyvsp[(3) - (3)].string_value)); }
    break;

  case 50:

/* Line 1806 of yacc.c  */
#line 261 "../src/cuda-sim/ptx.y"
    { add_pragma((yyvsp[(2) - (3)].string_value)); }
    break;

  case 51:

/* Line 1806 of yacc.c  */
#line 264 "../src/cuda-sim/ptx.y"
    { add_variables(); }
    break;

  case 52:

/* Line 1806 of yacc.c  */
#line 265 "../src/cuda-sim/ptx.y"
    { add_variables(); }
    break;

  case 53:

/* Line 1806 of yacc.c  */
#line 266 "../src/cuda-sim/ptx.y"
    { add_variables(); }
    break;

  case 54:

/* Line 1806 of yacc.c  */
#line 267 "../src/cuda-sim/ptx.y"
    { add_constptr((yyvsp[(2) - (6)].string_value), (yyvsp[(4) - (6)].string_value), (yyvsp[(6) - (6)].int_value)); }
    break;

  case 55:

/* Line 1806 of yacc.c  */
#line 270 "../src/cuda-sim/ptx.y"
    { set_variable_type(); }
    break;

  case 58:

/* Line 1806 of yacc.c  */
#line 275 "../src/cuda-sim/ptx.y"
    { add_identifier((yyvsp[(1) - (1)].string_value),0,NON_ARRAY_IDENTIFIER); func_header_info((yyvsp[(1) - (1)].string_value));}
    break;

  case 59:

/* Line 1806 of yacc.c  */
#line 276 "../src/cuda-sim/ptx.y"
    { func_header_info((yyvsp[(1) - (4)].string_value)); func_header_info_int("<", (yyvsp[(3) - (4)].int_value)); func_header_info(">");
		int i,lbase,l;
		char *id = NULL;
		lbase = strlen((yyvsp[(1) - (4)].string_value));
		for( i=0; i < (yyvsp[(3) - (4)].int_value); i++ ) { 
			l = lbase + (int)log10(i+1)+10;
			id = (char*) malloc(l);
			snprintf(id,l,"%s%u",(yyvsp[(1) - (4)].string_value),i);
			add_identifier(id,0,NON_ARRAY_IDENTIFIER); 
		}
		free((yyvsp[(1) - (4)].string_value));
	}
    break;

  case 60:

/* Line 1806 of yacc.c  */
#line 288 "../src/cuda-sim/ptx.y"
    { add_identifier((yyvsp[(1) - (3)].string_value),0,ARRAY_IDENTIFIER_NO_DIM); func_header_info((yyvsp[(1) - (3)].string_value)); func_header_info("["); func_header_info("]");}
    break;

  case 61:

/* Line 1806 of yacc.c  */
#line 289 "../src/cuda-sim/ptx.y"
    { add_identifier((yyvsp[(1) - (4)].string_value),(yyvsp[(3) - (4)].int_value),ARRAY_IDENTIFIER); func_header_info((yyvsp[(1) - (4)].string_value)); func_header_info_int("[",(yyvsp[(3) - (4)].int_value)); func_header_info("]");}
    break;

  case 67:

/* Line 1806 of yacc.c  */
#line 298 "../src/cuda-sim/ptx.y"
    { add_extern_spec(); }
    break;

  case 68:

/* Line 1806 of yacc.c  */
#line 301 "../src/cuda-sim/ptx.y"
    { add_alignment_spec((yyvsp[(2) - (2)].int_value)); }
    break;

  case 69:

/* Line 1806 of yacc.c  */
#line 303 "../src/cuda-sim/ptx.y"
    {  add_space_spec(reg_space,0); }
    break;

  case 70:

/* Line 1806 of yacc.c  */
#line 304 "../src/cuda-sim/ptx.y"
    {  add_space_spec(reg_space,0); }
    break;

  case 72:

/* Line 1806 of yacc.c  */
#line 308 "../src/cuda-sim/ptx.y"
    {  add_space_spec(const_space,(yyvsp[(1) - (1)].int_value)); }
    break;

  case 73:

/* Line 1806 of yacc.c  */
#line 309 "../src/cuda-sim/ptx.y"
    {  add_space_spec(global_space,0); }
    break;

  case 74:

/* Line 1806 of yacc.c  */
#line 310 "../src/cuda-sim/ptx.y"
    {  add_space_spec(local_space,0); }
    break;

  case 75:

/* Line 1806 of yacc.c  */
#line 311 "../src/cuda-sim/ptx.y"
    {  add_space_spec(param_space_unclassified,0); }
    break;

  case 76:

/* Line 1806 of yacc.c  */
#line 312 "../src/cuda-sim/ptx.y"
    {  add_space_spec(shared_space,0); }
    break;

  case 77:

/* Line 1806 of yacc.c  */
#line 313 "../src/cuda-sim/ptx.y"
    {  add_space_spec(surf_space,0); }
    break;

  case 78:

/* Line 1806 of yacc.c  */
#line 314 "../src/cuda-sim/ptx.y"
    {  add_space_spec(tex_space,0); }
    break;

  case 81:

/* Line 1806 of yacc.c  */
#line 321 "../src/cuda-sim/ptx.y"
    {  add_option(V2_TYPE); func_header_info(".v2");}
    break;

  case 82:

/* Line 1806 of yacc.c  */
#line 322 "../src/cuda-sim/ptx.y"
    {  add_option(V3_TYPE); func_header_info(".v3");}
    break;

  case 83:

/* Line 1806 of yacc.c  */
#line 323 "../src/cuda-sim/ptx.y"
    {  add_option(V4_TYPE); func_header_info(".v4");}
    break;

  case 84:

/* Line 1806 of yacc.c  */
#line 326 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( S8_TYPE ); }
    break;

  case 85:

/* Line 1806 of yacc.c  */
#line 327 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( S16_TYPE ); }
    break;

  case 86:

/* Line 1806 of yacc.c  */
#line 328 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( S32_TYPE ); }
    break;

  case 87:

/* Line 1806 of yacc.c  */
#line 329 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( S64_TYPE ); }
    break;

  case 88:

/* Line 1806 of yacc.c  */
#line 330 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( U8_TYPE ); }
    break;

  case 89:

/* Line 1806 of yacc.c  */
#line 331 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( U16_TYPE ); }
    break;

  case 90:

/* Line 1806 of yacc.c  */
#line 332 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( U32_TYPE ); }
    break;

  case 91:

/* Line 1806 of yacc.c  */
#line 333 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( U64_TYPE ); }
    break;

  case 92:

/* Line 1806 of yacc.c  */
#line 334 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( F16_TYPE ); }
    break;

  case 93:

/* Line 1806 of yacc.c  */
#line 335 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( F32_TYPE ); }
    break;

  case 94:

/* Line 1806 of yacc.c  */
#line 336 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( F64_TYPE ); }
    break;

  case 95:

/* Line 1806 of yacc.c  */
#line 337 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( FF64_TYPE ); }
    break;

  case 96:

/* Line 1806 of yacc.c  */
#line 338 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( B8_TYPE );  }
    break;

  case 97:

/* Line 1806 of yacc.c  */
#line 339 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( B16_TYPE ); }
    break;

  case 98:

/* Line 1806 of yacc.c  */
#line 340 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( B32_TYPE ); }
    break;

  case 99:

/* Line 1806 of yacc.c  */
#line 341 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( B64_TYPE ); }
    break;

  case 100:

/* Line 1806 of yacc.c  */
#line 342 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( BB64_TYPE ); }
    break;

  case 101:

/* Line 1806 of yacc.c  */
#line 343 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( BB128_TYPE ); }
    break;

  case 102:

/* Line 1806 of yacc.c  */
#line 344 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( PRED_TYPE ); }
    break;

  case 103:

/* Line 1806 of yacc.c  */
#line 345 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( TEXREF_TYPE ); }
    break;

  case 104:

/* Line 1806 of yacc.c  */
#line 346 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( SAMPLERREF_TYPE ); }
    break;

  case 105:

/* Line 1806 of yacc.c  */
#line 347 "../src/cuda-sim/ptx.y"
    { add_scalar_type_spec( SURFREF_TYPE ); }
    break;

  case 106:

/* Line 1806 of yacc.c  */
#line 350 "../src/cuda-sim/ptx.y"
    { add_array_initializer(); }
    break;

  case 107:

/* Line 1806 of yacc.c  */
#line 351 "../src/cuda-sim/ptx.y"
    { syntax_not_implemented(); }
    break;

  case 111:

/* Line 1806 of yacc.c  */
#line 357 "../src/cuda-sim/ptx.y"
    { add_label((yyvsp[(1) - (2)].string_value)); }
    break;

  case 113:

/* Line 1806 of yacc.c  */
#line 360 "../src/cuda-sim/ptx.y"
    { set_return(); }
    break;

  case 119:

/* Line 1806 of yacc.c  */
#line 367 "../src/cuda-sim/ptx.y"
    { add_opcode((yyvsp[(1) - (1)].int_value)); }
    break;

  case 121:

/* Line 1806 of yacc.c  */
#line 368 "../src/cuda-sim/ptx.y"
    { add_opcode((yyvsp[(1) - (1)].int_value)); }
    break;

  case 122:

/* Line 1806 of yacc.c  */
#line 370 "../src/cuda-sim/ptx.y"
    { add_pred((yyvsp[(2) - (2)].string_value),0, -1); }
    break;

  case 123:

/* Line 1806 of yacc.c  */
#line 371 "../src/cuda-sim/ptx.y"
    { add_pred((yyvsp[(3) - (3)].string_value),1, -1); }
    break;

  case 124:

/* Line 1806 of yacc.c  */
#line 372 "../src/cuda-sim/ptx.y"
    { add_pred((yyvsp[(2) - (3)].string_value),0,2); }
    break;

  case 125:

/* Line 1806 of yacc.c  */
#line 373 "../src/cuda-sim/ptx.y"
    { add_pred((yyvsp[(2) - (3)].string_value),0,3); }
    break;

  case 126:

/* Line 1806 of yacc.c  */
#line 374 "../src/cuda-sim/ptx.y"
    { add_pred((yyvsp[(2) - (3)].string_value),0,5); }
    break;

  case 127:

/* Line 1806 of yacc.c  */
#line 375 "../src/cuda-sim/ptx.y"
    { add_pred((yyvsp[(2) - (3)].string_value),0,6); }
    break;

  case 128:

/* Line 1806 of yacc.c  */
#line 376 "../src/cuda-sim/ptx.y"
    { add_pred((yyvsp[(2) - (3)].string_value),0,10); }
    break;

  case 129:

/* Line 1806 of yacc.c  */
#line 377 "../src/cuda-sim/ptx.y"
    { add_pred((yyvsp[(2) - (3)].string_value),0,12); }
    break;

  case 130:

/* Line 1806 of yacc.c  */
#line 378 "../src/cuda-sim/ptx.y"
    { add_pred((yyvsp[(2) - (3)].string_value),0,13); }
    break;

  case 131:

/* Line 1806 of yacc.c  */
#line 379 "../src/cuda-sim/ptx.y"
    { add_pred((yyvsp[(2) - (3)].string_value),0,17); }
    break;

  case 132:

/* Line 1806 of yacc.c  */
#line 380 "../src/cuda-sim/ptx.y"
    { add_pred((yyvsp[(2) - (3)].string_value),0,19); }
    break;

  case 133:

/* Line 1806 of yacc.c  */
#line 381 "../src/cuda-sim/ptx.y"
    { add_pred((yyvsp[(2) - (3)].string_value),0,28); }
    break;

  case 140:

/* Line 1806 of yacc.c  */
#line 391 "../src/cuda-sim/ptx.y"
    { add_option(UNI_OPTION); }
    break;

  case 141:

/* Line 1806 of yacc.c  */
#line 392 "../src/cuda-sim/ptx.y"
    { add_option(WIDE_OPTION); }
    break;

  case 142:

/* Line 1806 of yacc.c  */
#line 393 "../src/cuda-sim/ptx.y"
    { add_option(ANY_OPTION); }
    break;

  case 143:

/* Line 1806 of yacc.c  */
#line 394 "../src/cuda-sim/ptx.y"
    { add_option(ALL_OPTION); }
    break;

  case 144:

/* Line 1806 of yacc.c  */
#line 395 "../src/cuda-sim/ptx.y"
    { add_option(GLOBAL_OPTION); }
    break;

  case 145:

/* Line 1806 of yacc.c  */
#line 396 "../src/cuda-sim/ptx.y"
    { add_option(CTA_OPTION); }
    break;

  case 146:

/* Line 1806 of yacc.c  */
#line 397 "../src/cuda-sim/ptx.y"
    { add_option(SYS_OPTION); }
    break;

  case 147:

/* Line 1806 of yacc.c  */
#line 398 "../src/cuda-sim/ptx.y"
    { add_option(GEOM_MODIFIER_1D); }
    break;

  case 148:

/* Line 1806 of yacc.c  */
#line 399 "../src/cuda-sim/ptx.y"
    { add_option(GEOM_MODIFIER_2D); }
    break;

  case 149:

/* Line 1806 of yacc.c  */
#line 400 "../src/cuda-sim/ptx.y"
    { add_option(GEOM_MODIFIER_3D); }
    break;

  case 150:

/* Line 1806 of yacc.c  */
#line 401 "../src/cuda-sim/ptx.y"
    { add_option(SAT_OPTION); }
    break;

  case 151:

/* Line 1806 of yacc.c  */
#line 402 "../src/cuda-sim/ptx.y"
    { add_option(FTZ_OPTION); }
    break;

  case 152:

/* Line 1806 of yacc.c  */
#line 403 "../src/cuda-sim/ptx.y"
    { add_option(NEG_OPTION); }
    break;

  case 153:

/* Line 1806 of yacc.c  */
#line 404 "../src/cuda-sim/ptx.y"
    { add_option(APPROX_OPTION); }
    break;

  case 154:

/* Line 1806 of yacc.c  */
#line 405 "../src/cuda-sim/ptx.y"
    { add_option(FULL_OPTION); }
    break;

  case 155:

/* Line 1806 of yacc.c  */
#line 406 "../src/cuda-sim/ptx.y"
    { add_option(EXIT_OPTION); }
    break;

  case 156:

/* Line 1806 of yacc.c  */
#line 407 "../src/cuda-sim/ptx.y"
    { add_option(ABS_OPTION); }
    break;

  case 158:

/* Line 1806 of yacc.c  */
#line 409 "../src/cuda-sim/ptx.y"
    { add_option(TO_OPTION); }
    break;

  case 159:

/* Line 1806 of yacc.c  */
#line 410 "../src/cuda-sim/ptx.y"
    { add_option(HALF_OPTION); }
    break;

  case 160:

/* Line 1806 of yacc.c  */
#line 411 "../src/cuda-sim/ptx.y"
    { add_option(CA_OPTION); }
    break;

  case 161:

/* Line 1806 of yacc.c  */
#line 412 "../src/cuda-sim/ptx.y"
    { add_option(CG_OPTION); }
    break;

  case 162:

/* Line 1806 of yacc.c  */
#line 413 "../src/cuda-sim/ptx.y"
    { add_option(CS_OPTION); }
    break;

  case 163:

/* Line 1806 of yacc.c  */
#line 414 "../src/cuda-sim/ptx.y"
    { add_option(LU_OPTION); }
    break;

  case 164:

/* Line 1806 of yacc.c  */
#line 415 "../src/cuda-sim/ptx.y"
    { add_option(CV_OPTION); }
    break;

  case 165:

/* Line 1806 of yacc.c  */
#line 416 "../src/cuda-sim/ptx.y"
    { add_option(WB_OPTION); }
    break;

  case 166:

/* Line 1806 of yacc.c  */
#line 417 "../src/cuda-sim/ptx.y"
    { add_option(WT_OPTION); }
    break;

  case 167:

/* Line 1806 of yacc.c  */
#line 420 "../src/cuda-sim/ptx.y"
    { add_option(ATOMIC_AND); }
    break;

  case 168:

/* Line 1806 of yacc.c  */
#line 421 "../src/cuda-sim/ptx.y"
    { add_option(ATOMIC_OR); }
    break;

  case 169:

/* Line 1806 of yacc.c  */
#line 422 "../src/cuda-sim/ptx.y"
    { add_option(ATOMIC_XOR); }
    break;

  case 170:

/* Line 1806 of yacc.c  */
#line 423 "../src/cuda-sim/ptx.y"
    { add_option(ATOMIC_CAS); }
    break;

  case 171:

/* Line 1806 of yacc.c  */
#line 424 "../src/cuda-sim/ptx.y"
    { add_option(ATOMIC_EXCH); }
    break;

  case 172:

/* Line 1806 of yacc.c  */
#line 425 "../src/cuda-sim/ptx.y"
    { add_option(ATOMIC_ADD); }
    break;

  case 173:

/* Line 1806 of yacc.c  */
#line 426 "../src/cuda-sim/ptx.y"
    { add_option(ATOMIC_INC); }
    break;

  case 174:

/* Line 1806 of yacc.c  */
#line 427 "../src/cuda-sim/ptx.y"
    { add_option(ATOMIC_DEC); }
    break;

  case 175:

/* Line 1806 of yacc.c  */
#line 428 "../src/cuda-sim/ptx.y"
    { add_option(ATOMIC_MIN); }
    break;

  case 176:

/* Line 1806 of yacc.c  */
#line 429 "../src/cuda-sim/ptx.y"
    { add_option(ATOMIC_MAX); }
    break;

  case 179:

/* Line 1806 of yacc.c  */
#line 435 "../src/cuda-sim/ptx.y"
    { add_option(RN_OPTION); }
    break;

  case 180:

/* Line 1806 of yacc.c  */
#line 436 "../src/cuda-sim/ptx.y"
    { add_option(RZ_OPTION); }
    break;

  case 181:

/* Line 1806 of yacc.c  */
#line 437 "../src/cuda-sim/ptx.y"
    { add_option(RM_OPTION); }
    break;

  case 182:

/* Line 1806 of yacc.c  */
#line 438 "../src/cuda-sim/ptx.y"
    { add_option(RP_OPTION); }
    break;

  case 183:

/* Line 1806 of yacc.c  */
#line 441 "../src/cuda-sim/ptx.y"
    { add_option(RNI_OPTION); }
    break;

  case 184:

/* Line 1806 of yacc.c  */
#line 442 "../src/cuda-sim/ptx.y"
    { add_option(RZI_OPTION); }
    break;

  case 185:

/* Line 1806 of yacc.c  */
#line 443 "../src/cuda-sim/ptx.y"
    { add_option(RMI_OPTION); }
    break;

  case 186:

/* Line 1806 of yacc.c  */
#line 444 "../src/cuda-sim/ptx.y"
    { add_option(RPI_OPTION); }
    break;

  case 187:

/* Line 1806 of yacc.c  */
#line 447 "../src/cuda-sim/ptx.y"
    { add_option(EQ_OPTION); }
    break;

  case 188:

/* Line 1806 of yacc.c  */
#line 448 "../src/cuda-sim/ptx.y"
    { add_option(NE_OPTION); }
    break;

  case 189:

/* Line 1806 of yacc.c  */
#line 449 "../src/cuda-sim/ptx.y"
    { add_option(LT_OPTION); }
    break;

  case 190:

/* Line 1806 of yacc.c  */
#line 450 "../src/cuda-sim/ptx.y"
    { add_option(LE_OPTION); }
    break;

  case 191:

/* Line 1806 of yacc.c  */
#line 451 "../src/cuda-sim/ptx.y"
    { add_option(GT_OPTION); }
    break;

  case 192:

/* Line 1806 of yacc.c  */
#line 452 "../src/cuda-sim/ptx.y"
    { add_option(GE_OPTION); }
    break;

  case 193:

/* Line 1806 of yacc.c  */
#line 453 "../src/cuda-sim/ptx.y"
    { add_option(LO_OPTION); }
    break;

  case 194:

/* Line 1806 of yacc.c  */
#line 454 "../src/cuda-sim/ptx.y"
    { add_option(LS_OPTION); }
    break;

  case 195:

/* Line 1806 of yacc.c  */
#line 455 "../src/cuda-sim/ptx.y"
    { add_option(HI_OPTION); }
    break;

  case 196:

/* Line 1806 of yacc.c  */
#line 456 "../src/cuda-sim/ptx.y"
    { add_option(HS_OPTION); }
    break;

  case 197:

/* Line 1806 of yacc.c  */
#line 457 "../src/cuda-sim/ptx.y"
    { add_option(EQU_OPTION); }
    break;

  case 198:

/* Line 1806 of yacc.c  */
#line 458 "../src/cuda-sim/ptx.y"
    { add_option(NEU_OPTION); }
    break;

  case 199:

/* Line 1806 of yacc.c  */
#line 459 "../src/cuda-sim/ptx.y"
    { add_option(LTU_OPTION); }
    break;

  case 200:

/* Line 1806 of yacc.c  */
#line 460 "../src/cuda-sim/ptx.y"
    { add_option(LEU_OPTION); }
    break;

  case 201:

/* Line 1806 of yacc.c  */
#line 461 "../src/cuda-sim/ptx.y"
    { add_option(GTU_OPTION); }
    break;

  case 202:

/* Line 1806 of yacc.c  */
#line 462 "../src/cuda-sim/ptx.y"
    { add_option(GEU_OPTION); }
    break;

  case 203:

/* Line 1806 of yacc.c  */
#line 463 "../src/cuda-sim/ptx.y"
    { add_option(NUM_OPTION); }
    break;

  case 204:

/* Line 1806 of yacc.c  */
#line 464 "../src/cuda-sim/ptx.y"
    { add_option(NAN_OPTION); }
    break;

  case 207:

/* Line 1806 of yacc.c  */
#line 470 "../src/cuda-sim/ptx.y"
    { add_scalar_operand( (yyvsp[(1) - (1)].string_value) ); }
    break;

  case 208:

/* Line 1806 of yacc.c  */
#line 471 "../src/cuda-sim/ptx.y"
    { add_neg_pred_operand( (yyvsp[(2) - (2)].string_value) ); }
    break;

  case 209:

/* Line 1806 of yacc.c  */
#line 472 "../src/cuda-sim/ptx.y"
    { add_scalar_operand( (yyvsp[(2) - (2)].string_value) ); change_operand_neg(); }
    break;

  case 214:

/* Line 1806 of yacc.c  */
#line 477 "../src/cuda-sim/ptx.y"
    { change_operand_neg(); }
    break;

  case 216:

/* Line 1806 of yacc.c  */
#line 479 "../src/cuda-sim/ptx.y"
    { add_address_operand((yyvsp[(1) - (3)].string_value),(yyvsp[(3) - (3)].int_value)); }
    break;

  case 217:

/* Line 1806 of yacc.c  */
#line 480 "../src/cuda-sim/ptx.y"
    { add_scalar_operand( (yyvsp[(1) - (2)].string_value) ); change_operand_lohi(1);}
    break;

  case 218:

/* Line 1806 of yacc.c  */
#line 481 "../src/cuda-sim/ptx.y"
    { add_scalar_operand( (yyvsp[(2) - (3)].string_value) ); change_operand_lohi(1); change_operand_neg();}
    break;

  case 219:

/* Line 1806 of yacc.c  */
#line 482 "../src/cuda-sim/ptx.y"
    { add_scalar_operand( (yyvsp[(1) - (2)].string_value) ); change_operand_lohi(2);}
    break;

  case 220:

/* Line 1806 of yacc.c  */
#line 483 "../src/cuda-sim/ptx.y"
    { add_scalar_operand( (yyvsp[(2) - (3)].string_value) ); change_operand_lohi(2); change_operand_neg();}
    break;

  case 221:

/* Line 1806 of yacc.c  */
#line 484 "../src/cuda-sim/ptx.y"
    { add_2vector_operand((yyvsp[(1) - (3)].string_value),(yyvsp[(3) - (3)].string_value)); change_double_operand_type(-1);}
    break;

  case 222:

/* Line 1806 of yacc.c  */
#line 485 "../src/cuda-sim/ptx.y"
    { add_2vector_operand((yyvsp[(1) - (4)].string_value),(yyvsp[(3) - (4)].string_value)); change_double_operand_type(-1); change_operand_lohi(1);}
    break;

  case 223:

/* Line 1806 of yacc.c  */
#line 486 "../src/cuda-sim/ptx.y"
    { add_2vector_operand((yyvsp[(1) - (4)].string_value),(yyvsp[(3) - (4)].string_value)); change_double_operand_type(-1); change_operand_lohi(2);}
    break;

  case 224:

/* Line 1806 of yacc.c  */
#line 487 "../src/cuda-sim/ptx.y"
    { add_2vector_operand((yyvsp[(1) - (3)].string_value),(yyvsp[(3) - (3)].string_value)); change_double_operand_type(-3);}
    break;

  case 225:

/* Line 1806 of yacc.c  */
#line 488 "../src/cuda-sim/ptx.y"
    { add_2vector_operand((yyvsp[(1) - (4)].string_value),(yyvsp[(3) - (4)].string_value)); change_double_operand_type(-3); change_operand_lohi(1);}
    break;

  case 226:

/* Line 1806 of yacc.c  */
#line 489 "../src/cuda-sim/ptx.y"
    { add_2vector_operand((yyvsp[(1) - (4)].string_value),(yyvsp[(3) - (4)].string_value)); change_double_operand_type(-3); change_operand_lohi(2);}
    break;

  case 227:

/* Line 1806 of yacc.c  */
#line 492 "../src/cuda-sim/ptx.y"
    { add_2vector_operand((yyvsp[(2) - (5)].string_value),(yyvsp[(4) - (5)].string_value)); }
    break;

  case 228:

/* Line 1806 of yacc.c  */
#line 493 "../src/cuda-sim/ptx.y"
    { add_3vector_operand((yyvsp[(2) - (7)].string_value),(yyvsp[(4) - (7)].string_value),(yyvsp[(6) - (7)].string_value)); }
    break;

  case 229:

/* Line 1806 of yacc.c  */
#line 494 "../src/cuda-sim/ptx.y"
    { add_4vector_operand((yyvsp[(2) - (9)].string_value),(yyvsp[(4) - (9)].string_value),(yyvsp[(6) - (9)].string_value),(yyvsp[(8) - (9)].string_value)); }
    break;

  case 230:

/* Line 1806 of yacc.c  */
#line 497 "../src/cuda-sim/ptx.y"
    { add_scalar_operand((yyvsp[(2) - (3)].string_value)); }
    break;

  case 232:

/* Line 1806 of yacc.c  */
#line 501 "../src/cuda-sim/ptx.y"
    { add_builtin_operand((yyvsp[(1) - (2)].int_value),(yyvsp[(2) - (2)].int_value)); }
    break;

  case 233:

/* Line 1806 of yacc.c  */
#line 502 "../src/cuda-sim/ptx.y"
    { add_builtin_operand((yyvsp[(1) - (1)].int_value),-1); }
    break;

  case 234:

/* Line 1806 of yacc.c  */
#line 505 "../src/cuda-sim/ptx.y"
    { add_memory_operand(); }
    break;

  case 235:

/* Line 1806 of yacc.c  */
#line 506 "../src/cuda-sim/ptx.y"
    { add_memory_operand(); change_memory_addr_space((yyvsp[(1) - (4)].string_value)); }
    break;

  case 236:

/* Line 1806 of yacc.c  */
#line 507 "../src/cuda-sim/ptx.y"
    { change_memory_addr_space((yyvsp[(1) - (4)].string_value)); }
    break;

  case 237:

/* Line 1806 of yacc.c  */
#line 508 "../src/cuda-sim/ptx.y"
    { change_memory_addr_space((yyvsp[(1) - (4)].string_value)); add_memory_operand();}
    break;

  case 238:

/* Line 1806 of yacc.c  */
#line 509 "../src/cuda-sim/ptx.y"
    { change_operand_neg(); }
    break;

  case 239:

/* Line 1806 of yacc.c  */
#line 512 "../src/cuda-sim/ptx.y"
    { add_double_operand((yyvsp[(1) - (3)].string_value),(yyvsp[(3) - (3)].string_value)); change_double_operand_type(1); }
    break;

  case 240:

/* Line 1806 of yacc.c  */
#line 513 "../src/cuda-sim/ptx.y"
    { add_double_operand((yyvsp[(1) - (4)].string_value),(yyvsp[(3) - (4)].string_value)); change_double_operand_type(1); change_operand_lohi(1); }
    break;

  case 241:

/* Line 1806 of yacc.c  */
#line 514 "../src/cuda-sim/ptx.y"
    { add_double_operand((yyvsp[(1) - (4)].string_value),(yyvsp[(3) - (4)].string_value)); change_double_operand_type(1); change_operand_lohi(2); }
    break;

  case 242:

/* Line 1806 of yacc.c  */
#line 515 "../src/cuda-sim/ptx.y"
    { add_double_operand((yyvsp[(1) - (4)].string_value),(yyvsp[(4) - (4)].string_value)); change_double_operand_type(2); }
    break;

  case 243:

/* Line 1806 of yacc.c  */
#line 516 "../src/cuda-sim/ptx.y"
    { add_double_operand((yyvsp[(1) - (5)].string_value),(yyvsp[(4) - (5)].string_value)); change_double_operand_type(2); change_operand_lohi(1); }
    break;

  case 244:

/* Line 1806 of yacc.c  */
#line 517 "../src/cuda-sim/ptx.y"
    { add_double_operand((yyvsp[(1) - (5)].string_value),(yyvsp[(4) - (5)].string_value)); change_double_operand_type(2); change_operand_lohi(2); }
    break;

  case 245:

/* Line 1806 of yacc.c  */
#line 518 "../src/cuda-sim/ptx.y"
    { add_address_operand((yyvsp[(1) - (4)].string_value),(yyvsp[(4) - (4)].int_value)); change_double_operand_type(3); }
    break;

  case 246:

/* Line 1806 of yacc.c  */
#line 521 "../src/cuda-sim/ptx.y"
    { add_literal_int((yyvsp[(1) - (1)].int_value)); }
    break;

  case 247:

/* Line 1806 of yacc.c  */
#line 522 "../src/cuda-sim/ptx.y"
    { add_literal_float((yyvsp[(1) - (1)].float_value)); }
    break;

  case 248:

/* Line 1806 of yacc.c  */
#line 523 "../src/cuda-sim/ptx.y"
    { add_literal_double((yyvsp[(1) - (1)].double_value)); }
    break;

  case 249:

/* Line 1806 of yacc.c  */
#line 526 "../src/cuda-sim/ptx.y"
    { add_address_operand((yyvsp[(1) - (1)].string_value),0); }
    break;

  case 250:

/* Line 1806 of yacc.c  */
#line 527 "../src/cuda-sim/ptx.y"
    { add_address_operand((yyvsp[(1) - (2)].string_value),0); change_operand_lohi(1);}
    break;

  case 251:

/* Line 1806 of yacc.c  */
#line 528 "../src/cuda-sim/ptx.y"
    { add_address_operand((yyvsp[(1) - (2)].string_value),0); change_operand_lohi(2); }
    break;

  case 252:

/* Line 1806 of yacc.c  */
#line 529 "../src/cuda-sim/ptx.y"
    { add_address_operand((yyvsp[(1) - (3)].string_value),(yyvsp[(3) - (3)].int_value)); }
    break;



/* Line 1806 of yacc.c  */
#line 3430 "ptx.tab.c"
      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = (char *) YYSTACK_ALLOC (yymsg_alloc);
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined(yyoverflow) || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}



/* Line 2067 of yacc.c  */
#line 532 "../src/cuda-sim/ptx.y"


extern int ptx_lineno;
extern const char *g_filename;

void syntax_not_implemented()
{
	printf("Parse error (%s:%u): this syntax is not (yet) implemented:\n",g_filename,ptx_lineno);
	ptx_error(NULL);
	abort();
}

