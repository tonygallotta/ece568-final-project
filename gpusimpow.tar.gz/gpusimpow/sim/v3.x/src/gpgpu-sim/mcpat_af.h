/*
 * mcpat_af.h
 *
 *  Created on: May 18, 2012
 *      Author: sohan
 */

#ifndef MCPAT_AF_H_
#define MCPAT_AF_H_
#include <stdio.h>
//#include <string>
//using namespace std;
class l1_activity{
public:
	long long af_l1_miss,af_l1_access,af_l1_pendingHit;
};

class l2_activity{
public:
	long long af_l2_miss,af_l2_access,af_l2_pendingHit;
};

class dram_activity{
public:
	float  af_bnk_pre_percent,af_cke_lo_pre_percent,af_cke_lo_act_percent,af_tRRDsch,af_rdsch_percent,af_wrsch_percent;
	unsigned int af_n_cmd,af_n_nop,af_n_act,af_n_pre,af_n_req,af_n_rd,af_n_wr,af_n_activity,af_max_mrqq;
	float af_bw_util,af_dram_eff,af_avg_mrqq;

	const dram_activity operator-(const dram_activity &other) const
	{
		dram_activity res;
		res.af_n_cmd = af_n_cmd - other.af_n_cmd;
		res.af_n_rd = af_n_rd - other.af_n_rd;
		res.af_n_wr = af_n_wr - other.af_n_wr;
		res.af_n_nop = af_n_nop - other.af_n_nop;
		return res;
	}

	void reset(){
		af_n_rd=0;
		af_n_wr=0;
		af_n_cmd=0;
		af_rdsch_percent=0;
		af_wrsch_percent=0;
	}
};

class activity_factor{
public:
	// General activity

	const char *kernel_name;
	long long af_general_total_instructions,af_general_branch_instructions,af_general_total_cycles, af_tpc_active_cycles, af_sm_active_cycles; 	// Number of branch instructions executed
	long long af_total_warp_divergence,af_total_warp_divergence_old, af_total_warp_divergence_new;// total warp divergences w1-w31
	long long af_num_load_ins,af_num_store_ins,af_num_shmem_ins,af_num_tex_ins,af_num_const_ins,af_num_param_ins;

	//Register File
	long long af_rf_reads,af_rf_writes;

	//Instruction buffer
	long long af_ib_reads,af_ib_writes,af_ib_ready_flag_reads;

	//SIMT Stack
	long long af_recstack_reads,af_recstack_writes;

	//Scoreboard
	long long af_scoreboard_reads,af_scoreboard_writes;

	// instruction cache
	long long af_ic_accesses,af_ic_hits,af_ic_misses,af_ic_rf;

	// L1 Cache
	long long af_l1_total_misses,af_l1_total_accesses;
	float af_l1_total_miss_rate;

	//L2 Cache
	long long af_l2_total_misses,af_l2_total_hits,af_l2_total_accesses;
	float af_l2_total_miss_rate;

	//Constant Memory
	long long af_cmem_reads,af_cmem_writes,af_cmem_accesses;

	//Shared Memory
	long long af_shmem_reads,af_shmem_writes,af_shmem_accesses;

	//Global Memory
	long long af_general_gmem_instructions,af_generated_gmem_accesses,af_generated_gmem_reads,af_generated_gmem_writes;

	//DRAM
	long long af_mc_reads,af_mc_writes;
	long long af_total_rd,af_total_wr,af_total_cmd;

	// Cores
	long long af_sp_ins,af_sfu_ins,af_mem_ins;
	long long af_int_instructions,af_float_instructions,af_sfu_instructions;
	long long af_int_add,af_int_sub,af_int_mul,af_int_div,af_int_logical,af_int_max_min,af_int_mov;
	long long af_float_add,af_float_sub,af_float_mul,af_float_div,af_float_logical,af_float_max_min,af_float_mov;
	//NUM_OPCODES = 86,start_index=297, max_index=315
	long long af_int_operations[128][24];
	long long af_float_operations[128][24];

	//NOCs
	long long af_noc_total_accesses;

	// Flags
	bool l1_cache_activity;

	// counters
	int ithSM,n_mem_partition,ithMemoryPartition;

	//constructor
	activity_factor(){
		//TODO: Make it generic
		m_l1_activity = new l1_activity[16];
		m_l2_activity = new l2_activity[6];
		m_dram_act= new dram_activity[6];
		m_dram_act_old= new dram_activity[6];
		m_dram_act_new= new dram_activity[6];
		for (int i=0; i < 6 ; i++) {
			m_dram_act_old[i].reset();
			m_dram_act_new[i].reset();
			m_dram_act[i].reset();
		}
		kernel_name=NULL;

		//Register File
		af_rf_reads=0;
		af_rf_writes=0;


		af_ic_accesses=0;
		af_ic_hits=0;
		af_ic_misses=0;
		af_ic_rf=0;

		//L1 total cache stats
		af_l1_total_misses=0;
		af_l1_total_accesses=0;
		af_l1_total_miss_rate=0;

		//L2 total cache stats
		af_l2_total_misses=0;
		af_l2_total_hits=0;
		af_l2_total_accesses=0;
		af_l2_total_miss_rate=0;

		//DRAM
		af_generated_gmem_reads=0;
		af_generated_gmem_writes=0;
		af_general_gmem_instructions=0;
		af_generated_gmem_accesses=0;

		//DRAM
		af_mc_reads=0;
		af_mc_writes=0;
		af_total_rd=0;
		af_total_wr=0;
		af_total_cmd=0;

		af_int_instructions=0;
		af_float_instructions=0;
		af_sfu_instructions=0;
		af_int_add=0;
		af_int_sub=0;
		af_int_mul=0;
		af_int_div=0;
		af_int_logical=0;
		af_int_max_min=0;
		af_int_mov=0;
		af_float_add=0;
		af_float_sub=0;
		af_float_mul=0;
		af_float_div=0;
		af_float_logical=0;
		af_float_max_min=0;
		af_float_mov=0;
		memset(af_int_operations,0, sizeof(af_int_operations));


		af_general_total_instructions=0;
		af_tpc_active_cycles=0;
		af_sm_active_cycles=0;
		af_general_total_cycles=0;
		af_general_branch_instructions=0;
		af_total_warp_divergence=0;
		af_total_warp_divergence_old=0;
		af_total_warp_divergence_new=0;
		af_num_load_ins=0;
		af_num_store_ins=0;
		af_num_shmem_ins=0;
		af_num_tex_ins=0;
		af_num_const_ins=0;
		af_num_param_ins=0;

		af_ib_reads=0;
		af_ib_writes=0;
		af_ib_ready_flag_reads=0;

		af_recstack_reads=0;
		af_recstack_writes=0;

		af_scoreboard_reads=0;
		af_scoreboard_writes=0;

		af_sp_ins=0;
		af_sfu_ins=0;
		af_mem_ins=0;

		//NOC
		af_noc_total_accesses=0;

		//counters
		ithSM=0;
		n_mem_partition=0;
		ithMemoryPartition=0;

		//Flags
		l1_cache_activity=true;
	}


	class l1_activity* m_l1_activity;
	class l2_activity* m_l2_activity;
	class dram_activity* m_dram_act;
	class dram_activity* m_dram_act_old;
	class dram_activity* m_dram_act_new;

	void reset(){
		kernel_name=NULL;

		af_rf_reads=0;
		af_rf_writes=0;

		af_ic_accesses=0;
		af_ic_hits=0;
		af_ic_misses=0;
		af_ic_rf=0;

		//L1 total cache stats
		af_l1_total_misses=0;
		af_l1_total_accesses=0;
		af_l1_total_miss_rate=0;

		//L2 total cache stats
		af_l2_total_misses=0;
		af_l2_total_hits=0;
		af_l2_total_accesses=0;
		af_l2_total_miss_rate=0;

		//DRAM
		af_generated_gmem_reads=0;
		af_generated_gmem_writes=0;
		af_general_gmem_instructions=0;
		af_generated_gmem_accesses=0;

		//DRAM
		af_mc_reads=0;
		af_mc_writes=0;
		af_total_rd=0;
		af_total_wr=0;
		af_total_cmd=0;

		af_int_instructions=0;
		af_float_instructions=0;
		af_sfu_instructions=0;
		memset(af_int_operations,0, sizeof(af_int_operations));

		af_general_total_instructions=0;
		af_tpc_active_cycles=0;
		af_sm_active_cycles=0;
		af_general_total_cycles=0;
		af_general_branch_instructions=0;
		af_total_warp_divergence=0;
		af_num_load_ins=0;
		af_num_store_ins=0;
		af_num_shmem_ins=0;
		af_num_tex_ins=0;
		af_num_const_ins=0;
		af_num_param_ins=0;

		af_ib_reads=0;
		af_ib_writes=0;
		af_ib_ready_flag_reads=0;

		af_recstack_reads=0;
		af_recstack_writes=0;

		af_scoreboard_reads=0;
		af_scoreboard_writes=0;

		af_sp_ins=0;
		af_sfu_ins=0;
		af_mem_ins=0;

		//NOC
		af_noc_total_accesses=0;

		//counters used as array indexes.
		//TODO: Find a better way
		ithSM=0;
		n_mem_partition=0;
		ithMemoryPartition=0;

		//Flags
		l1_cache_activity=true;
	}

	//Destructor
	~activity_factor(){

		if (m_l1_activity) delete m_l1_activity;m_l1_activity=0;
		if(m_l2_activity) delete m_l2_activity;m_l2_activity=0;
		if(m_dram_act) delete m_dram_act;m_dram_act=0;
	}

};

extern activity_factor  aff;
//activity_factor  aff;


#endif /* MCPAT_AF_H_ */
