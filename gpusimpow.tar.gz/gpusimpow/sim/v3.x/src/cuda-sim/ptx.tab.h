/* A Bison parser, made by GNU Bison 2.5.  */

/* Bison interface for Yacc-like parsers in C
   
      Copyright (C) 1984, 1989-1990, 2000-2011 Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     STRING = 258,
     OPCODE = 259,
     ALIGN_DIRECTIVE = 260,
     BRANCHTARGETS_DIRECTIVE = 261,
     BYTE_DIRECTIVE = 262,
     CALLPROTOTYPE_DIRECTIVE = 263,
     CALLTARGETS_DIRECTIVE = 264,
     CONST_DIRECTIVE = 265,
     CONSTPTR_DIRECTIVE = 266,
     ENTRY_DIRECTIVE = 267,
     EXTERN_DIRECTIVE = 268,
     FILE_DIRECTIVE = 269,
     FUNC_DIRECTIVE = 270,
     GLOBAL_DIRECTIVE = 271,
     LOCAL_DIRECTIVE = 272,
     LOC_DIRECTIVE = 273,
     MAXNCTAPERSM_DIRECTIVE = 274,
     MAXNNREG_DIRECTIVE = 275,
     MAXNTID_DIRECTIVE = 276,
     MINNCTAPERSM_DIRECTIVE = 277,
     PARAM_DIRECTIVE = 278,
     PRAGMA_DIRECTIVE = 279,
     REG_DIRECTIVE = 280,
     REQNTID_DIRECTIVE = 281,
     SECTION_DIRECTIVE = 282,
     SHARED_DIRECTIVE = 283,
     SREG_DIRECTIVE = 284,
     STRUCT_DIRECTIVE = 285,
     SURF_DIRECTIVE = 286,
     TARGET_DIRECTIVE = 287,
     TEX_DIRECTIVE = 288,
     UNION_DIRECTIVE = 289,
     VERSION_DIRECTIVE = 290,
     ADDRESS_SIZE_DIRECTIVE = 291,
     VISIBLE_DIRECTIVE = 292,
     IDENTIFIER = 293,
     INT_OPERAND = 294,
     FLOAT_OPERAND = 295,
     DOUBLE_OPERAND = 296,
     S8_TYPE = 297,
     S16_TYPE = 298,
     S32_TYPE = 299,
     S64_TYPE = 300,
     U8_TYPE = 301,
     U16_TYPE = 302,
     U32_TYPE = 303,
     U64_TYPE = 304,
     F16_TYPE = 305,
     F32_TYPE = 306,
     F64_TYPE = 307,
     FF64_TYPE = 308,
     B8_TYPE = 309,
     B16_TYPE = 310,
     B32_TYPE = 311,
     B64_TYPE = 312,
     BB64_TYPE = 313,
     BB128_TYPE = 314,
     PRED_TYPE = 315,
     TEXREF_TYPE = 316,
     SAMPLERREF_TYPE = 317,
     SURFREF_TYPE = 318,
     V2_TYPE = 319,
     V3_TYPE = 320,
     V4_TYPE = 321,
     COMMA = 322,
     PRED = 323,
     HALF_OPTION = 324,
     EQ_OPTION = 325,
     NE_OPTION = 326,
     LT_OPTION = 327,
     LE_OPTION = 328,
     GT_OPTION = 329,
     GE_OPTION = 330,
     LO_OPTION = 331,
     LS_OPTION = 332,
     HI_OPTION = 333,
     HS_OPTION = 334,
     EQU_OPTION = 335,
     NEU_OPTION = 336,
     LTU_OPTION = 337,
     LEU_OPTION = 338,
     GTU_OPTION = 339,
     GEU_OPTION = 340,
     NUM_OPTION = 341,
     NAN_OPTION = 342,
     CF_OPTION = 343,
     SF_OPTION = 344,
     NSF_OPTION = 345,
     LEFT_SQUARE_BRACKET = 346,
     RIGHT_SQUARE_BRACKET = 347,
     WIDE_OPTION = 348,
     SPECIAL_REGISTER = 349,
     MINUS = 350,
     PLUS = 351,
     COLON = 352,
     SEMI_COLON = 353,
     EXCLAMATION = 354,
     PIPE = 355,
     RIGHT_BRACE = 356,
     LEFT_BRACE = 357,
     EQUALS = 358,
     PERIOD = 359,
     BACKSLASH = 360,
     DIMENSION_MODIFIER = 361,
     RN_OPTION = 362,
     RZ_OPTION = 363,
     RM_OPTION = 364,
     RP_OPTION = 365,
     RNI_OPTION = 366,
     RZI_OPTION = 367,
     RMI_OPTION = 368,
     RPI_OPTION = 369,
     UNI_OPTION = 370,
     GEOM_MODIFIER_1D = 371,
     GEOM_MODIFIER_2D = 372,
     GEOM_MODIFIER_3D = 373,
     SAT_OPTION = 374,
     FTZ_OPTION = 375,
     NEG_OPTION = 376,
     ATOMIC_AND = 377,
     ATOMIC_OR = 378,
     ATOMIC_XOR = 379,
     ATOMIC_CAS = 380,
     ATOMIC_EXCH = 381,
     ATOMIC_ADD = 382,
     ATOMIC_INC = 383,
     ATOMIC_DEC = 384,
     ATOMIC_MIN = 385,
     ATOMIC_MAX = 386,
     LEFT_ANGLE_BRACKET = 387,
     RIGHT_ANGLE_BRACKET = 388,
     LEFT_PAREN = 389,
     RIGHT_PAREN = 390,
     APPROX_OPTION = 391,
     FULL_OPTION = 392,
     ANY_OPTION = 393,
     ALL_OPTION = 394,
     GLOBAL_OPTION = 395,
     CTA_OPTION = 396,
     SYS_OPTION = 397,
     EXIT_OPTION = 398,
     ABS_OPTION = 399,
     TO_OPTION = 400,
     CA_OPTION = 401,
     CG_OPTION = 402,
     CS_OPTION = 403,
     LU_OPTION = 404,
     CV_OPTION = 405,
     WB_OPTION = 406,
     WT_OPTION = 407
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 2068 of yacc.c  */
#line 30 "ptx.y"

  double double_value;
  float  float_value;
  int    int_value;
  char * string_value;
  void * ptr_value;



/* Line 2068 of yacc.c  */
#line 212 "ptx.tab.h"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE ptx_lval;


