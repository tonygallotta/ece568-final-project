#! /usr/bin/python

import os;
import sys;

settings={}

argscan=1;
config_file="gpusimpow.conf";
if len(sys.argv) > 1:
	if sys.argv[argscan] == "-h" or sys.argv[argscan] == "--help":
		print("Usage: ./generate_config_files <config_base_filename>");
		print("If no base config file is specified, gpusimpow.conf is used!");
		sys.exit();
	if sys.argv[argscan] == "-i" or sys.argv[argscan] == "--input":
		config_file = sys.argv[argscan+1];
		argscan = argscan + 2;

print("Generating config files for "+config_file+"...");
		
for line in open(config_file,"r").readlines():
	line = line.strip()
	line_list = line.split()
	if ((not line.startswith("#")) and (not len(line_list) < 2)):
		settings[ line_list[0].lower() ] = line_list[1]

settings["number_of_cluster"]= int(settings["number_of_sm"])/int(settings["sm_per_cluster"])
settings["gpu_core_warps_in_fligh"]= int(settings["threads_per_shader"])/int(settings["gpu_threads_per_warp"])
settings["simulated_clock"]= int(settings["shader_clock"])/int(settings["gpu_clock_to_sim_clock"])
settings["gpu_ic_sets"]= int(settings["gpu_ic_size"])/(int(settings["gpu_ic_line"])*int(settings["gpu_ic_assoc"]))
#settings["noc_k"] = int(settings["number_of_cluster"])+int(settings["number_mcs"])

template_files = ["gpgpusim.conf_template", "gpgpupow.xml_template", "icnt_config_quadro_islip.txt_template" ]
for template_file in template_files:
	output_filename = str.replace(template_file,"_template","")
	output_file = open( output_filename,"w");
	
	for line in open(template_file,"r").readlines():
		escape = False;
		for substr in line.split("@@"):
			if escape:
				output_file.write(str(settings[ substr.lower() ]))
			else:
				output_file.write(str(substr))
			escape = not escape
	print("Generated file: "+output_filename);
