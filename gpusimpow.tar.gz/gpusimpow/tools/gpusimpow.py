#! /usr/bin/python

import os;
import sys;
import threading;
import multiprocessing;
from termcolor import colored;

first=True;
card = "gt240"
kname= [];
argscan = 1;
o_print = -1;

def insert_into_template( i, afs ,name):
	fname='temp/mcpat_'+ '_' + name  +'_'+str(i)+'.xml';
	print("Writing config and activities to "+fname);
	output = open(fname,'w+');
	for line in open('../tools/gpgpupow.xml','r').readlines():
		if line[:3] == "***":
			for line2 in afs:
				output.write(line2);				
		else:
			output.write(line);
	output.close();
	return;

def parse_mcpat(n,name,kname):
	k=0;
	buffer = [];
	fname='output/output_'+'_'+name+'_'+`n`+'.txt';
	print("Parsing and reordering GPGPUPow output from "+fname);
	for line in open(fname).readlines():
		if line[:1] == "@":
			k=9;
		if k>0:
			k=k-1;
			buffer.extend( [line] );
	results={};
	for line in buffer:
		a=line.split("=");
		results[a[0].strip()]=a[1].strip().split()[0];
	results["Method"]=kname;
	results["Name"]=name;
	return results;


def print_mcpat(n,name,kname):
	state_changes = [ 
   ("System:","SYSTEM"),
   ("GDDR:","GDDR"),
	("Processor:","CPU"),
	("Total Clusters","ROOT"), 
	("Core:","CORE"),
	("Warp Control Unit:","ROOT") ];
	colors = [ ("Total Leakage","SYSTEM","green"), 
				  ("Runtime Power","SYSTEM","red") ];
	curstate = "ROOT";

	fname='output/output_'+'_'+name+'_'+`n`+'.txt';
	print("Writing GPGPUPow output to "+fname);
	for line in open(fname).readlines():
		for keyword, state in state_changes: 
			if keyword in line:
				curstate = state;
		printed = False;
		for keyword, state, color in colors:
			if (keyword in line) and (state == curstate):
				print colored(line,color),
				printed = True;	
		if not printed:
			print line,
	return;




class mcpat_thread(threading.Thread):
	def __init__(self, n, max, offset,name):		
		self.n=n;
		self.max=max;
		self.pos=offset;
		self.benchname=name;
		threading.Thread.__init__(self);

	def run(self):
		while self.pos < self.max:
			print("Launching GPGPUPow instance ...");
		        os.system('../pow/gpgpupow -infile temp/mcpat_'+'_'+self.benchname +'_'+ str(self.pos) + '.xml -print_level 2 > output/output_'+'_'+self.benchname +'_'+`self.pos`+'.txt');
			self.pos = self.pos + self.n;
			

def process_file(output,root,dirs,name,first):
	af = [];	
	kernels={};
	kname=[];
	n=0;

	filename_path=os.path.join(root,name)
	print("Parsing activity file "+filename_path);
	for line in open(filename_path,'r').readlines():		
		if line[:3] == "***":	
			if line.find("Kernel Name") != -1:		
				kname.append(line.split("=")[1].split()[0]);
			else:
				insert_into_template(n,af,name.split(".")[0]);
				af = [];
				n = n + 1;
		else:
			af.append(line);
	n_cores = multiprocessing.cpu_count();
	if n_cores > n:
		n_cores = n;
	threads = [];
	for i in range(n_cores):					
		t=mcpat_thread(n_cores,n,i,name.split(".")[0]);
		t.start();
		threads.append(t);	
	for t in threads:
		t.join();
	for i in range(n):
		result=parse_mcpat(i,name.split(".")[0],kname);
		if kernels.has_key(kname[i]):
			r=kernels[kname[i]];
			r["n"]=r["n"]+1;
			r["Runtime Dynamic"]=float(r["Runtime Dynamic"])+float(result["Runtime Dynamic"]);
			r["Execution Time"]=float(r["Execution Time"])+float(result["Execution Time"]);
			kernels[kname[i]]=r;
		else:
			result["idx"]=n;
			result["n"]=1;
			kernels[kname[i]]=result;
	kernels_list = [];			
	for kern in kernels.itervalues():
		kernels_list.append(kern);
	if first:
		output.write("#area:"+kernels_list[0]["Area"]+"\n");
		output.write("#pdynamic:"+kernels_list[0]["Peak Dynamic"]+"\n");
		output.write("#leakage:"+kernels_list[0]["Total Leakage"]+"\n"); 
	for kern in sorted(kernels_list, key=lambda kern: kern["idx"]):
		n = int(kern["n"]);
		output.write(kern["Name"] + ":" + str(float(kern["Execution Time"])/n) + "," + str(float(kern["Runtime Dynamic"])/n)+"\n");
	if o_print != -1:
		print_mcpat(o_print-1,name.split(".")[0],kname);

if sys.argv[argscan] == "-h" or sys.argv[argscan] == "--help":
	print("Usage: ./gpusimpow.py <options> gpgpusim_activity_file");
	print("gpgpusim_activity_file must be the .xml file produced by GPGPU-Sim!");
	print("<options>:");
	print("-p, --print <num>: Directly print the output for the numth kernel");
	print("-b, --batch <folder>: Will process all the .xml activity files in the given folder");
	sys.exit();	
		
if sys.argv[argscan] == "-p" or sys.argv[argscan] == "--print":
	o_print = int(sys.argv[argscan+1]);
	argscan = argscan + 2;

if sys.argv[argscan] == "-b" or sys.argv[argscan] == "--batch":
	output = open("result.txt", "w+");
	print("Batch processing ...");
	for root, dirs, files in os.walk(sys.argv[argscan+1]):
		for name in files:
			if name.endswith(".xml"):
				print("Processing file "+name+" ...");
				process_file(output, root, dirs, name, first);
				if first:
					first = False;
	output.close();
	sys.exit();

# No batch processing
output = open("result.txt", "w+");
name = sys.argv[argscan];
root = "./";
dirs = "";
first = True;
print("Processing activity file "+name+" ...");
process_file(output, root, dirs, name, first);
output.close();
sys.exit();

