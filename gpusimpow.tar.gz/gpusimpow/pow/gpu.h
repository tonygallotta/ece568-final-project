/*
 * File: gpu.h
 * -----------
 * Contains definitions of GPU control structures.
 * 
 * Written by Michael Andersch, TUB, 2012.
 */

#ifndef GPU_H_
#define GPU_H_

#include "XML_Parse.h"
#include "logic.h"
#include "parameter.h"
#include "array.h"
#include "interconnect.h"
#include "basic_components.h"
#include "sharedcache.h"
#include "crossbar.h"

#define I_CACHE_ACCESS_ALLOW_BIT (1)
#define VALID_BIT (1)
#define READY_BIT (1)
#define WARP_BARRIERED_BIT (1)

#define REQ_SIZE_DESIGNATOR (3)

#define EXTRA_ADDRESSABLE_CONSTMEM_BITS 2

#define LDSTU_CLK_MULT 2
#define LDSTU_WSIZE_MOD LDSTU_CLK_MULT

#define CACHE_BANKS_L1 4

class scheduling_logic : public Component {
public:
	scheduling_logic(bool _is_default, int  core_num_warps_,
		            int  issue_width_, const InputParameter *configure_interface,
		            enum Device_ty device_ty_=Core_device,
		            enum Core_type core_ty_=Inorder);
	bool is_default;
	InputParameter l_ip;
	uca_org_t local_result;
	int issue_width;
	int core_num_warps;
	enum Device_ty device_ty;
	enum Core_type core_ty;

	void computeEnergy();
};

class WarpControlU :public Component {
  public:
	ParseXML *XML;
	int  ithCore;
	InputParameter interface_ip;
	CoreDynParam  coredynp;
	double clockRate,executionTime;
	ArrayST         * warp_status_table;
	ArrayST         * reconvergence_stacks;
	ArrayST         * instruction_buffer;
	ArrayST         * scoreboard;
	ArrayST         * ic;
	scheduling_logic * warp_selection;
	scheduling_logic * issue_selection;
	inst_decoder    * opcode_decoder;
	inst_decoder    * regs_decoder;
	inst_decoder    * misc_decoder;

	bool exist;

	WarpControlU(ParseXML *XML_interface, int ithCore_, InputParameter* interface_ip_,const CoreDynParam & dyn_p_, bool exist_=true);
	void computeEnergy(bool is_tdp=true);
	void displayEnergy(uint32_t indent = 0,int plevel = 100, bool is_tdp=true);
	~WarpControlU() {
	  if(warp_status_table) {delete warp_status_table; warp_status_table=0;}
	  if(reconvergence_stacks) {delete reconvergence_stacks; reconvergence_stacks=0;}
	  if(instruction_buffer) {delete instruction_buffer; instruction_buffer=0;}
	  if(scoreboard) {delete scoreboard; scoreboard=0;}
	  if(warp_selection) {delete warp_selection; warp_selection = 0;}
	  if(issue_selection) {delete issue_selection; issue_selection = 0;}
	  if(opcode_decoder) {delete opcode_decoder; opcode_decoder = 0;}
	  if(regs_decoder) {delete regs_decoder; regs_decoder = 0;}
	  if(misc_decoder) {delete misc_decoder; misc_decoder = 0;}
	  if( ic) {delete  ic;  ic = 0;}
	};
};

class FunctionalUnit_gpu : public Component {
public:
	ParseXML *XML;
	int  ithCore;
	InputParameter interface_ip;
	CoreDynParam  coredynp;
	double clockRate,executionTime;
	double FU_height;
	double num_fu;
	double energy, base_energy,per_access_energy, leakage, gate_leakage;
	bool  is_default;
	enum FU_type fu_type;
	statsDef       tdp_stats;
	statsDef       rtp_stats;
	statsDef       stats_t;
	//powerDef       power_t;

	int frequency_index;
	bool single_precision;

	// Area and power number for FMA from Energy Efficient FPU design paper
	// For Single precison 45nm process
	/* double fpu_area_power_sp[][] = {
			{2.08,16077,1.2,30.9},
			{1.32,14241,0.55,12.85},
			{0.98,12670,0.58,8.09},
			{0.50,12117,0.16,3.16},
			{0.2,10619,0.0358,0.952}
	};

	// For double precision 45nm process
	 double fpu_area_power_dp[][] = {
			{1.81,49839,4.6,95.9},
			{0.95,42019,1.8,29.2},
			{0.33,35058,0.4,5.6},
			{0.2,36747,0.13,3.23}
	};*/

	FunctionalUnit_gpu(ParseXML *XML_interface, int ithCore_, InputParameter* interface_ip_,const CoreDynParam & dyn_p_, enum FU_type fu_type);
	void computeEnergy(bool is_tdp=true);
	void displayEnergy(uint32_t indent,int plevel,bool is_tdp=true);
	~FunctionalUnit_gpu();

};

class CudaCore :public Component {
  public:

	ParseXML *XML;
	int  ithCore;
	InputParameter interface_ip;
	double clockRate,executionTime;
	double scktRatio, chip_PR_overhead, macro_PR_overhead;
	double lsq_height;
	CoreDynParam  coredynp;
	FunctionalUnit_gpu * fpu_g;
    FunctionalUnit_gpu * iu_g;
    FunctionalUnit_gpu * sfu_g;
	bool exist;

	CudaCore(ParseXML *XML_interface, int ithCore_, InputParameter* interface_ip_, const CoreDynParam & dyn_p_, bool exist_=true);
    void computeEnergy(bool is_tdp=true);
	void displayEnergy(uint32_t indent = 0,int plevel = 100, bool is_tdp=true);
	~CudaCore();
};

class gpu_register_file : public Component {
public:
	ParseXML *XML;
	gpu_register_file(ParseXML* XML_interface, int ithCore_, InputParameter* interface_ip_, const CoreDynParam & dyn_p_, bool exist_=true);

	int m_registers;
	int m_banks;
	int m_ports;
	int m_width;

	ArrayST	*memory_bank;
	Crossbar *cb;
	ArrayST *lane_op_collector;
	
	InputParameter interface_ip;
	double clockRate, executionTime;
	CoreDynParam  coredynp;

	void computeEnergy(bool is_tdp=true);
	void displayEnergy(uint32_t indent = 0,int plevel = 100, bool is_tdp=true);
};

class CudaCoreBase :public Component {
  public:
	ParseXML *XML;
	CoreDynParam  coredynp;
	double clockRate, executionTime;
	CudaCoreBase(ParseXML *XML_interface);
	void displayEnergy(uint32_t indent = 0,int plevel = 100, bool is_tdp=true);
};

class ConstantCache : public Component {
public:
	ParseXML *XML;
	int  ithCore;
	InputParameter interface_ip;
	CoreDynParam  coredynp;
	double clockRate, executionTime;

	bool existL3;

	ArrayST* L1;
	ArrayST* L2;
	ArrayST* L3;

	ConstantCache(ParseXML *XML_interface, int ithCore_, InputParameter* interface_ip_, const CoreDynParam& dyn_p_);
	void computeEnergy(bool is_tdp=true);
	void displayEnergy(uint32_t indent = 0, int plevel = 100, bool is_tdp = true);
};

class L2Cache : public Component {
public:
	ParseXML *XML;
	int  ithCore;
	InputParameter interface_ip;
	CoreDynParam  coredynp;
	double clockRate, executionTime;

	//bool existL2;

	ArrayST* L2;

	L2Cache(ParseXML *XML_interface, int ithCore_, InputParameter* interface_ip_, const CoreDynParam& dyn_p_);
	void computeEnergy(bool is_tdp=true);
	void displayEnergy(uint32_t indent = 0, int plevel = 100, bool is_tdp = true);
};

class CoalescingU : public Component {
public:
	CoalescingU(ParseXML *XML_interface, int ithCore_, InputParameter* interface_ip_,const CoreDynParam & dyn_p_, bool exist_=true);

	ParseXML *XML;
	int  ithCore;
	InputParameter interface_ip;
	CoreDynParam  coredynp;
	double clockRate,executionTime;
	bool exist;

	ArrayST* PRT;
	ArrayST* IncomingReqQ;
	ArrayST* OutgoingReqQ;

	scheduling_logic* PRTSelector;
	scheduling_logic* ThreadSelector;

	void computeEnergy(bool is_tdp=true);
	void displayEnergy(uint32_t indent = 0,int plevel = 100, bool is_tdp=true);

	~CoalescingU() {
	  if(PRT) {delete PRT; PRT=0;}
	  if(IncomingReqQ) {delete IncomingReqQ; IncomingReqQ=0;}
	  if(OutgoingReqQ) {delete OutgoingReqQ; OutgoingReqQ=0;}
	  if(PRTSelector) {delete PRTSelector; PRTSelector=0;}
	  if(ThreadSelector) {delete ThreadSelector; ThreadSelector = 0;}
	};
};

class DFFCoalescingU : public Component {
public:
	DFFCoalescingU(ParseXML *XML_interface, int ithCore_, InputParameter* interface_ip_,const CoreDynParam & dyn_p_, bool exist_=true, enum Device_ty device_ty_=Core_device);

	ParseXML *XML;
	int  ithCore;
	InputParameter l_ip;
	enum Device_ty device_ty;
	CoreDynParam  coredynp;
	double clockRate,executionTime;
	bool exist;

	double WNANDn, WNANDp, cell_load, num_cells;

	scheduling_logic* PRTSelector;
	scheduling_logic* ThreadSelector;

	void computeEnergy(bool is_tdp=true);
	void displayEnergy(uint32_t indent = 0,int plevel = 100, bool is_tdp=true);

	~DFFCoalescingU() {
	  if(PRTSelector) {delete PRTSelector; PRTSelector=0;}
	  if(ThreadSelector) {delete ThreadSelector; ThreadSelector = 0;}
	};
};

class SharedMemory : public Component {
public:
	ParseXML *XML;
	int ithCore;

	int m_registers;
	int num_banks;
	int size;
	int in_ports_di,out_ports_di,width_di;
	int in_ports_ai,out_ports_ai,width_ai;

	bool exist;

	ArrayST	*shmem_bank;
	Crossbar *data_interconnect;
	Crossbar *address_interconnect;
	DFFCoalescingU *acl; // shared memory address conflict check logic is similar in structure to coalescing logic
	InputParameter interface_ip;
	double clockRate, executionTime;
	CoreDynParam  coredynp;
	SharedMemory(ParseXML* XML_interface, int ithCore_, InputParameter* interface_ip_, const CoreDynParam & dyn_p_, bool exist_=true);
	void computeEnergy(bool is_tdp=true);
	void displayEnergy(uint32_t indent = 0,int plevel = 100, bool is_tdp=true);
	~SharedMemory(){
		if(shmem_bank){delete shmem_bank;shmem_bank=0;}
		if(data_interconnect){delete data_interconnect;data_interconnect=0;}
		if(address_interconnect){delete address_interconnect;address_interconnect=0;}
		if(acl){delete acl;acl=0;}
	}
};


class AddressGenerationU : public Component {
public:
	ParseXML *XML;
	int ithCore;
	InputParameter l_ip;
	enum Device_ty device_ty;
	CoreDynParam coredynp;
	double clockRate, executionTime;
	double WNANDn, WNANDp, cell_load;
	bool exist;
	int instances;
	
	AddressGenerationU(ParseXML *XML_interface, int ithCore_, InputParameter* interface_ip_, const CoreDynParam & dyn_p_, bool exist_=true, int instances_ = 8, enum Device_ty device_ty_=Core_device);
	
	void computeEnergy(bool is_tdp = true);
	void displayEnergy(uint32_t indent = 0, int plevel = 100, bool is_tdp = true);
};

class TextureCache : public Component {
public:
	ParseXML *XML;
	int  ithCore;
	InputParameter interface_ip;
	CoreDynParam  coredynp;
	bool exist;
	
	double clockRate, executionTime;
	
	int TMUsPerCore;
	int lineSizeL1, setAssocL1, cacheSizeL1;
	int lineSizeL2, setAssocL2, cacheSizeL2;
	int numCores;
	
	ArrayST* L1Tags;
	ArrayST* L1Data;
	
	TextureCache(ParseXML* interface, int _ithCore, InputParameter* _ip, const CoreDynParam& _dynp, bool _exist = true);
	~TextureCache() {
		if(L1Tags) {delete L1Tags; L1Tags = 0;}
		if(L1Data) {delete L1Data; L1Data = 0;}
	}
	
	void computeEnergy(bool is_tdp = true);
	void displayEnergy(uint32_t indent = 0, int plevel = 100, bool is_tdp = true);
};

class GPULoadStoreU : public Component {
public:
	ParseXML *XML;
	int  ithCore;
	InputParameter interface_ip;
	CoreDynParam  coredynp;
	double clockRate,executionTime;
	double scktRatio, chip_PR_overhead, macro_PR_overhead;
	bool exist;

	ConstantCache* constcache;
	SharedMemory* shmem;
	L2Cache *L2cache;
	DFFCoalescingU *cl;
	DFFCoalescingU *bank_cl; // shared memory bank conflict check logic is similar in structure to coalescing logic
// 	DataCache dcache; // contains shared memory as well
	AddressGenerationU *agu;
	TextureCache* tex;

	GPULoadStoreU(ParseXML *XML_interface, int ithCore_, InputParameter* interface_ip_,const CoreDynParam & dyn_p_, bool exist_=true);
	~GPULoadStoreU() {
		if(constcache) {delete constcache; constcache = 0;}
		if(shmem){delete shmem;shmem=0;}
		if(L2cache){delete L2cache;L2cache=0;}
		if(cl) {delete cl; cl = 0;}
		if(bank_cl) {delete bank_cl; bank_cl = 0;}
		if(tex) { delete tex; tex = 0; }
	}
	void computeEnergy(bool is_tdp=true);
	void displayEnergy(uint32_t indent = 0,int plevel = 100, bool is_tdp=true);
};

class GPUUndiffCore : public Component {
public:
	ParseXML *XML;
	int  ithCore;
	InputParameter interface_ip;
	CoreDynParam  coredynp;
	double clockRate,executionTime;
	double scktRatio, chip_PR_overhead, macro_PR_overhead;
	bool exist;
	
	int num_warps; // In-flight warps
	double num_tmus, num_rops; // texture sampler and ROP counts PER CORE, i.e. Fermi: 48 ROPs / 16 cores = 3
	GPUUndiffCore(ParseXML* XML_interface, int ithCore_, InputParameter* interface_ip_, const CoreDynParam & dyn_p_, bool exist_=true);
	void displayEnergy(uint32_t indent = 0, int plevel = 100, bool is_tdp = true);
};

/*
class Gddr:public Component {
public:
	ParseXML *XML;
	int ithMemoryPartition;
	InputParameter interface_ip;
	CoreDynParam  coredynp;
	//double energy, base_energy,per_access_energy, leakage, gate_leakage;
	bool  is_default;
	statsDef       tdp_stats;
	statsDef       rtp_stats;
	statsDef       stats_t;
	//powerDef       power_t;

	double pds_pre_pdn,	pds_pre_stby,pds_act_pdn,pds_act_stby;
	double 	psch_pre_pdn,psch_pre_stby,psch_act_pdn,psch_act_stby;
	double 	pds_act,psch_act,pds_wr,psch_wr,pds_rd,psch_rd,pds_dq,pds_termW;
	double 	psch_dq,psch_termW,pds_ref,psch_ref;
	double psys_pre_pdn,psys_pre_stby,psys_act_pdn,psys_act_stby,psys_act,psys_wr,psys_rd,psys_ref;
	double psys_tot,psys_rwt_tot,psys_back_tot;
	double pds_tot,pds_rwt_tot,pds_back_tot;

	bool exist;

	Gddr(ParseXML *XML_interface, int ithMemoryPartition_, InputParameter* interface_ip_, const CoreDynParam & dyn_p_, bool exist_=true);
	void computeEnergy(bool is_tdp=true);
	void displayEnergy(uint32_t indent = 0,int plevel = 100, bool is_tdp=true);
	~Gddr();
};
*/

#endif
