/*
 * system.h
 *
 *  Created on: Aug 1, 2012
 *      Author: sohan
 */

#ifndef SYSTEM_H_
#define SYSTEM_H_

#include "processor.h"

class Gddr:public Component {
public:
	ParseXML *XML;
	int ithMemoryPartition;
	InputParameter interface_ip;
	CoreDynParam  coredynp;
	//double energy, base_energy,per_access_energy, leakage, gate_leakage;
	bool  is_default;
	statsDef       tdp_stats;
	statsDef       rtp_stats;
	statsDef       stats_t;
	//powerDef       power_t;

	double pds_pre_pdn,	pds_pre_stby,pds_act_pdn,pds_act_stby;
	double 	psch_pre_pdn,psch_pre_stby,psch_act_pdn,psch_act_stby;
	double 	pds_act,psch_act,pds_wr,psch_wr,pds_rd,psch_rd,pds_dq,pds_termW;
	double 	psch_dq,psch_termW,pds_ref,psch_ref;
	double psys_pre_pdn,psys_pre_stby,psys_act_pdn,psys_act_stby,psys_act,psys_wr,psys_rd,psys_ref;
	double psys_tot,psys_rwt_tot,psys_back_tot;
	double pds_tot,pds_rwt_tot,pds_back_tot;

	bool exist;

	Gddr(ParseXML *XML_interface, int ithMemoryPartition_, bool exist_=true);
	void computeEnergy(bool is_tdp=true);
	void displayEnergy(uint32_t indent = 0,int plevel = 100, bool is_tdp=true);
	~Gddr();
};

class System : public Component
{
  public:
	ParseXML *XML;

    InputParameter interface_ip;
    ProcParam procdynp;
    Gddr *gddr;
    Processor *proc;

    System(ParseXML *XML_interface);
    void computeEnergy();
    void displayEnergy(uint32_t indent = 0,int plevel = 100, bool is_tdp=true);
    ~System(){
    	if(proc) {delete proc; proc = 0;}
    }
};


#endif /* SYSTEM_H_ */
