/*
 * system.cc
 *
 *  Created on: Aug 1, 2012
 *      Author: sohan
 */
#include "XML_Parse.h"
#include "system_gpu.h"
#include <string>
#include "version.h"

Gddr::Gddr(ParseXML* XML_interface, int ithMemoryPartition_, bool exist_)
:XML(XML_interface),
 ithMemoryPartition(ithMemoryPartition_),
 exist(exist_)
{
	if(!exist)
		return;

	//Data Sheet Background power
	pds_pre_pdn=XML->sys.core[ithMemoryPartition].gddr_idd2p*XML->sys.core[ithMemoryPartition].gddr_vdd;
	pds_pre_stby=XML->sys.core[ithMemoryPartition].gddr_idd2n*XML->sys.core[ithMemoryPartition].gddr_vdd;
	pds_act_pdn=XML->sys.core[ithMemoryPartition].gddr_idd3p*XML->sys.core[ithMemoryPartition].gddr_vdd;
	pds_act_stby=XML->sys.core[ithMemoryPartition].gddr_idd3n*XML->sys.core[ithMemoryPartition].gddr_vdd;

	//Background power scaled according to system usage
	psch_pre_pdn=pds_pre_pdn*XML->sys.core[ithMemoryPartition].af_bnk_pre_percent*XML->sys.core[ithMemoryPartition].af_cke_lo_pre_percent;
	psch_pre_stby=pds_pre_stby*XML->sys.core[ithMemoryPartition].af_bnk_pre_percent*(1-XML->sys.core[ithMemoryPartition].af_cke_lo_pre_percent);
	psch_act_pdn=pds_act_pdn*(1-XML->sys.core[ithMemoryPartition].af_bnk_pre_percent)*XML->sys.core[ithMemoryPartition].af_cke_lo_act_percent;
	psch_act_stby=pds_act_stby*(1-XML->sys.core[ithMemoryPartition].af_bnk_pre_percent)*(1-XML->sys.core[ithMemoryPartition].af_cke_lo_act_percent);

	// Activation to activation power
	pds_act=(XML->sys.core[ithMemoryPartition].gddr_idd0-(XML->sys.core[ithMemoryPartition].gddr_idd3n*XML->sys.core[ithMemoryPartition].tRAS+XML->sys.core[ithMemoryPartition].gddr_idd2n*(XML->sys.core[ithMemoryPartition].tRC-XML->sys.core[ithMemoryPartition].tRAS))/XML->sys.core[ithMemoryPartition].tRC);

	//activation power scaled according to averaged scheduled row to row activate timing
	psch_act=pds_act*(XML->sys.core[ithMemoryPartition].tRC/XML->sys.core[ithMemoryPartition].af_tRRDsch);

	// Power consumption due to WRITES
	pds_wr=(XML->sys.core[ithMemoryPartition].gddr_idd4w-XML->sys.core[ithMemoryPartition].gddr_idd3n)*XML->sys.core[ithMemoryPartition].gddr_vdd;

	// WRITEs power scaling according to command scheduling
	psch_wr=pds_wr*XML->sys.core[ithMemoryPartition].af_wrsch_percent;

	// Power consumption due to READS
	pds_rd=(XML->sys.core[ithMemoryPartition].gddr_idd4r-XML->sys.core[ithMemoryPartition].gddr_idd3n)*XML->sys.core[ithMemoryPartition].gddr_vdd;

	// READs power scaling according to command scheduling
	psch_rd=pds_rd*XML->sys.core[ithMemoryPartition].af_rdsch_percent;

	// Nominal I/O Termination power consumption
	pds_dq=XML->sys.core[ithMemoryPartition].gddr_pdq_rd*XML->sys.core[ithMemoryPartition].gddr_num_dqr;
	pds_termW=XML->sys.core[ithMemoryPartition].gddr_pdq_wr*XML->sys.core[ithMemoryPartition].gddr_num_dqw;

	// Nominal I/O Termination power scaling according to command scheduling
	psch_dq=pds_dq*XML->sys.core[ithMemoryPartition].af_rdsch_percent;
	psch_termW=pds_termW*XML->sys.core[ithMemoryPartition].af_wrsch_percent;

	// Refresh Power
	pds_ref=(XML->sys.core[ithMemoryPartition].gddr_idd5-XML->sys.core[ithMemoryPartition].gddr_idd3n)*XML->sys.core[ithMemoryPartition].gddr_vdd;

	// Scaling according to average scheduled refresh command
	psch_ref=pds_ref*(XML->sys.core[ithMemoryPartition].tRFC/XML->sys.core[ithMemoryPartition].tREFI);

	//Power derating ( voltage and frequency scaling)

	if(XML->sys.core[ithMemoryPartition].gddr_mrs12==0)
		psys_pre_pdn=psch_pre_pdn*(XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd)*(XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd);
	else
		psys_pre_pdn=psch_pre_pdn*(XML->sys.core[ithMemoryPartition].gddr_clock_used/XML->sys.core[ithMemoryPartition].gddr_clock)*((XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd)*(XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd));
	psys_pre_stby=psch_pre_stby*(XML->sys.core[ithMemoryPartition].gddr_clock_used/XML->sys.core[ithMemoryPartition].gddr_clock)*((XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd)*(XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd));
	psys_act_pdn=psch_act_pdn*(XML->sys.core[ithMemoryPartition].gddr_clock_used/XML->sys.core[ithMemoryPartition].gddr_clock)*((XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd)*(XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd));
	psys_act_stby=psch_act_stby*(XML->sys.core[ithMemoryPartition].gddr_clock_used/XML->sys.core[ithMemoryPartition].gddr_clock)*((XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd)*(XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd));
	psys_act=psch_act*((XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd)*(XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd));
	psys_wr=psch_wr*(XML->sys.core[ithMemoryPartition].gddr_clock_used/XML->sys.core[ithMemoryPartition].gddr_clock)*((XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd)*(XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd));
	psys_rd=psch_rd*(XML->sys.core[ithMemoryPartition].gddr_clock_used/XML->sys.core[ithMemoryPartition].gddr_clock)*((XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd)*(XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd));
	psys_ref=psch_ref*((XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd)*(XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd));

	area.set_area(0);
}


void Gddr::computeEnergy(bool is_tdp)
{

	//double pppm_t[4]    = {1,1,1,1};
	// Initialization phase
	if (is_tdp)
	{
		//set_pppm(pppm_t, 2, 2, 2, 2);//2 means two source operands needs to be passed for each int instruction.
		stats_t.readAc.access = XML->sys.core[ithMemoryPartition].gddr_num_mp*XML->sys.core[ithMemoryPartition].gddr_num_dram_per_mp;
		tdp_stats = stats_t;


	    power.readOp.leakage = 0;
	    power.readOp.gate_leakage = 0;
	     //double long_channel_device_reduction = longer_channel_device_reduction(Core_device, coredynp.core_ty);
	    //power.readOp.longer_channel_leakage	= power.readOp.leakage*long_channel_device_reduction;
	}
	else
	{
		stats_t.readAc.access = XML->sys.core[ithMemoryPartition].gddr_num_mp*XML->sys.core[ithMemoryPartition].gddr_num_dram_per_mp;
		rtp_stats = stats_t;
	}

	//Computation phase
	if(is_tdp)
	{

		//Total Background power
		//pds_back_tot=pds_pre_pdn+pds_pre_stby+pds_act_pdn+pds_act_stby+pds_ref;
		//Background power needs to be weighted for Peak Dynamic also
		pds_back_tot=psys_pre_pdn+psys_pre_stby+psys_act_pdn+psys_act_stby+pds_ref;
		//Total Activate power
		pds_act=pds_act*(XML->sys.core[ithMemoryPartition].tRC/XML->sys.core[ithMemoryPartition].tRRD);

		pds_rwt_tot=pds_wr+pds_rd+pds_dq+pds_termW;

		// GDDR total power
		pds_tot=pds_back_tot+pds_act+pds_rwt_tot;
		power.readOp.dynamic = pds_tot*stats_t.readAc.access*1e-3;

	}

	else
	{

		//Total Background power
		psys_back_tot=psys_pre_pdn+psys_pre_stby+psys_act_pdn+psys_act_stby+psys_ref;

		// Total Rd/Wr/Term Power
		psys_rwt_tot=psys_wr+psys_rd+psch_dq+psch_termW;

		// GDDR total power
		psys_tot=psys_back_tot+psys_act+psys_rwt_tot;
		rt_power.readOp.dynamic = psys_tot*stats_t.readAc.access*1e-3; // 1e-3 for converting into watt
	}


}


void Gddr::displayEnergy(uint32_t indent,int plevel,bool is_tdp)
{
	string indent_str(indent, ' ');
	string indent_str_next(indent+2, ' ');
	bool long_channel = XML->sys.longer_channel_device;

	if (is_tdp)
	{
			cout << indent_str << "Memory Partition (Count: "<< XML->sys.core[ithMemoryPartition].gddr_num_mp <<" ):" << endl;
			cout << indent_str << "Peak Dynamic = " << power.readOp.dynamic << " W" << endl;
			cout << indent_str_next << "Peak Background Power = " << pds_back_tot*1e-3  << " W" << endl;
			cout << indent_str_next << "Peak Activate Power = " << pds_act*1e-3  << " W" << endl;
			cout << indent_str_next << "Peak Rd/Wr/Term Power = " << pds_rwt_tot*1e-3  << " W" << endl;
			//cout << indent_str_next << "Gate Leakage = " << power.readOp.gate_leakage*1e-3  << " W" << endl;
			cout << indent_str << "Runtime Dynamic = " << rt_power.readOp.dynamic << " W" << endl;
			cout << indent_str_next << "Runtime Background Power = " << psys_back_tot*1e-3  << " W" << endl;
			cout << indent_str_next << "Runtime Activate Power = " << psys_act*1e-3  << " W" << endl;
			cout << indent_str_next << "Runtime Rd/Wr/Term Power = " << psys_rwt_tot*1e-3  << " W" << endl;
			cout <<endl;
	}
	else
	{
	}
}



System::System(ParseXML *XML_interface)
:XML(XML_interface),
 proc(0),
 gddr(0)
{
	int ithMemoryPartition;
	//Later it could be used to calculate power per memory partition
	ithMemoryPartition=0;
	//GDDR
	gddr = new Gddr(XML,ithMemoryPartition);
	area.set_area(area.get_area() + gddr->area.get_area());

	//Processor created
	proc= new Processor(XML);
	area.set_area(area.get_area() + proc->area.get_area());

}

void System::computeEnergy()
{
	bool is_tdp=true;
	double pppm_t[4] = {1,1,1,1};
	set_pppm(pppm_t,1,0,0,0);
	power = power +proc->power;
	rt_power = rt_power + proc->rt_power;
	for(int i=0;i<2;i++){
		if(is_tdp) {
			gddr->computeEnergy(is_tdp);
			power = power +gddr->power*pppm_t;
		}else {
			gddr->computeEnergy(is_tdp);
			rt_power = rt_power + gddr->rt_power*pppm_t;
		}
		is_tdp=false;

	}

}


void System::displayEnergy(uint32_t indent,int plevel,bool is_tdp)
{
	string indent_str(indent, ' ');
	string indent_str2(indent-1, ' ');
	string indent_str_next(indent+2, ' ');
	bool long_channel = XML->sys.longer_channel_device;
	if(is_tdp){

		if (plevel<5)
		{
			cout<<"\ngpgpupow (version "<< VER_MAJOR <<"."<< VER_MINOR
					<< " of " << VER_UPDATE << ") results (current print level is "<< plevel
			<<", please increase print level to see the details in components): "<<endl;
		}
		else
		{
			cout<<"\ngpgpupow (version "<< VER_MAJOR <<"."<< VER_MINOR
								<< " of " << VER_UPDATE << ") results  (current print level is 5)"<< endl;
		}
		cout <<"*****************************************************************************************"<<endl;
		cout <<indent_str<<"Technology "<<XML->sys.core_tech_node<<" nm"<<endl;
		//cout <<indent_str<<"Device Type= "<<XML->sys.device_type<<endl;
		if (long_channel)
			cout <<indent_str<<"Using Long Channel Devices When Appropriate"<<endl;
		//cout <<indent_str<<"Interconnect metal projection= "<<XML->sys.interconnect_projection_type<<endl;
		proc->displayInterconnectType(XML->sys.interconnect_projection_type, indent);
		cout <<indent_str<<"Core clock Rate(MHz) "<<XML->sys.core[0].clock_rate<<endl;
    	cout <<endl;
		cout <<"*****************************************************************************************"<<endl;

	cout <<"System: "<<endl;
	cout << "@" << indent_str2 << "Runtime Power = " << ((long_channel? power.readOp.longer_channel_leakage:power.readOp.leakage) + power.readOp.gate_leakage)+rt_power.readOp.dynamic << " W" << endl;
	cout << indent_str << "Area = " << area.get_area()*1e-6<< " mm^2" << endl;
	cout << indent_str << "Peak Power = " << power.readOp.dynamic +
		(long_channel? power.readOp.longer_channel_leakage:power.readOp.leakage) + power.readOp.gate_leakage <<" W" << endl;
	cout << indent_str << "Total Leakage = " <<
		(long_channel? power.readOp.longer_channel_leakage:power.readOp.leakage) + power.readOp.gate_leakage <<" W" << endl;
	cout << indent_str << "Peak Dynamic = " << power.readOp.dynamic << " W" << endl;
	cout << indent_str << "Subthreshold Leakage = " << (long_channel? power.readOp.longer_channel_leakage:power.readOp.leakage) <<" W" << endl;
	//cout << indent_str << "Subthreshold Leakage = " << power.readOp.longer_channel_leakage <<" W" << endl;
	cout << indent_str << "Gate Leakage = " << power.readOp.gate_leakage << " W" << endl;
	cout << indent_str << "Runtime Dynamic = " << rt_power.readOp.dynamic << " W" << endl;
	cout << indent_str << "Execution Time = " << fixed <<  proc->cores[0]->executionTime << " s" << endl;
	cout <<endl;
	}
	else
	{

	}

	if (gddr !=NULL){
		cout << "GDDR:" << endl;
		cout << indent_str_next << "Area = " << gddr->area.get_area()*1e-6<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << gddr->power.readOp.dynamic << " W" << endl;
		cout << indent_str_next << "Runtime Dynamic = " << gddr->rt_power.readOp.dynamic << " W" << endl;
		cout <<endl;
		if(plevel > 2)
			gddr->displayEnergy(indent+4,plevel,is_tdp);
		}
	//Display processor
	proc->displayEnergy(2, plevel);

}
