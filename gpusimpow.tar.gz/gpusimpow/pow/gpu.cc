/*
 * File: gpu.cc
 * ------------
 * Contains implementations of GPU control structures.
 * 
 * Written by Michael Andersch, Sohan Lal, Jan Lucas, TUB, 2012.
 */

#include "gpu.h"
#include "io.h"
#include "parameter.h"
#include "const.h"
#include "basic_circuit.h"
#include <iostream>
#include <algorithm>
#include "XML_Parse.h"
#include <string>
#include <cmath>
#include <assert.h>
#include "crossbar.h"


gpu_register_file::gpu_register_file(ParseXML* XML_interface, int ithCore_, InputParameter* interface_ip_, const CoreDynParam & dyn_p_, bool exist_) :  coredynp(dyn_p_), interface_ip(*interface_ip_) , XML(XML_interface)
{
	m_registers = XML->sys.core[0].gpu_num_registers;
	m_banks= XML->sys.core[0].gpu_reg_banks;
	int lines_per_bank= m_registers / m_banks;
	m_width = 32;
	m_ports= XML->sys.core[0].gpu_reg_ports;

	clockRate = coredynp.clockRate*XML->sys.core[0].gpu_clock_shader_to_uncore_ratio;
	executionTime = coredynp.executionTime;

	cb= new Crossbar(m_ports,m_ports,32);
	cb->compute_power();
	
	interface_ip.is_cache = false;
	interface_ip.pure_ram = true;
	interface_ip.pure_cam = false;
	interface_ip.line_sz = m_width/8;
	interface_ip.cache_sz = lines_per_bank * m_width/8;
	interface_ip.assoc = 1;
	interface_ip.nbanks = 1;
	interface_ip.out_w = m_width;
	interface_ip.access_mode = 0;
	interface_ip.throughput = 1.0/clockRate;
	interface_ip.latency = 1.0/clockRate;
	interface_ip.obj_func_dyn_energy = 0;
	interface_ip.obj_func_dyn_power  = 0;
	interface_ip.obj_func_leak_power = 0;
	interface_ip.obj_func_cycle_t    = 1;
	interface_ip.num_rw_ports = 1;
	interface_ip.num_rd_ports    = 0;
	interface_ip.num_wr_ports    = 0;
	interface_ip.num_se_rd_ports = 0;
	memory_bank = new ArrayST(&interface_ip, "Register File Bank", Core_device, coredynp.opt_local, coredynp.core_ty);
	memory_bank->power = memory_bank->power_t;
	memory_bank->area.set_area((memory_bank->area.get_area() + memory_bank->local_result.area));

	area.set_area(area.get_area() + (memory_bank->local_result.area*m_banks)+  (cb->area.get_area()* (m_banks/m_ports))   );

	// the operand collector unit for a single SIMD lane operand, stores 4 words, 2 ports
	interface_ip.is_cache = false;
	interface_ip.pure_ram = true;
	interface_ip.pure_cam = false;
	interface_ip.line_sz = m_width/8;
	interface_ip.cache_sz = 4 * interface_ip.line_sz;
	interface_ip.assoc = 1;
	interface_ip.nbanks = 1;
	interface_ip.out_w = m_width;
	interface_ip.access_mode = 0;
	interface_ip.throughput = 1.0/clockRate;
	interface_ip.latency = 1.0/clockRate;
	interface_ip.obj_func_dyn_energy = 0;
	interface_ip.obj_func_dyn_power  = 0;
	interface_ip.obj_func_leak_power = 0;
	interface_ip.obj_func_cycle_t    = 1;
	interface_ip.num_rw_ports = 2;
	interface_ip.num_rd_ports    = 0;
	interface_ip.num_wr_ports    = 0;
	interface_ip.num_se_rd_ports = 0;
	lane_op_collector = new ArrayST(&interface_ip, "Single-Operand Collector", Core_device, coredynp.opt_local, coredynp.core_ty);
	
	lane_op_collector->power = lane_op_collector->power_t;
	lane_op_collector->area.set_area(lane_op_collector->area.get_area() + lane_op_collector->local_result.area);
	
	area.set_area(area.get_area() + lane_op_collector->area.get_area() * 4 * XML->sys.core[0].gpu_num_SP_per_SM);
}

void gpu_register_file::computeEnergy(bool is_tdp)
{
	double pppm_t[4] = {1,1,1,1};

	if(is_tdp) {
		memory_bank->stats_t.readAc.access = 0.75;
		memory_bank->stats_t.writeAc.access = 0.25;
		memory_bank->power_t.reset();
		memory_bank->power_t.readOp.dynamic += memory_bank->local_result.power.readOp.dynamic * memory_bank->stats_t.readAc.access + memory_bank->local_result.power.writeOp.dynamic * memory_bank->stats_t.writeAc.access;
		
		lane_op_collector->stats_t.readAc.access = 1;
		lane_op_collector->stats_t.writeAc.access = 1;
		lane_op_collector->power_t.reset();
		lane_op_collector->power_t.readOp.dynamic += lane_op_collector->local_result.power.readOp.dynamic * lane_op_collector->stats_t.readAc.access + lane_op_collector->local_result.power.writeOp.dynamic * lane_op_collector->stats_t.writeAc.access;
		lane_op_collector->power = lane_op_collector->power_t + lane_op_collector->local_result.power * pppm_lkg;
		
		int collcnt = 4 * XML->sys.core[0].gpu_num_SP_per_SM;
		set_pppm(pppm_t, (double) m_banks, (double) m_banks, (double) m_banks, (double) m_banks);
		power = memory_bank->power_t * pppm_t + cb->power * pppm_t;
		set_pppm(pppm_t, (double) collcnt, (double) collcnt, (double) collcnt, (double) collcnt);
		power = power + lane_op_collector->power * pppm_t;
	} else {
		// TODO: this is fixed to 32 threads per warp even though not every instruction is
		// executed by all threads (due to divergence) because the average SIMD efficiency
		// is already factored into the access counts in the simulator
		int tpw = 32; //XML->sys.core[0].gpu_threads_per_warp;
		
		memory_bank->power_t.reset();
		memory_bank->stats_t.readAc.access = XML->sys.core[0].af_rf_reads*tpw;
		memory_bank->stats_t.writeAc.access = XML->sys.core[0].af_rf_writes*tpw;
		memory_bank->power_t.readOp.dynamic += 
			memory_bank->local_result.power.readOp.dynamic * memory_bank->stats_t.readAc.access +
			memory_bank->local_result.power.writeOp.dynamic * memory_bank->stats_t.writeAc.access;
		
		lane_op_collector->stats_t.readAc.access = XML->sys.core[0].af_rf_reads*tpw*4;
		lane_op_collector->stats_t.writeAc.access = XML->sys.core[0].af_rf_writes*tpw*4;
		lane_op_collector->power_t.reset();
		lane_op_collector->power_t.readOp.dynamic += lane_op_collector->local_result.power.readOp.dynamic * lane_op_collector->stats_t.readAc.access + lane_op_collector->local_result.power.writeOp.dynamic * lane_op_collector->stats_t.writeAc.access;
		lane_op_collector->rt_power = lane_op_collector->power_t + lane_op_collector->local_result.power*pppm_lkg;
		rt_power = memory_bank->power_t;
		rt_power = rt_power + lane_op_collector->rt_power;
		
		// Set pppm to number of accesses for dynamic power component
		long long acc = XML->sys.core[0].af_rf_reads*tpw + XML->sys.core[0].af_rf_writes*tpw;
		set_pppm(pppm_t, (double) acc, (double) m_banks, (double) m_banks, (double) m_banks);
		rt_power = rt_power + cb->power * pppm_t;
	}	
}

void gpu_register_file::displayEnergy(uint32_t indent,int plevel, bool is_tdp)
{
	string indent_str(indent, ' ');
	string indent_str_next(indent+2, ' ');
	
	if(is_tdp) {
		cout << indent_str<< "Register Memory Banks:" << endl;
		cout << indent_str_next << "Area = " << memory_bank->area.get_area()*1e-6*m_banks<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << memory_bank->local_result.power.readOp.dynamic*clockRate*m_banks*0.75+memory_bank->local_result.power.writeOp.dynamic*clockRate*m_banks*0.25 << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = "
				<< (memory_bank->power.readOp.leakage*m_banks) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << memory_bank->local_result.power.readOp.gate_leakage*m_banks << " W" << endl;
		cout << indent_str_next << "Runtime Power = " << (double)(memory_bank->local_result.power.readOp.dynamic*(XML->sys.core[0].af_rf_reads*32)+memory_bank->local_result.power.writeOp.dynamic*(XML->sys.core[0].af_rf_writes*32))/executionTime << " W" << endl;
		cout << endl;
		cout << indent_str<< "Single-Lane Operand Collectors:" << endl;
		cout << indent_str_next << "Area = " << lane_op_collector->area.get_area()*1e-6*4 << " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << lane_op_collector->power.readOp.dynamic*clockRate*4 << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = "
				<< (lane_op_collector->power.readOp.leakage*4) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << lane_op_collector->power.readOp.gate_leakage*4 << " W" << endl;
		cout << indent_str_next << "Runtime Power = " << (double)lane_op_collector->rt_power.readOp.dynamic/executionTime/XML->sys.core[0].gpu_num_SP_per_SM << " W" << endl;
		cout << endl;		
		cout << indent_str<< "Crossbars:" << endl;
		cout << indent_str_next << "Area = " << cb->area.get_area()*1e-6*(m_banks/m_ports) << " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << cb->power.readOp.dynamic*clockRate*m_banks << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = "
				<< (cb->power.readOp.leakage*m_banks/m_ports) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << cb->power.readOp.gate_leakage*m_banks/m_ports << " W" << endl;
		cout << indent_str_next << "Runtime Power = " << (double)(cb->power.readOp.dynamic*(XML->sys.core[0].af_rf_writes*32+XML->sys.core[0].af_rf_reads*32))/executionTime << " W" << endl;
		cout << endl;


	}
}


scheduling_logic::scheduling_logic(bool _is_default, int  core_num_warps_,
	int  issue_width_, const InputParameter *configure_interface,
	enum Device_ty device_ty_,
	enum Core_type core_ty_)
 :is_default(_is_default),
  core_num_warps(core_num_warps_),
  issue_width(issue_width_),
  device_ty(device_ty_),
  core_ty(core_ty_)
{
    	l_ip=*configure_interface;
    	local_result = init_interface(&l_ip);

    	computeEnergy();

    	double sckRation = g_tp.sckt_co_eff;
    	power.readOp.dynamic *= sckRation;
    	power.writeOp.dynamic *= sckRation;
    	power.searchOp.dynamic *= sckRation;

    	double long_channel_device_reduction = longer_channel_device_reduction(device_ty,core_ty);
    	power.readOp.longer_channel_leakage	= power.readOp.leakage*long_channel_device_reduction;
}

void scheduling_logic::computeEnergy()
{ // based on ISCA2003 paper on 64-bit priority encoders and nvidia patents
  double Ctotal, Cinv, CprePrioInverters, Cpencode, Cadder;
  double WSelORn, WSelORprequ, WSelPn, WSelPp, WSelEnn, WSelEnp;

  // TODO: UPDATE! 0.8um process data is used
  WSelORn    	=  	12.5 * l_ip.F_sz_um;//this was 10 micron for the 0.8 micron process
  WSelORprequ   = 	50 * l_ip.F_sz_um;//this was 40 micron for the 0.8 micron process
  WSelPn     	= 	12.5 * l_ip.F_sz_um;//this was 10mcron for the 0.8 micron process
  WSelPp     	=  	18.75 * l_ip.F_sz_um;//this was 15 micron for the 0.8 micron process
  WSelEnn    	=  	6.25 * l_ip.F_sz_um;//this was 5 micron for the 0.8 micron process
  WSelEnp    	=  	12.5 * l_ip.F_sz_um;//this was 10 micron for the 0.8 micron process

  Ctotal = 0;

  // single CMOS inverter
  Cinv = drain_C_(WSelPn, NCH, 1, 1, g_tp.cell_h_def) + drain_C_(WSelPp, PCH, 1, 1, g_tp.cell_h_def) + gate_C(WSelPn+WSelPp, 10.0);

  // valid bit inversion before prio encoding
  CprePrioInverters = Cinv * (double)core_num_warps;

  // 64-bit priority encoder with macro cell folding
  // The 50%/66% number is just a guess based on transistors switching per cycle and transistors switching for each input
  Cpencode = 0.5 * CprePrioInverters + 0.66*8.0*(15.0*Cinv + 24.0 * (drain_C_(WSelPn, NCH, 1, 1, g_tp.cell_h_def) + gate_C(WSelPn, 10.0)) + 8.0*(drain_C_(WSelPp, PCH, 1, 1, g_tp.cell_h_def) + gate_C(WSelPp, 10.0)));

  // TODO: phase counter currently only an adder
  // TODO: adder model based on 0.18 micron process
  // TODO: adder model extrapolated from 4-bit adder
  // 4-bit 0.18 micron adder is given at 34.28 microwatts for 50 MHz and 0.63V
//   Cadder = 34.28/50.0/(0.63*0.63) * 1.5;
//   Cadder /= 1e6;
  // TODO: Adder given by NXP data, see wiki for details
  Cadder = 1.5*88/1e12;

  Ctotal += issue_width * (Cpencode + Cadder);

  power.readOp.dynamic = Ctotal*g_tp.peri_global.Vdd*g_tp.peri_global.Vdd;
  //TODO continue here
//   power.readOp.leakage = issue_width * num_arbiter *
//       (cmos_Isub_leakage(WSelPn, WSelPp, 2, nor)/*approximate precompute with a nor gate*///grant1p
//        + cmos_Isub_leakage(WSelPn, WSelPp, 3, nor)//grant2p
//        + cmos_Isub_leakage(WSelPn, WSelPp, 4, nor)//grant3p
//        + cmos_Isub_leakage(WSelEnn, WSelEnp, 2, nor)*4//enable logic
//        + cmos_Isub_leakage(WSelEnn, WSelEnp, 1, inv)*2*3//for each grant there are two inverters, there are 3 grant sIsubnals
// 		  )*g_tp.peri_global.Vdd;
//   power.readOp.gate_leakage = issue_width * num_arbiter *
//       (cmos_Ig_leakage(WSelPn, WSelPp, 2, nor)/*approximate precompute with a nor gate*///grant1p
//        + cmos_Ig_leakage(WSelPn, WSelPp, 3, nor)//grant2p
//        + cmos_Ig_leakage(WSelPn, WSelPp, 4, nor)//grant3p
//        + cmos_Ig_leakage(WSelEnn, WSelEnp, 2, nor)*4//enable logic
//        + cmos_Ig_leakage(WSelEnn, WSelEnp, 1, inv)*2*3//for each grant there are two inverters, there are 3 grant signals
//         )*g_tp.peri_global.Vdd;
}

WarpControlU::WarpControlU(ParseXML* XML_interface, int ithCore_, InputParameter* interface_ip_, const CoreDynParam & dyn_p_, bool exist_)
:XML(XML_interface),
 ithCore(ithCore_),
 interface_ip(*interface_ip_),
 coredynp(dyn_p_),
 warp_status_table(0),
 reconvergence_stacks(0),
 instruction_buffer(0),
 scoreboard(0),
 warp_selection(0),
 issue_selection(0),
 ic(0),
 exist(exist_)
 {
	if (!exist) return;
	int   tag, data;
	int size, line, assoc;
	bool  is_default=true;
	string tmp_name;

	clockRate = coredynp.clockRate;
	executionTime = coredynp.executionTime;

	//**************** Warp Status Table ******************//
	data = XML->sys.core[ithCore].gpu_instr_address_width + (int)ceil(log2(XML->sys.core[ithCore].gpu_core_warps_in_flight)) + I_CACHE_ACCESS_ALLOW_BIT + XML->sys.core[ithCore].gpu_warp_priority_designator;
	interface_ip.is_cache = false;
	interface_ip.pure_ram = true;
	interface_ip.pure_cam = false;
	interface_ip.line_sz = data;
	interface_ip.cache_sz = interface_ip.line_sz * XML->sys.core[ithCore].gpu_core_warps_in_flight;
	interface_ip.assoc = 1;
	interface_ip.nbanks = 1;
	interface_ip.out_w = interface_ip.line_sz*8;
	interface_ip.access_mode = 0;
	interface_ip.throughput = 1.0/clockRate;
	interface_ip.latency = 1.0/clockRate;
	interface_ip.obj_func_dyn_energy = 0;
	interface_ip.obj_func_dyn_power  = 0;
	interface_ip.obj_func_leak_power = 0;
	interface_ip.obj_func_cycle_t    = 1;
	interface_ip.num_rw_ports = 0;
	interface_ip.num_rd_ports    = XML->sys.core[ithCore].gpu_warp_schedulers;
	interface_ip.num_wr_ports    = XML->sys.core[ithCore].gpu_warp_schedulers;
	interface_ip.num_se_rd_ports = 0;
	warp_status_table = new ArrayST(&interface_ip, "WarpStatusTable", Core_device, coredynp.opt_local, coredynp.core_ty);
	warp_status_table->area.set_area(warp_status_table->area.get_area() + warp_status_table->local_result.area);
	area.set_area(area.get_area() +  warp_status_table->local_result.area);
	//*************** END Warp Status Table ***************//

	//*************** Reconvergence Stacks ****************//
	interface_ip.is_cache = false;
	interface_ip.pure_ram = true;
	interface_ip.pure_cam = false;
	data = XML->sys.core[ithCore].gpu_instr_address_width * 2 + XML->sys.core[ithCore].gpu_threads_per_warp;
	interface_ip.line_sz = data;
	interface_ip.cache_sz = interface_ip.line_sz * XML->sys.core[ithCore].gpu_threads_per_warp / 2 * XML->sys.core[ithCore].gpu_core_warps_in_flight;
	interface_ip.assoc = 1;
	interface_ip.nbanks = 1;
	interface_ip.out_w = interface_ip.line_sz*8;
	interface_ip.access_mode = 0;
	interface_ip.throughput = 1.0/clockRate;
	interface_ip.latency = 1.0/clockRate;
	interface_ip.obj_func_dyn_energy = 0;
	interface_ip.obj_func_dyn_power  = 0;
	interface_ip.obj_func_leak_power = 0;
	interface_ip.obj_func_cycle_t    = 1;
	interface_ip.num_rw_ports    = 1;//XML->sys.core[ithCore].gpu_warp_schedulers; // For Fermi dual-issue, two EX pipelines simultaneously read / pop their stack entries
	interface_ip.num_rd_ports    = 0;
	interface_ip.num_wr_ports    = 0;
	interface_ip.num_se_rd_ports = 0;
	reconvergence_stacks = new ArrayST(&interface_ip, "ReconvergenceStacks", Core_device, coredynp.opt_local, coredynp.core_ty);
	// For area calculation, take into account rec. stacks are replicated for each in-flight warp
	reconvergence_stacks->area.set_area(reconvergence_stacks->area.get_area()+ reconvergence_stacks->local_result.area);//*XML->sys.core[ithCore].gpu_core_warps_in_flight);
	area.set_area(area.get_area()+ reconvergence_stacks->local_result.area);//*XML->sys.core[ithCore].gpu_core_warps_in_flight);
	//*************** END Reconvergence Stacks ************//

	//**************** Instruction Buffer ******************//
	interface_ip.is_cache = true;
	interface_ip.pure_ram = false;
	interface_ip.pure_cam = false;
	tag = (int)ceil(log2(XML->sys.core[ithCore].gpu_core_warps_in_flight));
	data = (XML->sys.core[ithCore].gpu_instr_size + READY_BIT + VALID_BIT + WARP_BARRIERED_BIT);
	interface_ip.specific_tag = 1;
	interface_ip.tag_w = tag;
	interface_ip.line_sz = data;
	interface_ip.cache_sz = XML->sys.core[ithCore].gpu_instrbuf_slots_per_warp * interface_ip.line_sz * XML->sys.core[ithCore].gpu_core_warps_in_flight; // This accounts for two instruction entries per warp at max
	interface_ip.assoc = XML->sys.core[ithCore].gpu_instrbuf_slots_per_warp;
	interface_ip.nbanks = 1;
	interface_ip.out_w = interface_ip.line_sz*8;
	interface_ip.access_mode = 0;
	interface_ip.throughput = 1.0/clockRate;
	interface_ip.latency = 1.0/clockRate;
	interface_ip.obj_func_dyn_energy = 0;
	interface_ip.obj_func_dyn_power  = 0;
	interface_ip.obj_func_leak_power = 0;
	interface_ip.obj_func_cycle_t    = 1;
	interface_ip.num_rw_ports    = 0; // For Fermi dual-issue, two EX pipelines simultaneously read / pop their stack entries
	interface_ip.num_rd_ports    = XML->sys.core[ithCore].gpu_warp_schedulers;
	interface_ip.num_wr_ports    = XML->sys.core[ithCore].gpu_warp_schedulers;
	interface_ip.num_se_rd_ports = 0;
	instruction_buffer = new ArrayST(&interface_ip, "GPUInstructionBuffer", Core_device, coredynp.opt_local, coredynp.core_ty);
	instruction_buffer->area.set_area(instruction_buffer->area.get_area() + instruction_buffer->local_result.area);
	area.set_area(area.get_area() +  instruction_buffer->local_result.area);
	//*************** END Instruction Buffer ************//

	if(XML->sys.core[ithCore].gpu_scoreboarded) { // Shader core is scoreboarded, create scoreboard mem structure
		interface_ip.is_cache = true;
		interface_ip.pure_ram = false;
		interface_ip.pure_cam = false;
		tag = (int)ceil(log2(XML->sys.core[ithCore].gpu_core_warps_in_flight));
		data = (int)ceil(log2((XML->sys.core[ithCore].gpu_maxregs_per_thread)))*2 + VALID_BIT;
		interface_ip.specific_tag = 1;
		interface_ip.tag_w = tag;
		interface_ip.line_sz = data;
		interface_ip.cache_sz = interface_ip.line_sz * XML->sys.core[ithCore].gpu_core_warps_in_flight * XML->sys.core[ithCore].gpu_warp_instrs_in_flight;
		interface_ip.assoc = XML->sys.core[ithCore].gpu_warp_instrs_in_flight;
		interface_ip.nbanks = 1;
		interface_ip.out_w = interface_ip.line_sz*8;
		interface_ip.access_mode = 0;
		interface_ip.throughput = 1.0/clockRate;
		interface_ip.latency = 1.0/clockRate;
		interface_ip.obj_func_dyn_energy = 0;
		interface_ip.obj_func_dyn_power  = 0;
		interface_ip.obj_func_leak_power = 0;
		interface_ip.obj_func_cycle_t    = 1;
		interface_ip.num_rw_ports    = 0;
		interface_ip.num_rd_ports    = XML->sys.core[ithCore].gpu_warp_schedulers;
		interface_ip.num_wr_ports    = XML->sys.core[ithCore].gpu_warp_schedulers;
		interface_ip.num_se_rd_ports = 0;
		scoreboard = new ArrayST(&interface_ip, "GPUScoreboard", Core_device, coredynp.opt_local, coredynp.core_ty);
		scoreboard->area.set_area(scoreboard->area.get_area() + scoreboard->local_result.area);
		area.set_area(area.get_area() +  scoreboard->local_result.area);
	} else {
	  // Blocking barrel processing, "scoreboard" is simplified to ready bit in instruction buffer
	}

	/* Warp selection logic */
	warp_selection = new scheduling_logic(is_default, XML->sys.core[ithCore].gpu_core_warps_in_flight,
		XML->sys.core[ithCore].gpu_warp_schedulers,
		&interface_ip, Core_device, coredynp.core_ty);

	issue_selection = new scheduling_logic(is_default, XML->sys.core[ithCore].gpu_core_warps_in_flight,
		XML->sys.core[ithCore].gpu_warp_schedulers,
		&interface_ip, Core_device, coredynp.core_ty);

	/* Decode logic */
	opcode_decoder = new inst_decoder(is_default, &interface_ip,
    		  coredynp.opcode_length, 1/*Decoder should not know how many by itself*/,
    		  false,
    		  Core_device, coredynp.core_ty);

	regs_decoder = new inst_decoder(is_default, &interface_ip,
    		  (int)ceil(log2((XML->sys.core[ithCore].gpu_maxregs_per_thread))), 1,
    		  false,
    		  Core_device, coredynp.core_ty);

	misc_decoder = new inst_decoder(is_default, &interface_ip,
    		  8/* Prefix field etc upto 14B*/, 1,
    		  false,
    		  Core_device, coredynp.core_ty);

	//******************Instruction Cache******************//


		size=(int)XML->sys.core[ithCore].gpu_ic_size;
		line=(int)XML->sys.core[ithCore].gpu_ic_line;
		assoc=(int)XML->sys.core[ithCore].gpu_ic_assoc;

		tag=(int) XML->sys.core[ithCore].gpu_globalmem_address_bits-(int)log2(size/(line*assoc))-(int)log2(line);

		//printf("%d",tag);

		interface_ip.specific_tag        = 1;
		interface_ip.tag_w               = tag;
		interface_ip.cache_sz            = (int)XML->sys.core[ithCore].gpu_ic_size;
		interface_ip.line_sz             = (int)XML->sys.core[ithCore].gpu_ic_line;
		interface_ip.assoc               = (int)XML->sys.core[ithCore].gpu_ic_assoc;
		interface_ip.nbanks              = 1;
		interface_ip.out_w               = 2*(int)XML->sys.core[ithCore].gpu_instr_size;//interface_ip.line_sz*8;     //(int)XML->sys.NoC[0].flit_bits;		// NOC flitsize is a resonable assumption for the port size
		interface_ip.access_mode         = 0;
		interface_ip.throughput          = 1.0/clockRate;
		interface_ip.latency             = 3.0/clockRate;
		interface_ip.is_cache            = true;
		interface_ip.obj_func_dyn_energy = 0;
		interface_ip.obj_func_dyn_power  = 0;
		interface_ip.obj_func_leak_power = 0;
		interface_ip.obj_func_cycle_t    = 1;
		interface_ip.num_rw_ports    = 1;
		interface_ip.num_rd_ports    = 0;
		interface_ip.num_wr_ports    = 0;
		interface_ip.num_se_rd_ports = 0;
	// 	fprintf(stderr, "Generating L1 cache...\n");
		ic = new ArrayST(&interface_ip, "Instruction Cache", Core_device, coredynp.opt_local, coredynp.core_ty);
		ic->area.set_area(ic->area.get_area()+ ic->local_result.area);
		area.set_area(area.get_area()+ ic->local_result.area);
}

void WarpControlU::computeEnergy(bool is_tdp)
{
	if(!exist) return;
	double r_access, w_access;

	// Initialization phase TODO: check TDP values
	if(is_tdp) {
		// Memory types
		// WST
		warp_status_table->stats_t.readAc.access = XML->sys.core[ithCore].gpu_warp_schedulers;
		warp_status_table->stats_t.writeAc.access = XML->sys.core[ithCore].gpu_warp_schedulers;
		warp_status_table->tdp_stats = warp_status_table->stats_t;

		// SIMT stacks
		reconvergence_stacks->stats_t.readAc.access = XML->sys.core[ithCore].gpu_warp_schedulers;
		reconvergence_stacks->stats_t.writeAc.access = XML->sys.core[ithCore].gpu_warp_schedulers;
		reconvergence_stacks->tdp_stats = reconvergence_stacks->stats_t;

		// IB
		instruction_buffer->stats_t.readAc.access = XML->sys.core[ithCore].gpu_warp_schedulers;
		instruction_buffer->stats_t.writeAc.access = XML->sys.core[ithCore].gpu_warp_schedulers;
		instruction_buffer->tdp_stats = instruction_buffer->stats_t;

		// Scoreboard
		if(XML->sys.core[ithCore].gpu_scoreboarded) {
			scoreboard->stats_t.readAc.access = XML->sys.core[ithCore].gpu_warp_schedulers;
			scoreboard->stats_t.writeAc.access = XML->sys.core[ithCore].gpu_warp_schedulers;
			scoreboard->tdp_stats = scoreboard->stats_t;
		}

		// Decoding logic
		opcode_decoder->stats_t.readAc.access     = XML->sys.core[ithCore].gpu_warp_schedulers;
		regs_decoder->stats_t.readAc.access  = XML->sys.core[ithCore].gpu_warp_schedulers;
		misc_decoder->stats_t.readAc.access     = XML->sys.core[ithCore].gpu_warp_schedulers;
		opcode_decoder->tdp_stats = opcode_decoder->stats_t;
		regs_decoder->tdp_stats = regs_decoder->stats_t;
		misc_decoder->tdp_stats = misc_decoder->stats_t;

		// Instruction Cache
		ic->stats_t.readAc.access = ic->stats_t.writeAc.access = 1;
		ic->tdp_stats = ic->stats_t;
	} else {
		// Memory types
		// WST
		warp_status_table->stats_t.readAc.access = XML->sys.core[ithCore].af_wst_reads;
		warp_status_table->stats_t.writeAc.access = XML->sys.core[ithCore].af_wst_writes;
		warp_status_table->rtp_stats = warp_status_table->stats_t;

		// SIMT stacks
		reconvergence_stacks->stats_t.readAc.access = XML->sys.core[ithCore].af_recstack_reads;
		reconvergence_stacks->stats_t.writeAc.access = XML->sys.core[ithCore].af_recstack_writes;
		reconvergence_stacks->rtp_stats = reconvergence_stacks->stats_t;

		// IB
		instruction_buffer->stats_t.readAc.access = XML->sys.core[ithCore].af_ib_reads;
		instruction_buffer->stats_t.writeAc.access = XML->sys.core[ithCore].af_ib_writes;
		instruction_buffer->rtp_stats = instruction_buffer->stats_t;

		// Scoreboard
		if(XML->sys.core[ithCore].gpu_scoreboarded) {
			scoreboard->stats_t.readAc.access = XML->sys.core[ithCore].af_scoreboard_reads;
			scoreboard->stats_t.writeAc.access = XML->sys.core[ithCore].af_scoreboard_reads;
			scoreboard->rtp_stats = scoreboard->stats_t;
		}

		// Decoding logic
		opcode_decoder->stats_t.readAc.access     = XML->sys.core[ithCore].af_general_total_instructions;
		regs_decoder->stats_t.readAc.access  = XML->sys.core[ithCore].af_general_total_instructions;
		misc_decoder->stats_t.readAc.access     = XML->sys.core[ithCore].af_general_total_instructions;
		opcode_decoder->rtp_stats = opcode_decoder->stats_t;
		regs_decoder->rtp_stats = regs_decoder->stats_t;
		misc_decoder->rtp_stats = misc_decoder->stats_t;

		// Instruction Cache
		//ic->stats_t.readAc.access = XML->sys.core[ithCore].af_ic_reads;
		//ic->stats_t.writeAc.access =XML->sys.core[ithCore].af_ic_writes;
		ic->stats_t.readAc.hit = XML->sys.core[ithCore].af_ic_hits;
		ic->stats_t.readAc.miss = XML->sys.core[ithCore].af_ic_misses;

		ic->rtp_stats = ic->stats_t;

	}

	warp_status_table->power_t.reset();
	instruction_buffer->power_t.reset();
	reconvergence_stacks->power_t.reset();
	ic->power_t.reset();
	if(XML->sys.core[ithCore].gpu_scoreboarded)
		scoreboard->power_t.reset();

	warp_status_table->power_t.readOp.dynamic += warp_status_table->local_result.power.readOp.dynamic * warp_status_table->stats_t.readAc.access + warp_status_table->local_result.power.writeOp.dynamic * warp_status_table->stats_t.writeAc.access + warp_selection->power.readOp.dynamic * warp_status_table->stats_t.readAc.access;
// 	printf("Warp Selection Logic Accesses: %f\n", warp_status_table->stats_t.readAc.access);
// 	printf("Warp Selection Logic Power per Access: %f\n", warp_selection->power.readOp.dynamic);
// 	printf("Warp Selection Logic Dynamic Power: %f\n", warp_selection->power.readOp.dynamic*warp_status_table->stats_t.readAc.access);
// 	printf("WST Dynamic Power: %f\n", warp_status_table->power_t.readOp.dynamic);

	instruction_buffer->power_t.readOp.dynamic += instruction_buffer->local_result.power.readOp.dynamic * instruction_buffer->stats_t.readAc.access + instruction_buffer->local_result.power.writeOp.dynamic * instruction_buffer->stats_t.writeAc.access + issue_selection->power.readOp.dynamic * instruction_buffer->stats_t.readAc.access;
// 	printf("Issue Selection Logic Accesses: %f\n", instruction_buffer->stats_t.readAc.access);
// 	printf("Issue Selection Logic Power per Access: %f\n", issue_selection->power.readOp.dynamic);
// 	printf("Issue Selection Logic Dynamic Power: %f\n", issue_selection->power.readOp.dynamic*instruction_buffer->stats_t.readAc.access);
// 	printf("IB Dynamic Power: %f\n", instruction_buffer->power_t.readOp.dynamic);

	reconvergence_stacks->power_t.readOp.dynamic += reconvergence_stacks->local_result.power.readOp.dynamic * reconvergence_stacks->stats_t.readAc.access + reconvergence_stacks->local_result.power.writeOp.dynamic * reconvergence_stacks->stats_t.writeAc.access;

	ic->power_t.readOp.dynamic += ic->local_result.power.readOp.dynamic * ic->stats_t.readAc.hit + ic->local_result.power.readOp.dynamic * ic->stats_t.readAc.miss + ic->local_result.power.writeOp.dynamic * ic->stats_t.readAc.miss;

	if(XML->sys.core[ithCore].gpu_scoreboarded) {
		scoreboard->power_t.readOp.dynamic += scoreboard->local_result.power.readOp.dynamic * scoreboard->stats_t.readAc.access + scoreboard->local_result.power.writeOp.dynamic * scoreboard->stats_t.writeAc.access;
	}


	// Computation phase
	if(is_tdp) {
		// Memory types
		// WST
		warp_status_table->power = warp_status_table->power_t + (warp_status_table->local_result.power + warp_selection->power) * pppm_lkg;
		// SIMT stacks
		reconvergence_stacks->power = reconvergence_stacks->power_t + reconvergence_stacks->local_result.power * pppm_lkg;
		// IB
		instruction_buffer->power = instruction_buffer->power_t + (instruction_buffer->local_result.power + issue_selection->power) * pppm_lkg;
		// Scoreboard
		if(XML->sys.core[ithCore].gpu_scoreboarded) {
			scoreboard->power = scoreboard->power_t + scoreboard->local_result.power * pppm_lkg;
		}

		power = power + warp_status_table->power + instruction_buffer->power + reconvergence_stacks->power;
		if(XML->sys.core[ithCore].gpu_scoreboarded)
			power = power + scoreboard->power;

		// Decoding logic
		opcode_decoder->power_t.readOp.dynamic    = opcode_decoder->power.readOp.dynamic;
		regs_decoder->power_t.readOp.dynamic = regs_decoder->power.readOp.dynamic;
		misc_decoder->power_t.readOp.dynamic    = misc_decoder->power.readOp.dynamic;

		opcode_decoder->power.readOp.dynamic    *= opcode_decoder->tdp_stats.readAc.access;
		regs_decoder->power.readOp.dynamic *= regs_decoder->tdp_stats.readAc.access;
		misc_decoder->power.readOp.dynamic    *= misc_decoder->tdp_stats.readAc.access;

		power = power + (opcode_decoder->power + regs_decoder->power + misc_decoder->power);

		//IC
		ic->power = ic->power_t + ic->local_result.power * pppm_lkg;
		power = power + ic->power;

	} else {
		// Memory types
		// WST
		warp_status_table->rt_power = warp_status_table->power_t + (warp_status_table->local_result.power + warp_selection->power) * pppm_lkg;
		// SIMT stacks
		reconvergence_stacks->rt_power = reconvergence_stacks->power_t + reconvergence_stacks->local_result.power * pppm_lkg;
		// IB
		instruction_buffer->rt_power = instruction_buffer->power_t + (instruction_buffer->local_result.power + issue_selection->power) * pppm_lkg;
		// Scoreboard
		if(XML->sys.core[ithCore].gpu_scoreboarded) {
			scoreboard->rt_power = scoreboard->power_t + scoreboard->local_result.power * pppm_lkg;
		}

		rt_power = rt_power + warp_status_table->rt_power + instruction_buffer->rt_power + reconvergence_stacks->rt_power;
		if(XML->sys.core[ithCore].gpu_scoreboarded)
			rt_power = rt_power + scoreboard->rt_power;

		// Decoding logic
		opcode_decoder->rt_power.readOp.dynamic    = opcode_decoder->power_t.readOp.dynamic*opcode_decoder->rtp_stats.readAc.access;
		regs_decoder->rt_power.readOp.dynamic = regs_decoder->power_t.readOp.dynamic * regs_decoder->rtp_stats.readAc.access;
		misc_decoder->rt_power.readOp.dynamic    = misc_decoder->power_t.readOp.dynamic * misc_decoder->rtp_stats.readAc.access;

		rt_power = rt_power + (opcode_decoder->rt_power + regs_decoder->rt_power + misc_decoder->rt_power);

		//IC
		ic->rt_power = ic->power_t + ic->local_result.power * pppm_lkg;
		rt_power = rt_power + ic->rt_power;
	}
}

void WarpControlU::displayEnergy(uint32_t indent,int plevel,bool is_tdp)
{
  	if (!exist) return;
	string indent_str(indent, ' ');
	string indent_str_next(indent+2, ' ');
	bool long_channel = XML->sys.longer_channel_device;

	if(is_tdp) {
		cout << indent_str<< "Warp Status Table:" << endl;
		cout << indent_str_next << "Area = " << warp_status_table->area.get_area()*1e-6<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << warp_status_table->power.readOp.dynamic*clockRate << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = "
				<< (long_channel? warp_status_table->power.readOp.longer_channel_leakage:warp_status_table->power.readOp.leakage) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << warp_status_table->power.readOp.gate_leakage << " W" << endl;
		cout << indent_str_next << "Runtime Dynamic = " << warp_status_table->rt_power.readOp.dynamic/executionTime << " W" << endl;
		cout << endl;

		cout << indent_str<< "Instruction Cache:" << endl;
		cout << indent_str_next << "Area = " << ic->area.get_area()*1e-6<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << ic->power.readOp.dynamic*clockRate << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = "
			<< (long_channel? ic->power.readOp.longer_channel_leakage:ic->power.readOp.leakage) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << ic->power.readOp.gate_leakage << " W" << endl;
		cout << indent_str_next << "Runtime Dynamic = " << ic->rt_power.readOp.dynamic/executionTime << " W" << endl;
		cout << endl;

		cout << indent_str<< "Instruction Buffer:" << endl;
		cout << indent_str_next << "Area = " << instruction_buffer->area.get_area()*1e-6<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << instruction_buffer->power.readOp.dynamic*clockRate << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = "
			<< (long_channel? instruction_buffer->power.readOp.longer_channel_leakage:instruction_buffer->power.readOp.leakage) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << instruction_buffer->power.readOp.gate_leakage << " W" << endl;
		cout << indent_str_next << "Runtime Dynamic = " << instruction_buffer->rt_power.readOp.dynamic/executionTime << " W" << endl;
		cout << endl;

		cout << indent_str<< "Reconvergence Stacks:" << endl;
		cout << indent_str_next << "Area = " << reconvergence_stacks->area.get_area()*1e-6<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << reconvergence_stacks->power.readOp.dynamic*clockRate << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = "
			<< (long_channel? reconvergence_stacks->power.readOp.longer_channel_leakage:reconvergence_stacks->power.readOp.leakage) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << reconvergence_stacks->power.readOp.gate_leakage << " W" << endl;
		cout << indent_str_next << "Runtime Dynamic = " << reconvergence_stacks->rt_power.readOp.dynamic/executionTime << " W" << endl;
		cout << endl;

		if(XML->sys.core[ithCore].gpu_scoreboarded) {
			cout << indent_str<< "Scoreboard:" << endl;
			cout << indent_str_next << "Area = " << scoreboard->area.get_area()*1e-6<< " mm^2" << endl;
			cout << indent_str_next << "Peak Dynamic = " << scoreboard->power.readOp.dynamic*clockRate << " W" << endl;
			cout << indent_str_next << "Subthreshold Leakage = "
				<< (long_channel? scoreboard->power.readOp.longer_channel_leakage:scoreboard->power.readOp.leakage) <<" W" << endl;
			cout << indent_str_next << "Gate Leakage = " << scoreboard->power.readOp.gate_leakage << " W" << endl;
			cout << indent_str_next << "Runtime Dynamic = " << scoreboard->rt_power.readOp.dynamic/executionTime << " W" << endl;
			cout << endl;
		}

		cout << indent_str<< "Instruction Decoders:" << endl;
		cout << indent_str_next << "Area = " << (opcode_decoder->area.get_area() +
				regs_decoder->area.get_area() +
				misc_decoder->area.get_area())*coredynp.decodeW*1e-6  << " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << (opcode_decoder->power.readOp.dynamic +
				regs_decoder->power.readOp.dynamic +
				misc_decoder->power.readOp.dynamic)*clockRate  << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = "
		<< (long_channel? (opcode_decoder->power.readOp.longer_channel_leakage +
				regs_decoder->power.readOp.longer_channel_leakage +
				misc_decoder->power.readOp.longer_channel_leakage):
					(opcode_decoder->power.readOp.leakage +
							regs_decoder->power.readOp.leakage +
							misc_decoder->power.readOp.leakage))  << " W" << endl;
		cout << indent_str_next << "Gate Leakage = " << (opcode_decoder->power.readOp.gate_leakage +
				regs_decoder->power.readOp.gate_leakage +
				misc_decoder->power.readOp.gate_leakage)  << " W" << endl;
		cout << indent_str_next << "Runtime Dynamic = " << (opcode_decoder->rt_power.readOp.dynamic +
				regs_decoder->rt_power.readOp.dynamic +
				misc_decoder->rt_power.readOp.dynamic)/executionTime << " W" << endl;
		cout << endl;
	} else {

	}
}

FunctionalUnit_gpu::FunctionalUnit_gpu(ParseXML *XML_interface, int ithCore_, InputParameter* interface_ip_,const CoreDynParam & dyn_p_, enum FU_type fu_type_)
:XML(XML_interface),
 ithCore(ithCore_),
 interface_ip(*interface_ip_),
 coredynp(dyn_p_),
 fu_type(fu_type_)
{
    double area_t;//, leakage, gate_leakage;
    double pmos_to_nmos_sizing_r = pmos_to_nmos_sz_ratio();
	clockRate = coredynp.clockRate*XML->sys.core[ithCore].gpu_clock_shader_to_uncore_ratio;
	executionTime = coredynp.executionTime;
	//executionTime = coredynp.executionTime/XML->sys.core[ithCore].gpu_clock_shader_to_uncore_ratio;
	frequency_index=0;

	double fpu_area_power_sp[][4] = {
				{2080000000,16077,0.0012,0.0309}, //{Hz,micro m,W,W}
				{1320000000,14241,0.00055,0.01285},
				{980000000,12670,0.00058,0.00809},
				{500000000,12117,0.00016,0.00316},
				{200000000,10619,0.0000358,0.000952}
		};

		// For double precision 45nm process
	double fpu_area_power_dp[][4] = {
				{1810000000,49839,0.0046,0.0959},
				{950000000,42019,0.0018,0.0292},
				{330000000,35058,0.0004,0.0056},
				{200000000,36747,0.00013,0.00323}
		};

	//XML_interface=_XML_interface;
	uca_org_t result2;
	result2 = init_interface(&interface_ip);
	single_precision=1;// TODO To be parameterized

		if (fu_type == FPU)
		{
			num_fu=XML->sys.core[ithCore].gpu_num_fpu_per_core;
			if(single_precision)
			{

#ifdef ANALYTICAL_FPU
				for(int i=0;i<5;i++)
				{
					if(clockRate>=fpu_area_power_sp[i][0])
					{
						if(i==0)
							frequency_index=0;
						else
							frequency_index=i-1;
						break;
					}
				}
				area_t=fpu_area_power_sp[frequency_index][1]*(g_ip->F_sz_nm*g_ip->F_sz_nm/45.0/45.0); // Power number from Energy Efficient FPU design paper
				leakage=fpu_area_power_sp[frequency_index][2];// feature size scaling needs to be done
				gate_leakage=0; // need to figure out
				base_energy = 0; // Yet dont know if we also need McPAT style base energy
				base_energy *=(g_tp.peri_global.Vdd*g_tp.peri_global.Vdd/1.2/1.2); // will be zero for the moment
				per_access_energy = fpu_area_power_sp[frequency_index][3]/clockRate*(g_ip->F_sz_nm/45.0); //This is per op energy(mJ)
				//TODO VDD scaling
				//FU_height=(38667*num_fu)*interface_ip.F_sz_um;//FPU from Sun's data
#else
				area_t=fpu_area_power_sp[0][1]*(g_ip->F_sz_nm*g_ip->F_sz_nm/45.0/45.0);
				leakage=fpu_area_power_sp[0][2];
				gate_leakage=0;
				base_energy = 0; 
				per_access_energy = 74.68e-12 *(g_ip->F_sz_nm/40.0); //Measurement result from GT240
#endif
			}

			else
			{   // Double precision fpu
				for(int i=0;i<4;i++)
				{
					if(clockRate>=fpu_area_power_dp[i][0])
					{
						if(i==0)
							frequency_index=0;
						else
							frequency_index=i-1;
						break;

					}
				}
				area_t=fpu_area_power_dp[frequency_index][1]*(g_ip->F_sz_nm*g_ip->F_sz_nm/45.0/45.0);
				leakage=fpu_area_power_dp[frequency_index][2];// feature size scaling needs to be done
				gate_leakage=0; // need to figure out
				base_energy = 0; // Yet dont know if we also need McPAT style base energy
				base_energy *=(g_tp.peri_global.Vdd*g_tp.peri_global.Vdd/1.2/1.2);
				per_access_energy = fpu_area_power_dp[frequency_index][3]/clockRate*(g_ip->F_sz_nm/45.0); //This is per op energy(mJ)
				//TODO VDD scaling
				//FU_height=(38667*num_fu)*interface_ip.F_sz_um;//FPU from Sun's data

			}
		}

		else if (fu_type==ALU)
		{

#ifdef ANALYTICAL_ALU
			num_fu=XML->sys.core[ithCore].gpu_num_iu_per_core;
			//dont know why 280*260*2
			//area_t = 280*260*2*g_tp.scaling_factor.logic_scaling_co_eff;//this is um^2 ALU + MUl
			area_t = 280*260*g_tp.scaling_factor.logic_scaling_co_eff;//this is um^2 ALU + MUl
			//leakage = area_t *(g_tp.scaling_factor.core_tx_density)*cmos_Isub_leakage(20*g_tp.min_w_nmos_, 20*g_tp.min_w_nmos_*pmos_to_nmos_sizing_r, 1, inv)*g_tp.peri_global.Vdd/2;//unit W
			//gate_leakage = area_t*(g_tp.scaling_factor.core_tx_density)*cmos_Ig_leakage(20*g_tp.min_w_nmos_, 20*g_tp.min_w_nmos_*pmos_to_nmos_sizing_r, 1, inv)*g_tp.peri_global.Vdd/2;
			leakage=0.0;
			gate_leakage=0.0;
			base_energy = coredynp.core_ty==Inorder? 0:89e-3; //W The base energy of ALU average numbers from Intel 4G and 773Mhz (Wattch)
			base_energy *=(g_tp.peri_global.Vdd*g_tp.peri_global.Vdd/1.2/1.2);
			per_access_energy = 1.15/1e9/4/1.3/1.3*g_tp.peri_global.Vdd*g_tp.peri_global.Vdd*(g_ip->F_sz_nm/90.0);//(g_tp.peri_global.Vdd*g_tp.peri_global.Vdd/1.2/1.2);//0.00649*1e-9; //This is per cycle energy(nJ)
			//printf("VDD=%f\n",g_tp.peri_global.Vdd);
			//FU_height=(6222*num_fu)*interface_ip.F_sz_um;//integer ALU
#else
			num_fu=XML->sys.core[ithCore].gpu_num_iu_per_core;
			area_t = 280*260*g_tp.scaling_factor.logic_scaling_co_eff;
			leakage=0.0;
			gate_leakage=0.0;
			base_energy= 0.0;
			per_access_energy = 37.88e-12 *(g_ip->F_sz_nm/40.0); //Measurement result from GT240

#endif
		}

		else if (fu_type==SFU)
		{
			num_fu=XML->sys.core[ithCore].gpu_num_sfu_per_core;
			area_t=340000*(g_ip->F_sz_nm*g_ip->F_sz_nm/180.0/180.0); // Power numbers from A high performance FP-SFU using constrained Piecewise Quadratic Aprrox paper
			leakage=0;// feature size scaling needs to be done
			gate_leakage=0; // need to figure out
			base_energy = 0; // Yet dont know if we also need McPAT style base energy
			base_energy *=(g_tp.peri_global.Vdd*g_tp.peri_global.Vdd/1.2/1.2);
			per_access_energy = 0.160*clockRate/420000000.0/clockRate*(g_ip->F_sz_nm/180.0); //This is per op energy(mJ) 160mw@420MHZ
			//TODO VDD scaling
		}

		else
		{
			cout<<"Unknown Functional Unit Type"<<endl;
			exit(0);
		}


	//IEXEU, simple ALU and FPU
	//  double C_ALU, C_EXEU, C_FPU; //Lum Equivalent capacitance of IEXEU and FPU. Based on Intel and Sun 90nm process fabracation.
	//
	//  C_ALU	  = 0.025e-9;//F
	//  C_EXEU  = 0.05e-9; //F
	//  C_FPU	  = 0.35e-9;//F
    area.set_area(area_t*num_fu);
    leakage *= num_fu;
    gate_leakage *=num_fu;
	//double macro_layout_overhead = g_tp.macro_layout_overhead;
	//area.set_area(area.get_area()*macro_layout_overhead);
}

void FunctionalUnit_gpu::computeEnergy(bool is_tdp)
{
	double pppm_t[4]    = {1,1,1,1};
	double FU_duty_cycle;
	if (is_tdp)
	{


		set_pppm(pppm_t, 2, 2, 2, 2);//2 means two source operands needs to be passed for each int instruction.
		if (fu_type == FPU)
		{
			stats_t.readAc.access = num_fu;
			tdp_stats = stats_t;
			//FU_duty_cycle = coredynp.FPU_duty_cycle;
		}
		else if (fu_type == ALU)
		{
			stats_t.readAc.access = num_fu;
			tdp_stats = stats_t;
			//FU_duty_cycle = coredynp.ALU_duty_cycle;
		}
		else if (fu_type == SFU)
		{
			stats_t.readAc.access = num_fu;
			tdp_stats = stats_t;
			//FU_duty_cycle = coredynp.MUL_duty_cycle;
		}

	    //power.readOp.dynamic = base_energy/clockRate + energy*stats_t.readAc.access;
	   // power.readOp.dynamic = per_access_energy*stats_t.readAc.access + base_energy/clockRate;
	    power.readOp.dynamic = per_access_energy*stats_t.readAc.access;
	    //double sckRation = g_tp.sckt_co_eff;
		//power.readOp.dynamic *= sckRation*FU_duty_cycle;
		//power.writeOp.dynamic *= sckRation;
		//power.searchOp.dynamic *= sckRation;

	    power.readOp.leakage = leakage;
	    power.readOp.gate_leakage = gate_leakage;
	    //double long_channel_device_reduction = longer_channel_device_reduction(Core_device, coredynp.core_ty);
	    //power.readOp.longer_channel_leakage	= power.readOp.leakage*long_channel_device_reduction;

	}
	else
	{
		if (fu_type == FPU)
		{
			stats_t.readAc.access = XML->sys.core[ithCore].af_fpu_accesses;
			rtp_stats = stats_t;
		}
		else if (fu_type == ALU)
		{
			stats_t.readAc.access = XML->sys.core[ithCore].af_iu_accesses;
			rtp_stats = stats_t;
		}
		else if (fu_type == SFU)
		{
			stats_t.readAc.access = XML->sys.core[ithCore].af_sfu_accesses;
			rtp_stats = stats_t;
		}

	    //rt_power.readOp.dynamic = base_energy*executionTime + energy*stats_t.readAc.access;
	    rt_power.readOp.dynamic = per_access_energy*stats_t.readAc.access + base_energy*executionTime;
		//double sckRation = g_tp.sckt_co_eff;
		//rt_power.readOp.dynamic *= sckRation;
		//rt_power.writeOp.dynamic *= sckRation;
		//rt_power.searchOp.dynamic *= sckRation;

	}


}


void FunctionalUnit_gpu::displayEnergy(uint32_t indent,int plevel,bool is_tdp)
{
	string indent_str(indent, ' ');
	string indent_str_next(indent+2, ' ');
	bool long_channel = XML->sys.longer_channel_device;

//	cout << indent_str_next << "Results Broadcast Bus Area = " << bypass->area.get_area() *1e-6 << " mm^2" << endl;
	if (is_tdp)
	{
		if (fu_type == FPU)
		{
			cout << indent_str << "Floating Point Units (FPUs) (Count: "<< XML->sys.core[ithCore].gpu_num_fpu_per_core <<" ):" << endl;
			cout << indent_str_next << "Area = " << area.get_area()*1e-6  << " mm^2" << endl;
			cout << indent_str_next << "Peak Dynamic = " << power.readOp.dynamic*clockRate  << " W" << endl;
			cout << indent_str_next << "Gate Leakage = " << power.readOp.gate_leakage  << " W" << endl;
			cout << indent_str_next << "Runtime Dynamic = " << rt_power.readOp.dynamic/executionTime << " W" << endl;
			cout <<endl;
		}
		else if (fu_type == ALU)
		{
			cout << indent_str << "Integer Units (Count: "<<  XML->sys.core[ithCore].gpu_num_iu_per_core<<" ):" << endl;
			cout << indent_str_next << "Area = " << area.get_area()*1e-6  << " mm^2" << endl;
			cout << indent_str_next << "Peak Dynamic = " << power.readOp.dynamic*clockRate  << " W" << endl;
			cout << indent_str_next << "Gate Leakage = " << power.readOp.gate_leakage  << " W" << endl;
			cout << indent_str_next << "Runtime Dynamic = " << rt_power.readOp.dynamic/executionTime << " W" << endl;
			cout <<endl;
		}
		else if (fu_type == SFU)
		{
			cout << indent_str << "Special Function Units (Exp/Trig) (Count: "<< XML->sys.core[ithCore].gpu_num_sfu_per_core <<" ):" << endl;
			cout << indent_str_next << "Area = " << area.get_area()*1e-6  << " mm^2" << endl;
			cout << indent_str_next << "Peak Dynamic = " << power.readOp.dynamic*clockRate  << " W" << endl;
			cout << indent_str_next << "Gate Leakage = " << power.readOp.gate_leakage  << " W" << endl;
			cout << indent_str_next << "Runtime Dynamic = " << rt_power.readOp.dynamic/executionTime << " W" << endl;
			cout <<endl;

		}

	}
	else
	{
	}

}

CudaCoreBase::CudaCoreBase(ParseXML *XML_interface)
:XML(XML_interface)
{
	power.reset();
	rt_power.reset();
	power.readOp.dynamic = 0.2/1.34e9;                          // According to our measurements an active SM on GT240 is using 0.2 Watt when running at 1.34 GHZ
	rt_power.readOp.dynamic = XML->sys.core[0].af_sm_active_cycles*(0.2/1.34e9)/XML->sys.number_of_cores;   // According to our measurements an active SM on GT240 is using 0.2 Watt when running at 1.34 GHZ
}


CudaCore::CudaCore(ParseXML* XML_interface, int ithCore_, InputParameter* interface_ip_, const CoreDynParam & dyn_p_, bool exist_)
:XML(XML_interface),
 ithCore(ithCore_),
 interface_ip(*interface_ip_),
 coredynp(dyn_p_),
 fpu_g(0),
 iu_g(0),
 sfu_g(0),
 exist(exist_)
{
	iu_g  = new FunctionalUnit_gpu(XML, ithCore,&interface_ip, coredynp, ALU);
	area.set_area(area.get_area()+ iu_g->area.get_area());
	//fu_height = exeu->FU_height;
	if (XML->sys.core[ithCore].gpu_num_fpu_per_core >0)
		{
		fpu_g  = new FunctionalUnit_gpu(XML, ithCore,&interface_ip, coredynp, FPU);
		area.set_area(area.get_area()+ fpu_g->area.get_area());
		}
	if (XML->sys.core[ithCore].gpu_num_sfu_per_core >0)
		{
		sfu_g   = new FunctionalUnit_gpu(XML, ithCore,&interface_ip, coredynp, SFU);
		area.set_area(area.get_area()+ sfu_g->area.get_area());
		//fu_height +=  sfu->FU_height;
		}
}

void CudaCore::computeEnergy(bool is_tdp)
{
	if (!exist) return;
	double pppm_t[4]    = {1,1,1,1};
//	rfu->power.reset();
//	rfu->rt_power.reset();
//	scheu->power.reset();
//	scheu->rt_power.reset();
//	exeu->power.reset();
//	exeu->rt_power.reset();

	iu_g->computeEnergy(is_tdp);
	if ( XML->sys.core[ithCore].gpu_num_fpu_per_core>0)
	{
		fpu_g->computeEnergy(is_tdp);
	}
	if (XML->sys.core[ithCore].gpu_num_sfu_per_core >0)
	{
		sfu_g->computeEnergy(is_tdp);
	}

	if (is_tdp)
	{
		//set_pppm(pppm_t, 2*coredynp.ALU_cdb_duty_cycle, 2, 2, 2*coredynp.ALU_cdb_duty_cycle);//2 means two source operands needs to be passed for each int instruction.
		//bypass.power = bypass.power + intTagBypass->power*pppm_t + int_bypass->power*pppm_t;
		if ( XML->sys.core[ithCore].gpu_num_sfu_per_core>0)
		{
			//set_pppm(pppm_t, 2*coredynp.MUL_cdb_duty_cycle, 2, 2, 2*coredynp.MUL_cdb_duty_cycle);//2 means two source operands needs to be passed for each int instruction.
			//bypass.power = bypass.power + intTag_mul_Bypass->power*pppm_t + int_mul_bypass->power*pppm_t;
			power      = power + sfu_g->power;
		}
		if (XML->sys.core[ithCore].gpu_num_fpu_per_core>0)
		{
			//set_pppm(pppm_t, 3*coredynp.FPU_cdb_duty_cycle, 3, 3, 3*coredynp.FPU_cdb_duty_cycle);//3 means three source operands needs to be passed for each fp instruction.
			//bypass.power = bypass.power + fp_bypass->power*pppm_t  + fpTagBypass->power*pppm_t ;
			power      = power + fpu_g->power;
		}

			//power     = power + iu_g->power;
	}
	else
	{
		//set_pppm(pppm_t, XML->sys.core[ithCore].cdb_alu_accesses, 2, 2, XML->sys.core[ithCore].cdb_alu_accesses);
		//bypass.rt_power = bypass.rt_power + intTagBypass->power*pppm_t;
		//bypass.rt_power = bypass.rt_power + int_bypass->power*pppm_t;

		if (XML->sys.core[ithCore].gpu_num_sfu_per_core >0)
		{
			//set_pppm(pppm_t, XML->sys.core[ithCore].cdb_mul_accesses, 2, 2, XML->sys.core[ithCore].cdb_mul_accesses);//2 means two source operands needs to be passed for each int instruction.
			//bypass.rt_power = bypass.rt_power + intTag_mul_Bypass->power*pppm_t + int_mul_bypass->power*pppm_t;
			rt_power      = rt_power + sfu_g->rt_power;
		}

		if (XML->sys.core[ithCore].gpu_num_fpu_per_core>0)
		{
			//set_pppm(pppm_t, XML->sys.core[ithCore].cdb_fpu_accesses, 3, 3, XML->sys.core[ithCore].cdb_fpu_accesses);
			//bypass.rt_power = bypass.rt_power + fp_bypass->power*pppm_t;
			//bypass.rt_power = bypass.rt_power + fpTagBypass->power*pppm_t;
			rt_power      = rt_power + fpu_g->rt_power;
		}
			rt_power      = rt_power + iu_g->rt_power;
	}
}

void CudaCore::displayEnergy(uint32_t indent,int plevel,bool is_tdp)
{

	if (!exist) return;
	string indent_str(indent, ' ');
	string indent_str_next(indent+2, ' ');
	bool long_channel = XML->sys.longer_channel_device;


//	cout << indent_str_next << "Results Broadcast Bus Area = " << bypass->area.get_area() *1e-6 << " mm^2" << endl;
	if (is_tdp)
	{
		iu_g->displayEnergy(indent,is_tdp);
		if (XML->sys.core[ithCore].gpu_num_fpu_per_core>0)
		{
			fpu_g->displayEnergy(indent,is_tdp);
		}
		if (XML->sys.core[ithCore].gpu_num_sfu_per_core >0)
		{
			sfu_g->displayEnergy(indent,is_tdp);
		}
	}
	else
	{
	}
}


#if 0
CoalescingU::CoalescingU(ParseXML *XML_interface, int ithCore_, InputParameter* interface_ip_,const CoreDynParam & dyn_p_, bool exist_)
:XML(XML_interface),
 ithCore(ithCore_),
 interface_ip(*interface_ip_),
 coredynp(dyn_p_),
 IncomingReqQ(0),
 OutgoingReqQ(0),
 PRT(0),
 PRTSelector(0),
 ThreadSelector(0),
 exist(exist_)
{

	if (!exist) return;
	int   tag, data;
	bool  is_default=true;
	string tmp_name;

	clockRate = coredynp.clockRate;
	executionTime = coredynp.executionTime;

	/** INCOMING QUEUE **/
	  tag = int(ceil(log2(XML->sys.core[ithCore].gpu_core_warps_in_flight)));
	  data = XML->sys.core[ithCore].gpu_threads_per_warp * XML->sys.core[ithCore].gpu_DRAM_address_width;
	  interface_ip.is_cache		   = true;
	  interface_ip.line_sz             = data;
	  interface_ip.specific_tag        = 1;
	  interface_ip.tag_w               = tag;
	  interface_ip.cache_sz            = XML->sys.core[ithCore].gpu_incoming_memreq_q_size*interface_ip.line_sz;
	  interface_ip.assoc               = 0;
	  interface_ip.nbanks              = 1;
	  interface_ip.out_w               = interface_ip.line_sz*8;
	  interface_ip.access_mode         = 1;
	  interface_ip.throughput          = 1.0/clockRate;
	  interface_ip.latency             = 1.0/clockRate;
	  interface_ip.obj_func_dyn_energy = 0;
	  interface_ip.obj_func_dyn_power  = 0;
	  interface_ip.obj_func_leak_power = 0;
	  interface_ip.obj_func_cycle_t    = 1;
	  interface_ip.num_rw_ports        = 0;
	  interface_ip.num_rd_ports        = 1;
	  interface_ip.num_wr_ports        = 1;
	  interface_ip.num_se_rd_ports     = 0;
	  IncomingReqQ = new ArrayST(&interface_ip, "IncomingMemQueue", Core_device, coredynp.opt_local, coredynp.core_ty);
	  IncomingReqQ->area.set_area(IncomingReqQ->area.get_area()+ IncomingReqQ->local_result.area);
	  area.set_area(area.get_area()+ IncomingReqQ->local_result.area);

	/** OUTGOING QUEUE **/
	  tag = int(ceil(log2(XML->sys.core[ithCore].gpu_core_warps_in_flight)));
	  data = REQ_SIZE_DESIGNATOR + int(ceil(log2(XML->sys.core[ithCore].gpu_core_warps_in_flight))) + XML->sys.core[ithCore].gpu_threads_per_warp + XML->sys.core[ithCore].gpu_DRAM_address_width;
	  interface_ip.is_cache		   = true;
	  interface_ip.line_sz             = data;
	  interface_ip.specific_tag        = 1;
	  interface_ip.tag_w               = tag;
	  interface_ip.cache_sz            = XML->sys.core[ithCore].gpu_outgoing_memreq_q_size*interface_ip.line_sz;
	  interface_ip.assoc               = 0;
	  interface_ip.nbanks              = 1;
	  interface_ip.out_w               = interface_ip.line_sz*8;
	  interface_ip.access_mode         = 1;
	  interface_ip.throughput          = 1.0/clockRate;
	  interface_ip.latency             = 1.0/clockRate;
	  interface_ip.obj_func_dyn_energy = 0;
	  interface_ip.obj_func_dyn_power  = 0;
	  interface_ip.obj_func_leak_power = 0;
	  interface_ip.obj_func_cycle_t    = 1;
	  interface_ip.num_rw_ports        = 0;
	  interface_ip.num_rd_ports        = 1;
	  interface_ip.num_wr_ports        = 1;
	  interface_ip.num_se_rd_ports     = 0;
	  OutgoingReqQ = new ArrayST(&interface_ip, "OutgoingMemQueue", Core_device, coredynp.opt_local, coredynp.core_ty);
	  OutgoingReqQ->area.set_area(OutgoingReqQ->area.get_area()+ OutgoingReqQ->local_result.area);
	  area.set_area(area.get_area()+ OutgoingReqQ->local_result.area);

	/** PRT **/
	data = XML->sys.core[ithCore].gpu_threads_per_warp * (XML->sys.core[ithCore].gpu_DRAM_address_width + 1); // plus one because of the serviced threads mask
	interface_ip.is_cache = false;
	interface_ip.pure_ram = true;
	interface_ip.pure_cam = false;
	interface_ip.line_sz = data;
	interface_ip.cache_sz = interface_ip.line_sz * XML->sys.core[ithCore].gpu_core_warps_in_flight;
	interface_ip.assoc = 1;
	interface_ip.nbanks = 1;
	interface_ip.out_w = interface_ip.line_sz*8;
	interface_ip.access_mode = 0;
	interface_ip.throughput = 1.0/clockRate;
	interface_ip.latency = 1.0/clockRate;
	interface_ip.obj_func_dyn_energy = 0;
	interface_ip.obj_func_dyn_power  = 0;
	interface_ip.obj_func_leak_power = 0;
	interface_ip.obj_func_cycle_t    = 1;
	interface_ip.num_rw_ports = 0;
	interface_ip.num_rd_ports    = 1;
	interface_ip.num_wr_ports    = 1;
	interface_ip.num_se_rd_ports = 0;
	PRT = new ArrayST(&interface_ip, "PRT", Core_device, coredynp.opt_local, coredynp.core_ty);
	PRT->area.set_area(PRT->area.get_area() + PRT->local_result.area);
	area.set_area(area.get_area() +  PRT->local_result.area);

	/* PRT entry and req thread selectors */
	PRTSelector = new scheduling_logic(is_default, XML->sys.core[ithCore].gpu_core_warps_in_flight,
		1, &interface_ip, Core_device, coredynp.core_ty);
	ThreadSelector = new scheduling_logic(is_default, XML->sys.core[ithCore].gpu_threads_per_warp,
		1, &interface_ip, Core_device, coredynp.core_ty);
}
#endif

DFFCoalescingU::DFFCoalescingU(ParseXML *XML_interface, int ithCore_, InputParameter* interface_ip_,const CoreDynParam & dyn_p_, bool exist_, enum Device_ty device_ty_)
:XML(XML_interface),
 ithCore(ithCore_),
 l_ip(*interface_ip_),
 coredynp(dyn_p_),
 PRTSelector(0),
 ThreadSelector(0),
 exist(exist_),
 device_ty(device_ty_)
{
	if (!exist) return;
	bool  is_default=true;

	clockRate = coredynp.clockRate;
	executionTime = coredynp.executionTime;

	WNANDn = 25 * l_ip.F_sz_um; //was 20 micron for the 0.8 micron proess
	WNANDp = 37.5 * l_ip.F_sz_um; //was 30 micron for the 0.8 micron process

	cell_load = 8 * gate_C(WNANDn + WNANDp, 0, false); // 8 is an assumption for now, can be readjusted later if necessary

	double PRT_cells = XML->sys.core[ithCore].gpu_core_warps_in_flight * (XML->sys.core[ithCore].gpu_threads_per_warp/LDSTU_WSIZE_MOD * (XML->sys.core[ithCore].gpu_DRAM_address_width + 1)); // plus one because of the serviced threads mask

	double IncomingReqCells = XML->sys.core[ithCore].gpu_threads_per_warp/LDSTU_WSIZE_MOD * XML->sys.core[ithCore].gpu_DRAM_address_width * XML->sys.core[ithCore].gpu_incoming_memreq_q_size;

	double OutgoingReqCells = REQ_SIZE_DESIGNATOR + int(ceil(log2(XML->sys.core[ithCore].gpu_core_warps_in_flight))) + XML->sys.core[ithCore].gpu_threads_per_warp/LDSTU_WSIZE_MOD + XML->sys.core[ithCore].gpu_DRAM_address_width;

	num_cells = PRT_cells + IncomingReqCells + OutgoingReqCells;

	/* PRT entry and req thread selectors */
	PRTSelector = new scheduling_logic(is_default, XML->sys.core[ithCore].gpu_core_warps_in_flight,
		1, &l_ip, Core_device, coredynp.core_ty);
	ThreadSelector = new scheduling_logic(is_default, XML->sys.core[ithCore].gpu_threads_per_warp/LDSTU_WSIZE_MOD,
		1, &l_ip, Core_device, coredynp.core_ty);

	computeEnergy();
}

void DFFCoalescingU::computeEnergy(bool is_tdp)
{
	if(!exist) return;
	double r_access, w_access;

	DFFCell cell(false, WNANDn, WNANDp, cell_load, &l_ip);
	cell.compute_DFF_cell();

	double clock_power = num_cells * cell.e_clock.readOp.dynamic;
	double total_power = num_cells * (cell.e_switch.readOp.dynamic + cell.e_keep_0.readOp.dynamic + cell.e_keep_1.readOp.dynamic)/3 + clock_power;
	double total_leakage = num_cells * cell.e_switch.readOp.leakage;
	double total_gate_leakage = num_cells * cell.e_switch.readOp.gate_leakage;
	power.readOp.dynamic += total_power;
	power.readOp.leakage += total_leakage;
	power.readOp.gate_leakage += total_gate_leakage;
	area.set_area(num_cells * cell.area.get_area());

	double long_channel_device_reduction = longer_channel_device_reduction(device_ty, coredynp.core_ty);
	power.readOp.longer_channel_leakage = power.readOp.leakage*long_channel_device_reduction;

	double sckRation = g_tp.sckt_co_eff*((2.0+2.0+1.0)/(XML->sys.core[ithCore].gpu_core_warps_in_flight + XML->sys.core[ithCore].gpu_incoming_memreq_q_size + 5.0));  // Not all table entries can switch at once but only 2 in PRT, 2 in inqueue, and approx. 20% of outqueue
	power.readOp.dynamic *= sckRation;
	power.writeOp.dynamic *= sckRation;
	power.searchOp.dynamic *= sckRation;

	power.readOp.dynamic += PRTSelector->power.readOp.dynamic + ThreadSelector->power.readOp.dynamic;
	rt_power.readOp.dynamic += XML->sys.core[ithCore].af_generated_gmem_accesses * (PRTSelector->power.readOp.dynamic + ThreadSelector->power.readOp.dynamic);
	power = power + (PRTSelector->power + ThreadSelector->power) * pppm_lkg;
	rt_power = rt_power + (PRTSelector->power + ThreadSelector->power) * pppm_lkg;

	area.set_area(area.get_area() * g_tp.macro_layout_overhead);
}

#if 0
void CoalescingU::computeEnergy(bool is_tdp)
{
	if(!exist) return;
	double r_access, w_access;

	// Initialization phase TODO: check TDP values
	if(is_tdp) {
		// Buffers
		// Incoming memory access request queue
		IncomingReqQ->stats_t.readAc.access = IncomingReqQ->stats_t.writeAc.access = 1;
		IncomingReqQ->tdp_stats = IncomingReqQ->stats_t;

		// Outgoing memory access request queue
		OutgoingReqQ->stats_t.readAc.access = OutgoingReqQ->stats_t.writeAc.access = 1;
		OutgoingReqQ->tdp_stats = OutgoingReqQ->stats_t;

		// Pending Request Table
		PRT->stats_t.readAc.access = PRT->stats_t.writeAc.access = 1;
		PRT->tdp_stats = PRT->stats_t;
	} else {
		// Buffers
		// Incoming memory access request queue
		IncomingReqQ->stats_t.readAc.access = XML->sys.core[ithCore].af_general_gmem_instructions;
		IncomingReqQ->stats_t.writeAc.access = XML->sys.core[ithCore].af_general_gmem_instructions;
		IncomingReqQ->rtp_stats = IncomingReqQ->stats_t;

		// Outgoing memory access request queue
		OutgoingReqQ->stats_t.readAc.access = XML->sys.core[ithCore].af_generated_gmem_accesses;
		OutgoingReqQ->stats_t.writeAc.access = XML->sys.core[ithCore].af_generated_gmem_accesses;
		OutgoingReqQ->rtp_stats = OutgoingReqQ->stats_t;

		// Pending Request Table
		PRT->stats_t.readAc.access = XML->sys.core[ithCore].af_generated_gmem_accesses;
		PRT->stats_t.writeAc.access = XML->sys.core[ithCore].af_general_gmem_instructions + (XML->sys.core[ithCore].af_generated_gmem_accesses - XML->sys.core[ithCore].af_general_gmem_instructions);
		// Write accesses are at least one per memory instruction (if fully coalesced) plus one for every global memory access that was generated additionally due to nonoptimal coalescence
		PRT->rtp_stats = PRT->stats_t;
	}

	IncomingReqQ->power_t.reset();
	OutgoingReqQ->power_t.reset();
	PRT->power_t.reset();

	IncomingReqQ->power_t.readOp.dynamic +=
	IncomingReqQ->local_result.power.readOp.dynamic * IncomingReqQ->stats_t.readAc.access
	+ IncomingReqQ->local_result.power.writeOp.dynamic * IncomingReqQ->stats_t.writeAc.access;

	OutgoingReqQ->power_t.readOp.dynamic +=
	OutgoingReqQ->local_result.power.readOp.dynamic * OutgoingReqQ->stats_t.readAc.access
	+ OutgoingReqQ->local_result.power.writeOp.dynamic * OutgoingReqQ->stats_t.writeAc.access;

	PRT->power_t.readOp.dynamic +=
	PRT->local_result.power.readOp.dynamic * PRT->stats_t.readAc.access
	+ PRT->local_result.power.writeOp.dynamic * PRT->stats_t.writeAc.access
	+ PRTSelector->power.readOp.dynamic * PRT->stats_t.readAc.access
	+ ThreadSelector->power.readOp.dynamic * PRT->stats_t.readAc.access;

	// Computation phase
	if(is_tdp) {
		// Memory types
		// incoming req queue
		IncomingReqQ->power = IncomingReqQ->power_t + IncomingReqQ->local_result.power * pppm_lkg;

		// outgoing req queue
		OutgoingReqQ->power = OutgoingReqQ->power_t + OutgoingReqQ->local_result.power * pppm_lkg;

		// pending request table
		PRT->power = PRT->power_t + (PRT->local_result.power + PRTSelector->power + ThreadSelector->power) * pppm_lkg;

		power = power +IncomingReqQ->power + OutgoingReqQ->power + PRT->power;
	} else {
		// Memory types
		// incoming req queue
		IncomingReqQ->rt_power = IncomingReqQ->power_t + IncomingReqQ->local_result.power * pppm_lkg;

		// outgoing req queue
		OutgoingReqQ->rt_power = OutgoingReqQ->power_t + OutgoingReqQ->local_result.power * pppm_lkg;

		// pending request table
		PRT->rt_power = PRT->power_t + (PRT->local_result.power + PRTSelector->power + ThreadSelector->power) * pppm_lkg;

		rt_power = rt_power +IncomingReqQ->rt_power + OutgoingReqQ->rt_power + PRT->rt_power;
	}
}

void CoalescingU::displayEnergy(uint32_t indent,int plevel,bool is_tdp)
{
  	if (!exist) return;
	string indent_str(indent, ' ');
	string indent_str_next(indent+2, ' ');
	bool long_channel = XML->sys.longer_channel_device;

	if(is_tdp) {
		cout << indent_str<< "PRT:" << endl;
		cout << indent_str_next << "Area = " << PRT->area.get_area()*1e-6<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << PRT->power.readOp.dynamic*clockRate << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = "
				<< (long_channel? PRT->power.readOp.longer_channel_leakage:PRT->power.readOp.leakage) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << PRT->power.readOp.gate_leakage << " W" << endl;
		cout << indent_str_next << "Runtime Dynamic = " << PRT->rt_power.readOp.dynamic/executionTime << " W" << endl;
		cout << endl;

		cout << indent_str<< "Application Request Queue:" << endl;
		cout << indent_str_next << "Area = " << IncomingReqQ->area.get_area()*1e-6<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << IncomingReqQ->power.readOp.dynamic*clockRate << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = "
			<< (long_channel? IncomingReqQ->power.readOp.longer_channel_leakage:IncomingReqQ->power.readOp.leakage) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << IncomingReqQ->power.readOp.gate_leakage << " W" << endl;
		cout << indent_str_next << "Runtime Dynamic = " << IncomingReqQ->rt_power.readOp.dynamic/executionTime << " W" << endl;
		cout << endl;

		cout << indent_str<< "Outgoing Memory Access Request Queue:" << endl;
		cout << indent_str_next << "Area = " << OutgoingReqQ->area.get_area()*1e-6<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << OutgoingReqQ->power.readOp.dynamic*clockRate << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = "
			<< (long_channel? OutgoingReqQ->power.readOp.longer_channel_leakage:OutgoingReqQ->power.readOp.leakage) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << OutgoingReqQ->power.readOp.gate_leakage << " W" << endl;
		cout << indent_str_next << "Runtime Dynamic = " << OutgoingReqQ->rt_power.readOp.dynamic/executionTime << " W" << endl;
		cout << endl;
	} else {

	}
}
#endif

SharedMemory::SharedMemory(ParseXML* XML_interface, int ithCore_, InputParameter* interface_ip_, const CoreDynParam & dyn_p_, bool exist_)
:XML(XML_interface),
 ithCore(ithCore_),
 interface_ip(*interface_ip_),
 coredynp(dyn_p_),
 exist(exist_)
 {
	num_banks= XML->sys.core[ithCore].gpu_shmem_num_banks;
	//int lines_per_bank= m_registers / m_banks;
	in_ports_di=num_banks;
	out_ports_di=XML->sys.core[ithCore].gpu_num_SP_per_SM;
	in_ports_ai=XML->sys.core[ithCore].gpu_num_SP_per_SM;
	out_ports_ai=XML->sys.core[ithCore].gpu_num_SP_per_SM;
	//TODO: Check the width parameter of Crossbar. Subthreshold leakage increases too much with value =32
	width_di = 32/2;

	size = (int)XML->sys.core[ithCore].gpu_shmem_size;
	width_ai=(int)log2(size);

	//clockRate = coredynp.clockRate;
	clockRate = coredynp.clockRate*XML->sys.core[ithCore].gpu_clock_shader_to_uncore_ratio;
	executionTime = coredynp.executionTime;

	data_interconnect= new Crossbar(in_ports_di,out_ports_di,width_di);
	//data_interconnect= new Crossbar(32,32,32);
	address_interconnect= new Crossbar(in_ports_ai,out_ports_ai,width_ai);
	//address_interconnect= new Crossbar(32,32,32);

	//address conflict logic
	//acl = new DFFCoalescingU(XML, ithCore, &interface_ip, coredynp);
	//area.set_area(area.get_area() + acl->area.get_area());
	//power=power+acl->power;

	interface_ip.is_cache = false;
	interface_ip.pure_ram = true;
	interface_ip.pure_cam = false;
	interface_ip.line_sz = 4; // Size in bytes?
	interface_ip.cache_sz = size/num_banks; // in bytes
	//interface_ip.cache_sz = size; // in bytes
	interface_ip.assoc = 1;
	interface_ip.nbanks = 1;
	interface_ip.out_w = 32; // size in bits
	interface_ip.access_mode = 0;
	interface_ip.throughput = 1.0/clockRate;
	interface_ip.latency = 1.0/clockRate;
	interface_ip.obj_func_dyn_energy = 0;
	interface_ip.obj_func_dyn_power  = 0;
	interface_ip.obj_func_leak_power = 0;
	interface_ip.obj_func_cycle_t    = 1;
	interface_ip.num_rw_ports = 1;
	interface_ip.num_rd_ports    = 0;
	interface_ip.num_wr_ports    = 0;
	interface_ip.num_se_rd_ports = 0;
	shmem_bank = new ArrayST(&interface_ip, "Shared Memory Bank", Core_device, coredynp.opt_local, coredynp.core_ty);
	//Area for one bank
	shmem_bank->area.set_area((shmem_bank->area.get_area() + shmem_bank->local_result.area));
	//Num_bank area
	shmem_bank->area.set_area((shmem_bank->area.get_area()*num_banks));

	//Set share memory area equal to num_bank area
	area.set_area((area.get_area()+shmem_bank->area.get_area()));

	// Compute data interconnect Power
	data_interconnect->compute_power();
	//add data interconnect area to share memory area
	area.set_area(area.get_area()+data_interconnect->area.get_area());

	//Compute address interconnect power
	address_interconnect->compute_power();
	//Add address interconnect area
	area.set_area(area.get_area()+address_interconnect->area.get_area());

	//TODO: Direct write Paths not modeled yet refer to NVIDIA Patent US 8108625 B1
	}

void SharedMemory::computeEnergy(bool is_tdp) {
	double r_access, w_access;
	double pppm_t[4] = {1,1,1,1};
	// Set pppm to number of banks
	set_pppm(pppm_t, (double) num_banks, (double) num_banks, (double) num_banks, (double) num_banks);

	// Initialization phase
	if(is_tdp) {
		shmem_bank->stats_t.readAc.access = shmem_bank->stats_t.writeAc.access = 1;
		shmem_bank->tdp_stats = shmem_bank->stats_t;

	} else {
		shmem_bank->stats_t.readAc.access = XML->sys.core[ithCore].af_shmem_reads;
		shmem_bank->stats_t.writeAc.access = XML->sys.core[ithCore].af_shmem_writes;
		shmem_bank->rtp_stats = shmem_bank->stats_t;
		}

	shmem_bank->power_t.reset();

	// Multiply Single bank power by number of banks
// 	shmem_bank->local_result.power = shmem_bank->local_result.power * pppm_t;

	// Multiply Single bank power by number of banks
	shmem_bank->power_t.readOp.dynamic +=
	shmem_bank->local_result.power.readOp.dynamic * num_banks * shmem_bank->stats_t.readAc.access
	+ shmem_bank->local_result.power.writeOp.dynamic * num_banks * shmem_bank->stats_t.writeAc.access;
	
	// Computation phase
	if(is_tdp) {
		//shmem_bank->power = shmem_bank->power_t + shmem_bank->local_result.power;
		shmem_bank->power = shmem_bank->power_t + shmem_bank->local_result.power * pppm_lkg;
		power=power+shmem_bank->power+data_interconnect->power+address_interconnect->power;
		// Bank conflict checker taken ou as it is already in Ld/St unit
		//+acl->power;
		//power=power+shmem_bank->power;
	} else {
		//shmem_bank->rt_power = shmem_bank->power_t*pppm_t + shmem_bank->local_result.power *pppm_t;
		shmem_bank->rt_power = shmem_bank->power_t + shmem_bank->local_result.power * pppm_lkg;
		rt_power=rt_power+shmem_bank->rt_power+data_interconnect->power+address_interconnect->power;
		//+acl->rt_power;
		//rt_power=rt_power+shmem_bank->rt_power;
	}
}

void SharedMemory::displayEnergy(uint32_t indent, int plevel, bool is_tdp) {
	string indent_str(indent, ' ');
	string indent_str_next(indent+2, ' ');
	bool long_channel = XML->sys.longer_channel_device;

	if(is_tdp) {
		cout << indent_str<< "Memory Banks:" << endl;
		cout << indent_str_next << "Area = " << shmem_bank->area.get_area()*1e-6<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << shmem_bank->power.readOp.dynamic*clockRate<< " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = " << (long_channel? shmem_bank->power.readOp.longer_channel_leakage:shmem_bank->power.readOp.leakage) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " <<shmem_bank->power.readOp.gate_leakage << " W" << endl;
		cout << indent_str_next << "Runtime Dynamic = " << shmem_bank->rt_power.readOp.dynamic/executionTime << " W" << endl;
		cout << endl;

		cout << indent_str<< "Data Interconnect:" << endl;
		cout << indent_str_next << "Area = " << data_interconnect->area.get_area()*1e-6<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << data_interconnect->power.readOp.dynamic*clockRate << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = " << (data_interconnect->power.readOp.leakage) <<" W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = " << (long_channel? data_interconnect->power.readOp.longer_channel_leakage:data_interconnect->power.readOp.leakage) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << data_interconnect->power.readOp.gate_leakage << " W" << endl;
		cout << endl;

		cout << indent_str<< "Address Interconnect:" << endl;
		cout << indent_str_next << "Area = " << address_interconnect->area.get_area()*1e-6<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << address_interconnect->power.readOp.dynamic*clockRate << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = " << (address_interconnect->power.readOp.leakage) <<" W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = " << (long_channel? address_interconnect->power.readOp.longer_channel_leakage:address_interconnect->power.readOp.leakage) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << address_interconnect->power.readOp.gate_leakage << " W" << endl;
		cout << endl;

	/*	cout << indent_str<< "Address Conflict Checker:" << endl;
		cout << indent_str_next << "Area = " << acl->area.get_area()*1e-6<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << acl->power.readOp.dynamic*clockRate << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = "
			 << (long_channel? acl->power.readOp.longer_channel_leakage:acl->power.readOp.leakage) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << acl->power.readOp.gate_leakage << " W" << endl;
		cout << indent_str_next << "Runtime Dynamic = " << acl->rt_power.readOp.dynamic/executionTime << " W" << endl;
		cout << endl;
		*/
		//data_interconnect->print_crossbar();
		//address_interconnect->print_crossbar();
}
}


ConstantCache::ConstantCache(ParseXML *XML_interface, int ithCore_, InputParameter* interface_ip_, const CoreDynParam& dyn_p_) 
: XML(XML_interface),
  ithCore(ithCore_),
  interface_ip(*interface_ip_),
  coredynp(dyn_p_),
  existL3(false)
{
	int tag, data, size, line, assoc, banks;
	clockRate = coredynp.clockRate;
	executionTime = coredynp.executionTime;
	
	tag = (int)ceil(log2(XML->sys.core[ithCore].gpu_user_addressable_constmem)) + EXTRA_ADDRESSABLE_CONSTMEM_BITS;
	
	// L1
	size                             = (int)XML->sys.core[ithCore].gpu_const_l1_size;
	line                             = (int)XML->sys.core[ithCore].gpu_const_l1_line;
	assoc                            = (int)XML->sys.core[ithCore].gpu_const_l1_assoc;
	banks                            = 1;
	interface_ip.specific_tag        = 1;
	interface_ip.tag_w               = tag;
	interface_ip.cache_sz            = size;
	interface_ip.line_sz             = line;
	interface_ip.assoc               = assoc;
	interface_ip.nbanks              = banks;
	interface_ip.out_w               = interface_ip.line_sz*8;
	interface_ip.access_mode         = 0;
	interface_ip.throughput          = 1.0/clockRate;
	interface_ip.latency             = 3.0/clockRate;
	interface_ip.is_cache            = true;
	interface_ip.obj_func_dyn_energy = 0;
	interface_ip.obj_func_dyn_power  = 0;
	interface_ip.obj_func_leak_power = 0;
	interface_ip.obj_func_cycle_t    = 1;
	interface_ip.num_rw_ports    = 1;
	interface_ip.num_rd_ports    = 0;
	interface_ip.num_wr_ports    = 0;
	interface_ip.num_se_rd_ports = 0;
// 	fprintf(stderr, "Generating L1 cache...\n");
	L1 = new ArrayST(&interface_ip, "ConstL1", Core_device, coredynp.opt_local, coredynp.core_ty);
	L1->area.set_area(L1->area.get_area()+ L1->local_result.area);
	area.set_area(area.get_area()+ L1->local_result.area);
	
	// L2
	size                             = (int)XML->sys.core[ithCore].gpu_const_l2_size;
	line                             = (int)XML->sys.core[ithCore].gpu_const_l2_line;
	assoc                            = (int)XML->sys.core[ithCore].gpu_const_l2_assoc;
	banks                            = 1;
	interface_ip.specific_tag        = 1;
	interface_ip.tag_w               = tag;
	interface_ip.cache_sz            = size;
	interface_ip.line_sz             = line;
	interface_ip.assoc               = assoc;
	interface_ip.nbanks              = banks;
	
	//interface_ip.out_w               = interface_ip.line_sz*8;			// this would be a 2048-bit output port, seems extremly unlikely

	interface_ip.out_w               = (int)XML->sys.NoC[0].flit_bits;		// NOC flitsize is a resonable assumption for the port size
	interface_ip.access_mode         = 0;
	interface_ip.throughput          = 1.0/clockRate;
	interface_ip.latency             = 3.0/clockRate;
	interface_ip.is_cache            = true;
	interface_ip.obj_func_dyn_energy = 0;
	interface_ip.obj_func_dyn_power  = 0;
	interface_ip.obj_func_leak_power = 0;
	interface_ip.obj_func_cycle_t    = 1;
	interface_ip.num_rw_ports    = 1;
	interface_ip.num_rd_ports    = 0;
	interface_ip.num_wr_ports    = 0;
	interface_ip.num_se_rd_ports = 0;
// 	fprintf(stderr, "Generating L2 cache...\n");
	L2 = new ArrayST(&interface_ip, "ConstL2", Core_device, coredynp.opt_local, coredynp.core_ty);
	L2->area.set_area(L2->area.get_area()+ L2->local_result.area / XML->sys.core[ithCore].gpu_SM_per_TPC);
	area.set_area(area.get_area()+ L2->local_result.area / XML->sys.core[ithCore].gpu_SM_per_TPC);  
	 
	// L3
	if((size = (int)XML->sys.core[ithCore].gpu_const_l3_size) > 0) {
		existL3 = true;
		line                             = (int)XML->sys.core[ithCore].gpu_const_l3_line;
		assoc                            = (int)XML->sys.core[ithCore].gpu_const_l3_assoc;
		banks                            = 1;
		interface_ip.specific_tag        = 1;
		interface_ip.tag_w               = tag;
		interface_ip.cache_sz            = size;
		interface_ip.line_sz             = line;
		interface_ip.assoc               = assoc;
		interface_ip.nbanks              = banks;
		interface_ip.out_w               = (int)XML->sys.NoC[0].flit_bits;		// NOC flitsize is a resonable assumption for the port size

//		interface_ip.out_w               = interface_ip.line_sz*8;
		interface_ip.access_mode         = 0;
		interface_ip.throughput          = 1.0/clockRate;
		interface_ip.latency             = 3.0/clockRate;
		interface_ip.is_cache            = true;
		interface_ip.obj_func_dyn_energy = 0;
		interface_ip.obj_func_dyn_power  = 0;
		interface_ip.obj_func_leak_power = 0;
		interface_ip.obj_func_cycle_t    = 1;
		interface_ip.num_rw_ports    = 1;
		interface_ip.num_rd_ports    = 0;
		interface_ip.num_wr_ports    = 0;
		interface_ip.num_se_rd_ports = 0;
// 		fprintf(stderr, "Generating L3 cache...\n");
		L3 = new ArrayST(&interface_ip, "ConstL3", LLC_device, coredynp.opt_local, coredynp.core_ty);
		L3->area.set_area(L3->area.get_area()+ L3->local_result.area / (XML->sys.core[ithCore].gpu_SM_per_TPC * XML->sys.core[ithCore].gpu_num_TPCs));
		area.set_area(area.get_area()+ L3->local_result.area / (XML->sys.core[ithCore].gpu_SM_per_TPC * XML->sys.core[ithCore].gpu_num_TPCs));  
	}
}

void ConstantCache::computeEnergy(bool is_tdp) {
	double r_access, w_access;
	double pppm_t[4] = {1,1,1,1};
	
	// Initialization phase
	if(is_tdp) {
		// L1
		L1->stats_t.readAc.access = L1->stats_t.writeAc.access = 1;
		L1->tdp_stats = L1->stats_t;
		
		// L2
		L2->stats_t.readAc.access = L2->stats_t.writeAc.access = 1;
		L2->tdp_stats = L2->stats_t;
		
		if(existL3) {
			L3->stats_t.readAc.access = L3->stats_t.writeAc.access = 1;
			L3->tdp_stats = L3->stats_t;
		}
	} else {
		// L1
		L1->stats_t.readAc.access = XML->sys.core[ithCore].af_cmem_reads;
		L1->stats_t.writeAc.access = XML->sys.core[ithCore].af_cmem_writes;
		L1->rtp_stats = L1->stats_t;
		
		// L2
		L2->stats_t.readAc.access = XML->sys.core[ithCore].af_cmem_reads * 0.5;
		L2->stats_t.writeAc.access = XML->sys.core[ithCore].af_cmem_writes;
		L2->rtp_stats = L2->stats_t;
		
		if(existL3) {
			L3->stats_t.readAc.access = XML->sys.core[ithCore].af_cmem_reads * 0.25;
			L3->stats_t.writeAc.access = XML->sys.core[ithCore].af_cmem_writes;
			L3->rtp_stats = L3->stats_t;
		}
	}
	
	L1->power_t.reset();
	L2->power_t.reset();
	if(existL3)
		L3->power_t.reset();
	
	// L2 is per TPC, but since constcache is instantiated per core, have to divide by number of cores in TPC
	double frac = 1.0/(double)XML->sys.core[ithCore].gpu_SM_per_TPC;
	set_pppm(pppm_t, frac, frac, frac, frac);
	L2->local_result.power = L2->local_result.power * pppm_t;
	// L3 is per-chip, but constcache is instantiated per core, so have to divide by number of SMs in chip
	frac = frac / (double)XML->sys.core[ithCore].gpu_num_TPCs;
	set_pppm(pppm_t, frac, frac, frac, frac);
	L3->local_result.power = L3->local_result.power * pppm_t;
	
	L1->power_t.readOp.dynamic += 
	L1->local_result.power.readOp.dynamic * L1->stats_t.readAc.access 
	+ L1->local_result.power.writeOp.dynamic * L1->stats_t.writeAc.access; 

	L2->power_t.readOp.dynamic += 
	L2->local_result.power.readOp.dynamic * L2->stats_t.readAc.access 
	+ L2->local_result.power.writeOp.dynamic * L2->stats_t.writeAc.access; 

	if(existL3) {
		L3->power_t.readOp.dynamic += 
		L3->local_result.power.readOp.dynamic * L3->stats_t.readAc.access 
		+ L3->local_result.power.writeOp.dynamic * L3->stats_t.writeAc.access;
	}

	// Computation phase
	if(is_tdp) {
		L1->power = L1->power_t + L1->local_result.power * pppm_lkg;
		L2->power = L2->power_t + L2->local_result.power * pppm_lkg;
		power = power +L1->power + L2->power;
		
		if(existL3){
			L3->power = L3->power_t + L3->local_result.power * pppm_lkg;
			power = power + L3->power;
		}
	} else {
		L1->rt_power = L1->power_t + L1->local_result.power * pppm_lkg;
		L2->rt_power = L2->power_t + L2->local_result.power * pppm_lkg;
		rt_power = rt_power + L1->rt_power + L2->rt_power;
		
		if(existL3) {
			L3->rt_power = L3->power_t + L3->local_result.power * pppm_lkg;
			rt_power = rt_power + L3->rt_power;
		}
	}
}

void ConstantCache::displayEnergy(uint32_t indent, int plevel, bool is_tdp) {
	string indent_str(indent, ' ');
	string indent_str_next(indent+2, ' ');
	bool long_channel = XML->sys.longer_channel_device;
	
	if(is_tdp) {
		cout << indent_str<< "L1 Constant Cache:" << endl;
		cout << indent_str_next << "Area = " << L1->area.get_area()*1e-6<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << L1->power.readOp.dynamic*clockRate << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = " << (long_channel? L1->power.readOp.longer_channel_leakage:L1->power.readOp.leakage) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << L1->power.readOp.gate_leakage << " W" << endl;
		cout << indent_str_next << "Runtime Dynamic = " << L1->rt_power.readOp.dynamic/executionTime << " W" << endl;
		cout << endl;
		
		cout << indent_str<< "L2 Constant Cache (Core Slice):" << endl;
		cout << indent_str_next << "Area = " << L2->area.get_area()*1e-6<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << L2->power.readOp.dynamic*clockRate << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = "
			<< (long_channel? L2->power.readOp.longer_channel_leakage:L2->power.readOp.leakage) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << L2->power.readOp.gate_leakage << " W" << endl;
		cout << indent_str_next << "Runtime Dynamic = " << L2->rt_power.readOp.dynamic/executionTime << " W" << endl;
		cout << endl;
		
		cout << indent_str<< "L3 Constant Cache (Core Slice):" << endl;
		cout << indent_str_next << "Area = " << L3->area.get_area()*1e-6<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << L3->power.readOp.dynamic*clockRate << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = "
			<< (long_channel? L3->power.readOp.longer_channel_leakage:L3->power.readOp.leakage) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << L3->power.readOp.gate_leakage << " W" << endl;
		cout << indent_str_next << "Runtime Dynamic = " << L3->rt_power.readOp.dynamic/executionTime << " W" << endl;
		cout << endl;
	}
}

L2Cache::L2Cache(ParseXML *XML_interface, int ithCore_, InputParameter* interface_ip_, const CoreDynParam& dyn_p_)
: XML(XML_interface),
  ithCore(ithCore_),
  interface_ip(*interface_ip_),
  coredynp(dyn_p_)
  {
	int tag, data, size, line, assoc, banks;
	clockRate = coredynp.clockRate*XML->sys.core[ithCore].gpu_clock_L2_to_uncore_ratio;
	executionTime = coredynp.executionTime/XML->sys.core[ithCore].gpu_clock_L2_to_uncore_ratio;

	//tag = (int)ceil(log2(XML->sys.core[ithCore].gpu_user_addressable_constmem)) + EXTRA_ADDRESSABLE_CONSTMEM_BITS;
	//tag = (int)ceil(log2(XML->sys.core[ithCore].gpu_user_addressable_globalmem));
	size                             = (int)XML->sys.core[ithCore].gpu_l2_size;
	line                             = (int)XML->sys.core[ithCore].gpu_l2_line;
	assoc                            = (int)XML->sys.core[ithCore].gpu_l2_assoc;

	tag=XML->sys.core[ithCore].gpu_globalmem_address_bits- log2(size/(line*assoc))-log2(line);
	banks                            = 4;
	interface_ip.specific_tag        = 1;
	interface_ip.tag_w               = tag;
	interface_ip.cache_sz            = size;
	interface_ip.line_sz             = line;
	interface_ip.assoc               = assoc;
	interface_ip.nbanks              = banks;
	interface_ip.out_w               = (int)XML->sys.NoC[0].flit_bits;		// NOC flitsize is a resonable assumption for the port size
	interface_ip.access_mode         = 0;
	interface_ip.throughput          = 1.0/clockRate;
	interface_ip.latency             = 3.0/clockRate;
	interface_ip.is_cache            = true;
	interface_ip.obj_func_dyn_energy = 0;
	interface_ip.obj_func_dyn_power  = 0;
	interface_ip.obj_func_leak_power = 0;
	interface_ip.obj_func_cycle_t    = 1;
	interface_ip.num_rw_ports    = 1;
	interface_ip.num_rd_ports    = 0;
	interface_ip.num_wr_ports    = 0;
	interface_ip.num_se_rd_ports = 0;
// 	fprintf(stderr, "Generating L1 cache...\n");
	L2 = new ArrayST(&interface_ip, "L2 Cache", Core_device, coredynp.opt_local, coredynp.core_ty);
	L2->area.set_area(L2->area.get_area()+ L2->local_result.area);
	area.set_area(area.get_area()+ L2->local_result.area);

}

// Currently gpgpu-sim provides information for accesses,misses and hits to L2 only. It does not provide separate account of number of reads
// and writes. So only number of accesses is equally divided between reads and writes for calculating the power.
void L2Cache::computeEnergy(bool is_tdp) {
	double r_access, w_access;
	double pppm_t[4] = {1,1,1,1};
	set_pppm(pppm_t, XML->sys.core[ithCore].gddr_num_mp, XML->sys.core[ithCore].gddr_num_mp, XML->sys.core[ithCore].gddr_num_mp, XML->sys.core[ithCore].gddr_num_mp);
	// Initialization phase
	if(is_tdp) {

		L2->stats_t.readAc.access = L2->stats_t.writeAc.access = 1;
		L2->tdp_stats = L2->stats_t;


	} else {

		L2->stats_t.readAc.access = XML->sys.core[ithCore].af_l2_accesses*0.5;
		L2->stats_t.writeAc.access =XML->sys.core[ithCore].af_l2_accesses*0.5;
		L2->rtp_stats = L2->stats_t;
	}

	L2->power_t.reset();

	// L2 is per TPC, but since constcache is instantiated per core, have to divide by number of cores in TPC
	//double frac = 1.0/(double)XML->sys.core[ithCore].gpu_SM_per_TPC;
//	set_pppm(pppm_t, frac, frac, frac, frac);
	//L2->local_result.power = L2->local_result.power * pppm_t;

	L2->power_t.readOp.dynamic +=
	L2->local_result.power.readOp.dynamic * L2->stats_t.readAc.access
	+ L2->local_result.power.writeOp.dynamic * L2->stats_t.writeAc.access;

	// Computation phase
	if(is_tdp) {
		L2->power = L2->power_t + L2->local_result.power * pppm_lkg;
		power = power + L2->power;


	} else {
		L2->rt_power = L2->power_t + L2->local_result.power * pppm_lkg;
		rt_power = rt_power + L2->rt_power;

	}
}

void L2Cache::displayEnergy(uint32_t indent, int plevel, bool is_tdp) {
	string indent_str(indent, ' ');
	string indent_str_next(indent+2, ' ');
	bool long_channel = XML->sys.longer_channel_device;

	if(is_tdp) {
		cout << indent_str<< "L2 Cache (Per Memory Partition):" << endl;
		cout << indent_str_next << "Area = " << L2->area.get_area()*1e-6<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << L2->power.readOp.dynamic*clockRate << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = "
			<< (long_channel? L2->power.readOp.longer_channel_leakage:L2->power.readOp.leakage) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << L2->power.readOp.gate_leakage << " W" << endl;
		cout << indent_str_next << "Runtime Dynamic = " << L2->rt_power.readOp.dynamic/executionTime << " W" << endl;
		cout << endl;

	}
}


AddressGenerationU::AddressGenerationU(ParseXML *XML_interface, int ithCore_, InputParameter* interface_ip_, const CoreDynParam & dyn_p_, bool exist_, int instances_, enum Device_ty device_ty_)
: exist(exist_),
  coredynp(dyn_p_),
  ithCore(ithCore_),
  XML(XML_interface),
  l_ip(*interface_ip_),
  instances(instances_),
  device_ty(device_ty_)
{
	clockRate = coredynp.clockRate;
	executionTime = coredynp.executionTime;

	WNANDn = 25 * l_ip.F_sz_um; //was 20 micron for the 0.8 micron proess
	WNANDp = 37.5 * l_ip.F_sz_um; //was 30 micron for the 0.8 micron process

	cell_load = 8 * gate_C(WNANDn + WNANDp, 0, false); // 8 is an assumption for now, can be readjusted later if necessary

	computeEnergy();
}

void AddressGenerationU::computeEnergy(bool is_tdp) {
	if(!exist) return;

	double Ctotal, CFullAdd, CAccumArith, CAddrGen;
	double WSelORn, WSelORprequ, WSelPn, WSelPp, WSelEnn, WSelEnp;

	int num_cells = 64 * 8; // 64 DFFs for each accumulator, 8 accumulators
	DFFCell cell(false, WNANDn, WNANDp, cell_load, &l_ip);
	cell.compute_DFF_cell();

	double clock_power = num_cells * cell.e_clock.readOp.dynamic;
	double total_power = num_cells * (cell.e_switch.readOp.dynamic + cell.e_keep_0.readOp.dynamic + cell.e_keep_1.readOp.dynamic)/3 + clock_power;
	double total_leakage = num_cells * cell.e_switch.readOp.leakage;
	double total_gate_leakage = num_cells * cell.e_switch.readOp.gate_leakage;
	power.readOp.dynamic += total_power;
	power.readOp.leakage += total_leakage;
	power.readOp.gate_leakage += total_gate_leakage;
	area.set_area(num_cells * cell.area.get_area());

	double long_channel_device_reduction = longer_channel_device_reduction(device_ty, coredynp.core_ty);
	power.readOp.longer_channel_leakage = power.readOp.leakage*long_channel_device_reduction;

	double sckRation = g_tp.sckt_co_eff;
	power.readOp.dynamic *= sckRation;
	power.writeOp.dynamic *= sckRation;
	power.searchOp.dynamic *= sckRation;

	area.set_area(area.get_area() * g_tp.macro_layout_overhead);

	// TODO: UPDATE! 0.8um process data is used ... is this even correct?
	WSelPn     = 12.5 * l_ip.F_sz_um;//this was 10mcron for the 0.8 micron process
	WSelPp     = 18.75 * l_ip.F_sz_um;//this was 15 micron for the 0.8 micron process

	CFullAdd = 4.0 * (drain_C_(WSelPn, NCH, 1, 1, g_tp.cell_h_def) +  drain_C_(WSelPp, PCH, 1, 1, g_tp.cell_h_def)) + 3.0 * gate_C(WSelPn + WSelPp, 10.0);

	CAccumArith = 64.0 * CFullAdd + 32.0 * 0.5 * CFullAdd; // last part is estimate for half adder, TODO
	CAddrGen = CAccumArith + 32.0 * 2.0 * CFullAdd;
	Ctotal = (double)instances * 8.0 * CAddrGen;

	power.readOp.dynamic += Ctotal * g_tp.peri_global.Vdd * g_tp.peri_global.Vdd;

	rt_power.readOp.dynamic *= XML->sys.core[ithCore].af_general_memory_instructions;
}

TextureCache::TextureCache(ParseXML* interface, int _ithCore, InputParameter* _ip, const CoreDynParam& _dynp, bool _exist) 
: XML(interface),
  ithCore(_ithCore),
  interface_ip(*_ip),
  coredynp(_dynp),
  exist(_exist),
  L1Tags(NULL),
  L1Data(NULL)
{
	if(!exist) return;
	// Grab information from XML parser
	lineSizeL1 = XML->sys.core[ithCore].gpu_texmem_L1_line;
	lineSizeL2 = XML->sys.core[ithCore].gpu_texmem_L2_line;
	setAssocL1 = XML->sys.core[ithCore].gpu_texmem_L1_assoc;
	setAssocL2 = XML->sys.core[ithCore].gpu_texmem_L2_assoc;
	cacheSizeL1 = XML->sys.core[ithCore].gpu_texmem_L1_size;
	cacheSizeL2 = XML->sys.core[ithCore].gpu_texmem_L2_size;	
	int cores = XML->sys.core[ithCore].gpu_num_TPCs * XML->sys.core[ithCore].gpu_SM_per_TPC;
	if(XML->sys.core[ithCore].gpu_num_tmus)
		TMUsPerCore = XML->sys.core[ithCore].gpu_num_tmus / (double)(cores);
	
	
	// compute tag bits and total tag store size
	int sets = cacheSizeL1/(setAssocL1*lineSizeL1);
	int tag = (int)ceil(log2(sets));
	int tagStoreSizeBits = sets * setAssocL1 * tag;
	
	// compute data array info
	int singleBankDataArraySize = sets * (setAssocL1 / TMUsPerCore) * lineSizeL1;
	
	clockRate = coredynp.clockRate;
	executionTime = coredynp.executionTime;
	
	/* For texture cache, we model tag store and data array as two separate SRAM structures
	 * because the CACTI optimizer cannot handle small, highly associative, multibanked caches */
	
	// Tag store
	interface_ip.cache_sz            = tagStoreSizeBits/8;
	interface_ip.line_sz             = (int)ceil((double)tag/8.0);
	interface_ip.assoc               = setAssocL1;
	interface_ip.nbanks              = 1;
	interface_ip.out_w               = interface_ip.line_sz;
	interface_ip.access_mode         = 0;
	interface_ip.throughput          = 1.0/clockRate;
	interface_ip.latency             = 1.0/clockRate;
	interface_ip.is_cache            = false;
	interface_ip.pure_ram            = true;
	interface_ip.obj_func_dyn_energy = 0;
	interface_ip.obj_func_dyn_power  = 0;
	interface_ip.obj_func_leak_power = 0;
	interface_ip.obj_func_cycle_t    = 1;
	interface_ip.num_rw_ports    = 0;
	interface_ip.num_rd_ports    = 1;
	interface_ip.num_wr_ports    = 1;
	interface_ip.num_se_rd_ports = 0;
	L1Tags = new ArrayST(&interface_ip, "L1TextureCache Tag Store", Core_device, coredynp.opt_local, coredynp.core_ty);
	L1Tags->area.set_area(L1Tags->area.get_area()+ L1Tags->local_result.area);
	area.set_area(area.get_area()+ L1Tags->local_result.area);
	
// 	printf("Optimized tag store, proceeding to data array ...\n");
	
	// Data array
	interface_ip.specific_tag        = 1;
	interface_ip.cache_sz            = cacheSizeL1;
	interface_ip.line_sz             = lineSizeL1;
	interface_ip.assoc               = 1;
	interface_ip.nbanks              = TMUsPerCore;
	interface_ip.out_w               = interface_ip.line_sz * 8;
	interface_ip.access_mode         = 0;
	interface_ip.throughput          = 1.0/clockRate;
	interface_ip.latency             = 1.0/clockRate;
	interface_ip.is_cache            = false;
	interface_ip.pure_ram            = true;
	interface_ip.obj_func_dyn_energy = 0;
	interface_ip.obj_func_dyn_power  = 0;
	interface_ip.obj_func_leak_power = 0;
	interface_ip.obj_func_cycle_t    = 1;
	interface_ip.num_rw_ports    = 0;
	interface_ip.num_rd_ports    = 1;
	interface_ip.num_wr_ports    = 1;
	interface_ip.num_se_rd_ports = 0;
	L1Data = new ArrayST(&interface_ip, "L1TextureCache Data Array", Core_device, coredynp.opt_local, coredynp.core_ty);
	L1Data->area.set_area(L1Data->area.get_area()+ L1Data->local_result.area);
	area.set_area(area.get_area()+ L1Data->local_result.area);
	
	// NOTE: not entirely sure there is no L2 tex $. Could be unified with L2 D$?
}

void TextureCache::computeEnergy(bool is_tdp) {
	double pppm_t[4] = {1,1,1,1};
	
	// Initialization phase
	if(is_tdp) {
		// L1
		L1Tags->stats_t.readAc.access = L1Tags->stats_t.writeAc.access = L1Data->stats_t.writeAc.access = L1Data->stats_t.readAc.access = 1;
		L1Tags->tdp_stats = L1Tags->stats_t;
		L1Data->tdp_stats = L1Data->stats_t;
	} else {
		// L1
		L1Tags->stats_t.readAc.access = XML->sys.core[ithCore].af_general_texmem_instructions;
		L1Data->stats_t.readAc.access = XML->sys.core[ithCore].af_general_texmem_instructions;
		L1Tags->stats_t.writeAc.access = XML->sys.core[ithCore].af_texmem_misses;
		L1Data->stats_t.writeAc.access = XML->sys.core[ithCore].af_texmem_misses;
		L1Tags->rtp_stats = L1Tags->stats_t;
		L1Data->rtp_stats = L1Data->stats_t;
	}
	
	L1Tags->power_t.reset();
	L1Data->power_t.reset();
	L1Tags->power_t.readOp.dynamic += 
	L1Tags->local_result.power.readOp.dynamic * L1Tags->stats_t.readAc.access 
	+ L1Tags->local_result.power.writeOp.dynamic * L1Tags->stats_t.writeAc.access; 
	L1Data->local_result.power.readOp.dynamic * L1Data->stats_t.readAc.access 
	+ L1Data->local_result.power.writeOp.dynamic * L1Data->stats_t.writeAc.access; 

	// Computation phase
	if(is_tdp) {
		L1Tags->power = L1Tags->power_t + L1Tags->local_result.power * pppm_lkg;
		L1Data->power = L1Data->power_t + L1Data->local_result.power * pppm_lkg;
		power = power + L1Tags->power + L1Data->power;
	} else {
		L1Tags->rt_power = L1Tags->power_t + L1Tags->local_result.power * pppm_lkg;
		L1Data->rt_power = L1Data->power_t + L1Data->local_result.power * pppm_lkg;
		rt_power = rt_power + L1Tags->rt_power + L1Data->power;		
	}
}

void TextureCache::displayEnergy(uint32_t indent, int plevel, bool is_tdp) {
	string indent_str(indent, ' ');
	string indent_str_next(indent+2, ' ');
	bool long_channel = XML->sys.longer_channel_device;

	if(is_tdp) {
		cout << indent_str<< "Level 1 Tag Store:" << endl;
		cout << indent_str_next << "Area = " << L1Tags->area.get_area()*1e-6<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << L1Tags->power.readOp.dynamic*clockRate << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = "
			<< (long_channel? L1Tags->power.readOp.longer_channel_leakage:L1Tags->power.readOp.leakage) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << L1Tags->power.readOp.gate_leakage << " W" << endl;
		cout << indent_str_next << "Runtime Dynamic = " << L1Tags->rt_power.readOp.dynamic/executionTime << " W" << endl;
		cout << endl;
		
		cout << indent_str<< "Level 1 Data Array:" << endl;
		cout << indent_str_next << "Area = " << L1Data->area.get_area()*1e-6<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << L1Data->power.readOp.dynamic*clockRate << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = "
			<< (long_channel? L1Data->power.readOp.longer_channel_leakage:L1Data->power.readOp.leakage) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << L1Data->power.readOp.gate_leakage << " W" << endl;
		cout << indent_str_next << "Runtime Dynamic = " << L1Data->rt_power.readOp.dynamic/executionTime << " W" << endl;
		cout << endl;

	}
}

GPULoadStoreU::GPULoadStoreU(ParseXML *XML_interface, int ithCore_, InputParameter* interface_ip_,const CoreDynParam & dyn_p_, bool exist_)
 :XML(XML_interface),
  ithCore(ithCore_),
  interface_ip(*interface_ip_),
  coredynp(dyn_p_),
  exist(exist_)
{
	if(!exist) return;
	int tag, data, agu_instances;

	//TODO: Need to scale clockRate and ExecutionTime according to its clock in GPU
	//Not scaled yet. Assumption is LD/ST unit works at Uncore clock
	clockRate = coredynp.clockRate;
	executionTime = coredynp.executionTime;
	
	// Coalescence-like logics
	cl = new DFFCoalescingU(XML, ithCore, &interface_ip, coredynp);
	area.set_area(area.get_area() + cl->area.get_area());
	bank_cl = new DFFCoalescingU(XML, ithCore, &interface_ip, coredynp);
	area.set_area(area.get_area() + bank_cl->area.get_area());
	
	// Constant Cache
	constcache = new ConstantCache(XML, ithCore, &interface_ip, coredynp);
	area.set_area(area.get_area() + constcache->area.get_area());
	
	// Shared memory and D-Cache
	shmem = new SharedMemory(XML, ithCore, &interface_ip,coredynp);
	area.set_area(area.get_area() + shmem->area.get_area());
	
	// Unified L2 Cache
	if(XML->sys.core[ithCore].gpu_l2_cached) {
	L2cache = new L2Cache(XML, ithCore, &interface_ip,coredynp);
	area.set_area(area.get_area() + ((float)(XML->sys.core[ithCore].gddr_num_mp)/XML->sys.number_of_cores)*L2cache->area.get_area());
	}

	// Address generation unit
	agu_instances = XML->sys.core[ithCore].gpu_threads_per_warp / 4;
	agu_instances /= LDSTU_WSIZE_MOD; // We know that current GPUs operate the LDSTU at double frequency but process only half-wide warps
	agu = new AddressGenerationU(XML, ithCore, &interface_ip, coredynp, true, agu_instances);
	area.set_area(area.get_area() + agu->area.get_area());
	
	tex = new TextureCache(XML, ithCore, &interface_ip, coredynp);
	area.set_area(area.get_area() + tex->area.get_area());
	
}

void GPULoadStoreU::computeEnergy(bool is_tdp) {
	constcache->computeEnergy(is_tdp);
	shmem->computeEnergy(is_tdp);
	tex->computeEnergy(is_tdp);

	if(XML->sys.core[ithCore].gpu_l2_cached) {
	L2cache->computeEnergy(is_tdp);
	}
	double pppm_t[4];
	float alpha=(float)XML->sys.core[ithCore].gddr_num_mp/(float)XML->sys.number_of_cores;
	set_pppm(pppm_t,alpha,alpha,alpha,alpha);
	if(is_tdp)
	{
		power = power + cl->power + bank_cl->power + constcache->power+shmem->power +agu->power + tex->power;
		if(XML->sys.core[ithCore].gpu_l2_cached) {
			power = power + L2cache->power*pppm_t;
		}
	}
	else
	{
		rt_power = rt_power + cl->rt_power + bank_cl->rt_power + constcache->rt_power+shmem->rt_power + agu->rt_power + tex->rt_power;
		if(XML->sys.core[ithCore].gpu_l2_cached) {
			rt_power = rt_power + L2cache->rt_power *pppm_t;
		}
	}
	return;
}

void GPULoadStoreU::displayEnergy(uint32_t indent,int plevel, bool is_tdp) {
	string indent_str(indent, ' ');
	string indent_str_next(indent+2, ' ');
	bool long_channel = XML->sys.longer_channel_device;
	
	if(is_tdp) {
	cout << indent_str<< "Coalescer:" << endl;
	cout << indent_str_next << "Area = " << cl->area.get_area()*1e-6<< " mm^2" << endl;
	cout << indent_str_next << "Peak Dynamic = " << cl->power.readOp.dynamic*clockRate*LDSTU_CLK_MULT << " W" << endl;
	cout << indent_str_next << "Subthreshold Leakage = " << (long_channel? cl->power.readOp.longer_channel_leakage:cl->power.readOp.leakage) <<" W" << endl;
	cout << indent_str_next << "Gate Leakage = " << cl->power.readOp.gate_leakage << " W" << endl;
	cout << indent_str_next << "Runtime Dynamic = " << cl->rt_power.readOp.dynamic/executionTime << " W" << endl;
	cout << endl;
	
	cout << indent_str<< "Bank Conflict Checker:" << endl;
	cout << indent_str_next << "Area = " << bank_cl->area.get_area()*1e-6<< " mm^2" << endl;
	cout << indent_str_next << "Peak Dynamic = " << bank_cl->power.readOp.dynamic*clockRate*LDSTU_CLK_MULT << " W" << endl;
	cout << indent_str_next << "Subthreshold Leakage = "
		<< (long_channel? bank_cl->power.readOp.longer_channel_leakage:bank_cl->power.readOp.leakage) <<" W" << endl;
	cout << indent_str_next << "Gate Leakage = " << bank_cl->power.readOp.gate_leakage << " W" << endl;
	cout << indent_str_next << "Runtime Dynamic = " << bank_cl->rt_power.readOp.dynamic/executionTime << " W" << endl;
	cout << endl;
	
	cout << indent_str<< "AGU Array:" << endl;
	cout << indent_str_next << "Area = " << agu->area.get_area()*1e-6<< " mm^2" << endl;
	cout << indent_str_next << "Peak Dynamic = " << agu->power.readOp.dynamic*clockRate*LDSTU_CLK_MULT << " W" << endl;
	cout << indent_str_next << "Subthreshold Leakage = "
		<< (long_channel? agu->power.readOp.longer_channel_leakage:agu->power.readOp.leakage) <<" W" << endl;
	cout << indent_str_next << "Gate Leakage = " << agu->power.readOp.gate_leakage << " W" << endl;
	cout << indent_str_next << "Runtime Dynamic = " << agu->rt_power.readOp.dynamic/executionTime << " W" << endl;
	cout << endl;
	
	cout << indent_str<< "Per-Core Constant Cache Partition:" << endl;
	cout << indent_str_next << "Area = " << constcache->area.get_area()*1e-6<< " mm^2" << endl;
	cout << indent_str_next << "Peak Dynamic = " << constcache->power.readOp.dynamic*clockRate << " W" << endl;
	cout << indent_str_next << "Subthreshold Leakage = "
		<< (long_channel? constcache->power.readOp.longer_channel_leakage:constcache->power.readOp.leakage) <<" W" << endl;
	cout << indent_str_next << "Gate Leakage = " << constcache->power.readOp.gate_leakage << " W" << endl;
	cout << indent_str_next << "Runtime Dynamic = " << constcache->rt_power.readOp.dynamic/executionTime << " W" << endl;
	cout << endl;
	if(plevel > 2)
		constcache->displayEnergy(indent+2, plevel, is_tdp);

	cout << indent_str << "Shared Memory Per SM:" << endl;
	cout << indent_str_next << "Area = " << shmem->area.get_area()*1e-6<< " mm^2" << endl;
	cout << indent_str_next << "Peak Dynamic = " << shmem->power.readOp.dynamic*clockRate *XML->sys.core[ithCore].gpu_clock_shader_to_uncore_ratio<< " W" << endl;
	cout << indent_str_next << "Subthreshold Leakage = "
	  << (long_channel? shmem->power.readOp.longer_channel_leakage:shmem->power.readOp.leakage) <<" W" << endl;
	//cout << indent_str_next << "Subthreshold Leakage = " << ifu->power.readOp.longer_channel_leakage <<" W" << endl;
	cout << indent_str_next << "Gate Leakage = " << shmem->power.readOp.gate_leakage << " W" << endl;
	cout << indent_str_next << "Runtime Dynamic = " << shmem->rt_power.readOp.dynamic/executionTime << " W" << endl;
	cout <<endl;
	if(plevel > 2)
		shmem->displayEnergy(indent+4,plevel,is_tdp);
	cout << indent_str << "Texture Cache:" << endl;
	cout << indent_str_next << "Area = " << tex->area.get_area()*1e-6<< " mm^2" << endl;
	cout << indent_str_next << "Peak Dynamic = " << tex->power.readOp.dynamic*clockRate << " W" << endl;
	cout << indent_str_next << "Subthreshold Leakage = "
	  << (long_channel? tex->power.readOp.longer_channel_leakage:tex->power.readOp.leakage) <<" W" << endl;
	//cout << indent_str_next << "Subthreshold Leakage = " << ifu->power.readOp.longer_channel_leakage <<" W" << endl;
	cout << indent_str_next << "Gate Leakage = " << tex->power.readOp.gate_leakage << " W" << endl;
	cout << indent_str_next << "Runtime Dynamic = " << tex->rt_power.readOp.dynamic/executionTime << " W" << endl;
	cout <<endl;
	if(plevel > 2)
		tex->displayEnergy(indent+4, plevel, is_tdp);
	if(XML->sys.core[ithCore].gpu_l2_cached) {
	float alpha=(float)XML->sys.core[ithCore].gddr_num_mp/(float)XML->sys.number_of_cores;
	cout << indent_str << "L2 Cache Per SM"<<endl;
	cout << indent_str_next << "Area = " << L2cache->area.get_area()*1e-6*alpha<< " mm^2" << endl;
	cout << indent_str_next << "Peak Dynamic = " << L2cache->power.readOp.dynamic*clockRate*alpha << " W" << endl;
	cout << indent_str_next << "Subthreshold Leakage = "
	     << (long_channel? L2cache->power.readOp.longer_channel_leakage*alpha:L2cache->power.readOp.leakage*alpha) <<" W" << endl;
	//cout << indent_str_next << "Subthreshold Leakage = " << ifu->power.readOp.longer_channel_leakage <<" W" << endl;
	cout << indent_str_next << "Gate Leakage = " << L2cache->power.readOp.gate_leakage*alpha << " W" << endl;
	cout << indent_str_next << "Runtime Dynamic = " << L2cache->rt_power.readOp.dynamic/executionTime*alpha << " W" << endl;
	cout <<endl;
	if(plevel > 2)
		L2cache->displayEnergy(indent+4,plevel,is_tdp);
	}
	}
}

GPUUndiffCore::GPUUndiffCore(ParseXML* XML_interface, int ithCore_, InputParameter* interface_ip_, const CoreDynParam & dyn_p_, bool exist_) 
: XML(XML_interface),
  ithCore(ithCore_),
  interface_ip(*interface_ip_),
  coredynp(dyn_p_),
  exist(exist_),
  num_rops(64.0),
  num_tmus(128.0)
{
	if(!exist) return;
	int cores = XML->sys.core[ithCore].gpu_num_TPCs * XML->sys.core[ithCore].gpu_SM_per_TPC;
	num_warps = XML->sys.core[ithCore].gpu_core_warps_in_flight;
	if(XML->sys.core[ithCore].gpu_num_rops)
		num_rops = XML->sys.core[ithCore].gpu_num_rops / (double)(cores);
	if(XML->sys.core[ithCore].gpu_num_tmus)
		num_tmus = XML->sys.core[ithCore].gpu_num_tmus / (double)(cores);
	
	double undiffcore_area = 0;
	double core_tx_density = 0;
	double pmos_to_nmos_sizing_r = pmos_to_nmos_sz_ratio();
	uca_org_t result = init_interface(&interface_ip);
	
	undiffcore_area = num_rops * 1.818 + num_tmus * 1.584; // GT200b estimates
	undiffcore_area *= g_tp.scaling_factor.logic_scaling_co_eff * 1e6; //change from mm^2 to um^2
	
	core_tx_density                 = g_tp.scaling_factor.core_tx_density;
	power.readOp.leakage = undiffcore_area*(core_tx_density)*cmos_Isub_leakage(5*g_tp.min_w_nmos_, 5*g_tp.min_w_nmos_*pmos_to_nmos_sizing_r, 1, inv)*g_tp.peri_global.Vdd;//unit W
	power.readOp.gate_leakage = undiffcore_area*(core_tx_density)*cmos_Ig_leakage(5*g_tp.min_w_nmos_, 5*g_tp.min_w_nmos_*pmos_to_nmos_sizing_r, 1, inv)*g_tp.peri_global.Vdd;

	double long_channel_device_reduction = longer_channel_device_reduction(Core_device, coredynp.core_ty);
	power.readOp.longer_channel_leakage = power.readOp.leakage*long_channel_device_reduction;
	area.set_area(undiffcore_area);

	scktRatio = g_tp.sckt_co_eff;
	power.readOp.dynamic *= scktRatio;
	power.writeOp.dynamic *= scktRatio;
	power.searchOp.dynamic *= scktRatio;
	macro_PR_overhead = g_tp.macro_layout_overhead;
	area.set_area(area.get_area()*macro_PR_overhead);
}

void GPUUndiffCore::displayEnergy(uint32_t indent, int plevel, bool is_tdp) {
	string indent_str(indent, ' ');
	string indent_str_next(indent+2, ' ');
	bool long_channel = XML->sys.longer_channel_device;

	if (is_tdp)
	{
		cout << indent_str << "GPU UndiffCore:" << endl;
		cout << indent_str_next << "Area = " << area.get_area()*1e-6<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << power.readOp.dynamic*clockRate << " W" << endl;
		cout << indent_str_next<< "Subthreshold Leakage = "
					<< (long_channel? power.readOp.longer_channel_leakage:power.readOp.leakage) <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << power.readOp.gate_leakage << " W" << endl;
		cout <<endl;
	}
	else
	{
		cout << indent_str << "GPU UndiffCore:" << endl;
		cout << indent_str_next << "Area = " << area.get_area()*1e-6<< " mm^2" << endl;
		cout << indent_str_next << "Peak Dynamic = " << power.readOp.dynamic*clockRate << " W" << endl;
		cout << indent_str_next << "Subthreshold Leakage = " << power.readOp.leakage <<" W" << endl;
		cout << indent_str_next << "Gate Leakage = " << power.readOp.gate_leakage << " W" << endl;
		cout <<endl;
	}
}

/*
Gddr::Gddr(ParseXML* XML_interface, int ithMemoryPartition_, InputParameter* interface_ip_, const CoreDynParam & dyn_p_, bool exist_)
:XML(XML_interface),
 ithMemoryPartition(ithMemoryPartition_),
 interface_ip(*interface_ip_),
 coredynp(dyn_p_),
 exist(exist_)
{
	if(!exist)
		return;

	//Data Sheet Background power
	pds_pre_pdn=XML->sys.core[ithMemoryPartition].gddr_idd2p*XML->sys.core[ithMemoryPartition].gddr_vdd;
	pds_pre_stby=XML->sys.core[ithMemoryPartition].gddr_idd2n*XML->sys.core[ithMemoryPartition].gddr_vdd;
	pds_act_pdn=XML->sys.core[ithMemoryPartition].gddr_idd3p*XML->sys.core[ithMemoryPartition].gddr_vdd;
	pds_act_stby=XML->sys.core[ithMemoryPartition].gddr_idd3n*XML->sys.core[ithMemoryPartition].gddr_vdd;

	//Background power scaled according to system usage
	psch_pre_pdn=pds_pre_pdn*XML->sys.core[ithMemoryPartition].af_bnk_pre_percent*XML->sys.core[ithMemoryPartition].af_cke_lo_pre_percent;
	psch_pre_stby=pds_pre_stby*XML->sys.core[ithMemoryPartition].af_bnk_pre_percent*(1-XML->sys.core[ithMemoryPartition].af_cke_lo_pre_percent);
	psch_act_pdn=pds_act_pdn*(1-XML->sys.core[ithMemoryPartition].af_bnk_pre_percent)*XML->sys.core[ithMemoryPartition].af_cke_lo_act_percent;
	psch_act_stby=pds_act_stby*(1-XML->sys.core[ithMemoryPartition].af_bnk_pre_percent)*(1-XML->sys.core[ithMemoryPartition].af_cke_lo_act_percent);

	// Activation to activation power
	pds_act=(XML->sys.core[ithMemoryPartition].gddr_idd0-(XML->sys.core[ithMemoryPartition].gddr_idd3n*XML->sys.core[ithMemoryPartition].tRAS+XML->sys.core[ithMemoryPartition].gddr_idd2n*(XML->sys.core[ithMemoryPartition].tRC-XML->sys.core[ithMemoryPartition].tRAS))/XML->sys.core[ithMemoryPartition].tRC);

	//activation power scaled according to averaged scheduled row to row activate timing
	psch_act=pds_act*(XML->sys.core[ithMemoryPartition].tRC/XML->sys.core[ithMemoryPartition].af_tRRDsch);

	// Power consumption due to WRITES
	pds_wr=(XML->sys.core[ithMemoryPartition].gddr_idd4w-XML->sys.core[ithMemoryPartition].gddr_idd3n)*XML->sys.core[ithMemoryPartition].gddr_vdd;

	// WRITEs power scaling according to command scheduling
	psch_wr=pds_wr*XML->sys.core[ithMemoryPartition].af_wrsch_percent;

	// Power consumption due to READS
	pds_rd=(XML->sys.core[ithMemoryPartition].gddr_idd4r-XML->sys.core[ithMemoryPartition].gddr_idd3n)*XML->sys.core[ithMemoryPartition].gddr_vdd;

	// READs power scaling according to command scheduling
	psch_rd=pds_rd*XML->sys.core[ithMemoryPartition].af_rdsch_percent;

	// Nominal I/O Termination power consumption
	pds_dq=XML->sys.core[ithMemoryPartition].gddr_pdq_rd*XML->sys.core[ithMemoryPartition].gddr_num_dqr;
	pds_termW=XML->sys.core[ithMemoryPartition].gddr_pdq_wr*XML->sys.core[ithMemoryPartition].gddr_num_dqw;

	// Nominal I/O Termination power scaling according to command scheduling
	psch_dq=pds_dq*XML->sys.core[ithMemoryPartition].af_rdsch_percent;
	psch_termW=pds_termW*XML->sys.core[ithMemoryPartition].af_wrsch_percent;

	// Refresh Power
	pds_ref=(XML->sys.core[ithMemoryPartition].gddr_idd5-XML->sys.core[ithMemoryPartition].gddr_idd3n)*XML->sys.core[ithMemoryPartition].gddr_vdd;

	// Scaling according to average scheduled refresh command
	psch_ref=pds_ref*(XML->sys.core[ithMemoryPartition].tRFC/XML->sys.core[ithMemoryPartition].tREFI);

	//Power derating ( voltage and frequency scaling)

	if(XML->sys.core[ithMemoryPartition].gddr_mrs12==0)
		psys_pre_pdn=psch_pre_pdn*(XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd)*(XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd);
	else
		psys_pre_pdn=psch_pre_pdn*(XML->sys.core[ithMemoryPartition].gddr_clock_used/XML->sys.core[ithMemoryPartition].gddr_clock)*((XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd)*(XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd));
	psys_pre_stby=psch_pre_stby*(XML->sys.core[ithMemoryPartition].gddr_clock_used/XML->sys.core[ithMemoryPartition].gddr_clock)*((XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd)*(XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd));
	psys_act_pdn=psch_act_pdn*(XML->sys.core[ithMemoryPartition].gddr_clock_used/XML->sys.core[ithMemoryPartition].gddr_clock)*((XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd)*(XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd));
	psys_act_stby=psch_act_stby*(XML->sys.core[ithMemoryPartition].gddr_clock_used/XML->sys.core[ithMemoryPartition].gddr_clock)*((XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd)*(XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd));
	psys_act=psch_act*((XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd)*(XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd));
	psys_wr=psch_wr*(XML->sys.core[ithMemoryPartition].gddr_clock_used/XML->sys.core[ithMemoryPartition].gddr_clock)*((XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd)*(XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd));
	psys_rd=psch_rd*(XML->sys.core[ithMemoryPartition].gddr_clock_used/XML->sys.core[ithMemoryPartition].gddr_clock)*((XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd)*(XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd));
	psys_ref=psch_ref*((XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd)*(XML->sys.core[ithMemoryPartition].gddr_vdd_used/XML->sys.core[ithMemoryPartition].gddr_vdd));

	area.set_area(0);
}


void Gddr::computeEnergy(bool is_tdp)
{

	//double pppm_t[4]    = {1,1,1,1};
	// Initialization phase
	if (is_tdp)
	{
		//set_pppm(pppm_t, 2, 2, 2, 2);//2 means two source operands needs to be passed for each int instruction.
		stats_t.readAc.access = XML->sys.core[ithMemoryPartition].gddr_num_mp*XML->sys.core[ithMemoryPartition].gddr_num_dram_per_mp;
		tdp_stats = stats_t;


	    power.readOp.leakage = 0;
	    power.readOp.gate_leakage = 0;
	     //double long_channel_device_reduction = longer_channel_device_reduction(Core_device, coredynp.core_ty);
	    //power.readOp.longer_channel_leakage	= power.readOp.leakage*long_channel_device_reduction;
	}
	else
	{
		stats_t.readAc.access = XML->sys.core[ithMemoryPartition].gddr_num_mp*XML->sys.core[ithMemoryPartition].gddr_num_dram_per_mp;
		rtp_stats = stats_t;
	}

	//Computation phase
	if(is_tdp)
	{

		//Total Background power
		//pds_back_tot=pds_pre_pdn+pds_pre_stby+pds_act_pdn+pds_act_stby+pds_ref;
		//Background power needs to be weighted for Peak Dynamic also
		pds_back_tot=psys_pre_pdn+psys_pre_stby+psys_act_pdn+psys_act_stby+pds_ref;
		//Total Activate power
		pds_act=pds_act*(XML->sys.core[ithMemoryPartition].tRC/XML->sys.core[ithMemoryPartition].tRRD);

		pds_rwt_tot=pds_wr+pds_rd+pds_dq+pds_termW;

		// GDDR total power
		pds_tot=pds_back_tot+pds_act+pds_rwt_tot;
		power.readOp.dynamic = pds_tot*stats_t.readAc.access;

	}

	else
	{

		//Total Background power
		psys_back_tot=psys_pre_pdn+psys_pre_stby+psys_act_pdn+psys_act_stby+psys_ref;

		// Total Rd/Wr/Term Power
		psys_rwt_tot=psys_wr+psys_rd+psch_dq+psch_termW;

		// GDDR total power
		psys_tot=psys_back_tot+psys_act+psys_rwt_tot;
		rt_power.readOp.dynamic = psys_tot*stats_t.readAc.access;
	}


}


void Gddr::displayEnergy(uint32_t indent,int plevel,bool is_tdp)
{
	string indent_str(indent, ' ');
	string indent_str_next(indent+2, ' ');
	bool long_channel = XML->sys.longer_channel_device;

	if (is_tdp)
	{
			cout << indent_str << "Memory Partition (Count: "<< XML->sys.core[ithMemoryPartition].gddr_num_mp <<" ):" << endl;
			cout << indent_str << "Peak Dynamic = " << power.readOp.dynamic*1e-3 << " W" << endl;
			cout << indent_str_next << "Peak Background Power = " << pds_back_tot*1e-3  << " W" << endl;
			cout << indent_str_next << "Peak Activate Power = " << pds_act*1e-3  << " W" << endl;
			cout << indent_str_next << "Peak Rd/Wr/Term Power = " << pds_rwt_tot*1e-3  << " W" << endl;
			//cout << indent_str_next << "Gate Leakage = " << power.readOp.gate_leakage*1e-3  << " W" << endl;
			cout << indent_str << "Runtime Dynamic = " << rt_power.readOp.dynamic*1e-3 << " W" << endl;
			cout << indent_str_next << "Runtime Background Power = " << psys_back_tot*1e-3  << " W" << endl;
			cout << indent_str_next << "Runtime Activate Power = " << psys_act*1e-3  << " W" << endl;
			cout << indent_str_next << "Runtime Rd/Wr/Term Power = " << psys_rwt_tot*1e-3  << " W" << endl;
			cout <<endl;
	}
	else
	{
	}
}

*/

